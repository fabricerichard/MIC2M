function [var_dot] = v_ec_cine_nl_iso_1D_dot(t,var,flag,nom_para,para,type_var,num_var,nom_var,var_asservi_dot)
%function [var_dot,test_rupture,aux]=v_ec_cine_nl_iso_3D_dot(nom_para,para,type_var,num_var,nom_var,var,var_asservi_dot,pas_temps)

test_rupture=0;
aux=0;

% parametres
assignation_para(nom_para,para)

% variables
assignation_var(nom_var,var) 
assignation_var_asservi_dot(nom_var,var_asservi_dot) 

sigeq  =   abs(sigz-X)  ;
F = sigeq-sigy-R ;

if sigeq<=0 ; sigeq=1e-10 ; end 
if F<=0 ; F = 1e-10 ; end

% Loi viscoplastique
epsineq_dot = (F/K)^n  ;

% Normalit�
epsinz_dot = sign(sigz-X) * epsineq_dot ;

% Ecrouissage
if X==0 ; X=1e-12 ; end
if X0==0 ; X0=1e-12 ; end

Y0=C/g ; p=g  ;
Yet=Y0 + Yiso ;
X_dot = p * (Yet*epsinz_dot - (X) *epsineq_dot ) - rm*(abs(X)/X0)^m0*(X/abs(X))  ;
R_dot = b*(Q-R)*epsineq_dot ;
Yiso_dot    = bY*(Yisosat-Yiso)*epsineq_dot ;

A = [ 	 0 , 0 , 0 , 0 ; ...
	-1 , 0 , E , 0 ; ...
	 0 ,-1 , 1 , 1 ; ...
	 0 , 0 , 0 , 1	] ;

% asservissement

impose = [ 0 ; 0 ; 0 ; epsinz_dot ] ;

j=0 ;
for i=1:length(type_var)
    if strcmp(type_var(i),'asservi')==1
        j=j+1 ;
        A(j,i)  = 1 ;
        impose(j)=var_asservi_dot(i) ; 
    end
end   

var_dot = A \ impose ;  
var_dot = [var_dot ; epsineq_dot ; X_dot ; R_dot ; Yiso_dot ] ;