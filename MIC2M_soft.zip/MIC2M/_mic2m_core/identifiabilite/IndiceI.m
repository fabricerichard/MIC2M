function [I,Jb,delta,test_rupture]=IndiceI(P)

test_rupture = 0 ;
% parametres courants
parametres=P(:,1) ; save parametres.txt parametres -ascii ;
parametres

[s,ident,essais,model] = textread(['liste_experiences.txt'],'%s %s %s %s') ;
for i=2:length(s) 
    if strcmp( ident(i),'%')==0 
        nom_du_modele=char(model(i)) ;
    end
end

fid = fopen('nom_du_modele.txt','w');
for i=1:size(char(nom_du_modele),2)   ;  fprintf(fid,'%s',char(nom_du_modele(i))) ; end
fclose('all');

% lecture parametre
fich_parametre = [char(nom_du_modele),'_parametres'] ;
[nom_para,para_nom,a,b,loi,CV] = textread([fich_parametre,'.txt'],'%s %f %f %f %f %f') ;
if length(parametres)~=length(para_nom)
       disp('incoherence parametrique') ; 
       disp('fonction IndiceI') ; 
       pause
end
V=[parametres,a,b,loi,CV] ;

% calcul des sensibilites
[sensi]=derive1('fsensi',V,1) ;
eval(['save  sensi.txt sensi -ascii']) ;

N=size(V,1);
j=0;
for i=1:N
   if abs(V(i,3)-V(i,2))>0
      j=j+1;
      nbp(j)=i ;
   end
end
etude = nbp  ;

Npoint=size(sensi,1) ; npara=size(sensi,2) ;

for i = 1:npara
    deltam_sqr(i)  = 1 * norm((sensi(:,i)),2) ; %/N^.5 deja dans sensi
    deltam_abs(i)  = 1/N^.5 * norm((sensi(:,i)),1) ; %/N^.5 deja dans sensi
    deltam_mean(i) = N^.5 * mean(sensi(:,i)) ; %/N^.5 deja dans sensi
    deltam_max(i)  = N^.5 * max (sensi(:,i)) ; %/N^.5 deja dans sensi
    deltam_min(i)  = N^.5 * min (sensi(:,i)) ;  %/N^.5 deja dans sensi
end

delta = [deltam_sqr ; deltam_abs  ; deltam_mean ; deltam_max ; deltam_min] ;
%delta = deltam_sqr
%delta = deltam_abs
%delta = deltam_mean
%delta = deltam_max

% Indice I
Je(1)=1e10 ;
for i=round(Npoint/10):Npoint
    fisher=sensi(1:i,etude)'*sensi(1:i,etude) ; e=eig(fisher);
    Je(i)   = real(max(e)/min(e)) ; 
    detJe(i)= real(det(fisher)^(1/length(etude))) ;
    if Je(i)<1e-3 ;  Je(i)=1e10  ; end
    I(i) = log10(Je(i)) ;
end

% Indice Brun
Jb(1)=100 ; 
for i=round(Npoint/10):Npoint
    for u=1:npara
        sensit(1:i,u) = sensi(1:i,u)/norm(sensi(1:i,u)) ;
        deltam_abs(i,u)  = 1/N    * norm((sensi(1:i,u)),1) ;
    end
    rapport_deltam_abs(i)  = max(deltam_abs(i,:))./min(deltam_abs(i,:)) ;
    fishert=sensit(1:i,etude)'*sensit(1:i,etude);e=eig(fishert);
    Jb(i)=real(1/(min(e))^.5) ; detJb(i)=det(fishert)^(1/length(etude)) ;
    if Jb(i)<1e-3 ; Jb(i)=100 ;end ;
    if Jb(i)>100 ; Jb(i)=100  ;end
   
end