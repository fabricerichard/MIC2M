
clear all
load sensi.txt

etude=[ 1 2 3 ]

load J.txt
load P_LM.txt
J_LM=J;

N=size(sensi,1) ;
np=size(sensi,2) ;

JFab(1)=1e10 ;
for i=2:N
     for j=1:np
        A=J_LM(1:i,etude)'*J_LM(1:i,etude);
     end
     for k=1:np
        for l=1:np
             Ab(k,l)=A(k,l)/(A(k,k)*A(l,l))^0.5;
        end
     end
     
    e=eig(Ab);
    JFab(i)=real(max(e)/min(e)) ; detJFab(i)=real(det(Ab)^(1/length(etude))) ;
    if JFab(i)<1e-3 ;  JFab(i)=1e10  ; end
end

figure(2)
load temps.txt
%plot(temps,log10(Je)); hold on
plot(log10(JFab)); hold on
set(gca,'FontName','Times New Roman','fontsize',35)
%title('critere JE')
axis([0 length(JFab) 0 6])
%xlabel('% de l''essai','FontSize',35,'FontName','Times New Roman');
xlabel('nombre de mesures','FontSize',35,'FontName','Times New Roman');

ylabel('{log(J_F)}','FontSize',35,'FontName','Times New Roman');
axis square
box on
grid

[log10(min(JFab)) min(JFab)]



for i=1:size(sensi,2)
    for j=1:size(sensi,2)
        A=[J_LM(:,i) J_LM(:,j)]'*[J_LM(:,i) J_LM(:,j)]
        
        MACMatJF=[1 , A(1,2)/(A(1,1)*A(2,2))^0.5  ;  A(2,1)/(A(1,1)*A(2,2))^0.5 ,1] 
        
        e=eig(MACMatJF)
        pause
        MACJF(i,j)=max(eig(MACMatJF))/min(eig(MACMatJF))
        %if MACJe(i,j)>1000 ; MACJe(i,j)=1000 ; end
    end  
end
MACJF

figure(8)
[l c] = size(MACJF) ;
MACJF = [MACJF zeros(l,1)] ;
MACJF = [MACJF ; zeros(1,c+1)] ;
%[l c] = size(JFab) ;
colormap(cool) ;
colormap(gray(4))
pcolor(MACJF) ;
colorbar ;
title('JF matrix') ;
xlabel('parameter 2') ;
ylabel('parameter 1') ;
axis square    




