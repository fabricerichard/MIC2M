function LateXANOVA(Variance,Ftest,Ftheo,ddls,FSnedTest,NbParam)

fichierLATEX = fopen('ANOVA.tex','w+');
fprintf(fichierLATEX,'\\begin{center}\n');
fprintf(fichierLATEX,'\\begin{tabular}{|c|c|c|c|c|c|}\n');
fprintf(fichierLATEX,'\\hline\n');
Text = ['\\textbf{Facteur}& ',...
        '\\textbf{ddl} & \\textbf{Variance} &',...
        '\\textbf{F}${}_{\\textrm{\\textbf{Essais}}}$ &',...
        '\\textbf{F}${}_{\\textrm{\\textbf{Snedecor}}}$ &',...
        '\\textbf{R�sultats}\\\\\n'];
fprintf(fichierLATEX,Text);
fprintf(fichierLATEX,'\\hline\n');
min = 1;
max = 2*NbParam-1;
j=1;
k=2;
IterTot = size(Variance,2);
NbTotPI = NbParam*(NbParam-1)/2;
for i=1:1:NbParam
    fprintf(fichierLATEX,'%s & %i & %7.4f & %5.3f & %5.3f & %s \\\\\n',...
        char([64+i]),ddls(i),Variance(i),Ftest(i),...
        Ftheo(i),FSnedTest(i,:));
    fprintf(fichierLATEX,'\\hline\n');    
end
for i=(NbParam+1):1:(NbTotPI+NbParam)
    Text = [char([64+j]),char([64+k])];
    fprintf(fichierLATEX,'%s & %i & %7.4f & %5.3f & %5.3f & %s \\\\\n',...
        Text,ddls(i),Variance(i),Ftest(i),...
        Ftheo(i),FSnedTest(i,:));
     if((i<=max)&&(k<NbParam))
         k=k+1;
     else
         j=j+1;
         k=j+1;
         max = max+NbParam-j;
     end
    fprintf(fichierLATEX,'\\hline\n'); 
end
fprintf(fichierLATEX,'%s & %i & %7.4f & & & \\\\\n',...
        'R�sidu',ddls(end),Variance(end));
fprintf(fichierLATEX,'\\hline\n');
fprintf(fichierLATEX,'\\end{tabular}\n');
fprintf(fichierLATEX,'\\end{center}\n');
fclose(fichierLATEX);