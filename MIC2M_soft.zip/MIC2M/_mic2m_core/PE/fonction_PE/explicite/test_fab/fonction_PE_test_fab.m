function G = fonction_PE(nom_para,valeur_para,i)

assignation_para(nom_para,valeur_para) ;


G=E+NU+E*NU^2;
%G=E/2/(1+NU) ;
