function G = fonction_PE(nom_para,valeur_para,i)

assignation_para(nom_para,valeur_para) ;


I=b*h^3/12 ; 
G=F*L^3/3/E/I;

