function TraceParam(TExp,Name,NbParam,BVal)

% Trac�s des niveaux des param�tres


hTraceParam = figure('name','Trac�s des niveaux des param�tres',...
                     'NumberTitle','off');

hold on;
for i=1:1:NbParam
    subplot(ceil(NbParam/3),3,i)
    X = [-1 1];
    Y = [BVal(i,1) BVal(i,2)];
    plot(X,Y,'b');
    hold on;
    plot(X,Y,'or');
    titre = ['Facteur ',char([64+i])];
    title(titre,'Fontsize',10);
    xlabel('Niveau','Fontsize',8);
    ylabel(Name(i+1,:),'Fontsize',8);
    axis([-1 1 0.75*BVal(i,1) 1.25*BVal(i,2)]);
end

saveas(hTraceParam,'ParamNiveau.eps','psc2');