clear all

fprintf('Module Plans d''Exp�riences \n')
fprintf('S�bastien THIBAUD, Fabrice RICHARD\n')
fprintf('2010-\n')

% CHOIX PE 
liste_modele = textread(['liste_PE','.txt'],'%s') ;
disp(' ')
for i=1:size(liste_modele,1) ; disp(['(',num2str(i),')','  ',char(liste_modele(i))]) ; end  
disp(' ') ; 
choix = input('CHOIX : ') ; nom_du_modele = char(liste_modele(choix)) 


fid = fopen('nom_PE.txt','w');
for i=1:size(char(nom_du_modele),2)   ;  fprintf(fid,'%s',char(nom_du_modele(i))) ; end
fclose('all');
% lecture parametre
fich_parametre = [char(nom_du_modele),'_parametres'] ;

x='%s %f %f %f %f %f %f' ;
[nom_para,para_nom,a,b,ET,loi,q] = textread([fich_parametre,'.txt'],x) ;

V=[para_nom,a,b,ET,loi] ;
parametres=para_nom ;
% parametres courants
save parametres.txt parametres -ASCII ;



NbParam = length(nom_para) ;

Name = ['Nom_Param';nom_para] ;
Name = char(Name) ;
BVal = [a b] ;

%[NbParam Name BVal] = LireDataFile(DataFile)

NbEssais = 2^NbParam ;

% G�n�ration de la table des exp�riences
TExp = GeneTableExp(NbParam,NbEssais) ;

% Sauvevarde de la table des exp�riences au format texte
EcrireTableExp(TExp,Name);


%Tracer les graphes de variations limites des param�tres
TraceParam(TExp,Name,NbParam,BVal);

%Calculer les r�ponses
% Fonction � modifier selon les tests � r�aliser (simulations, essais, ...)
%

%Reponse = CalculReponse(TExp,NbParam,BVal);

Reponse = CalculReponse('fonction_PE',V,TExp) ;


% Calcul des effets

[EFB EFH] = EFactor(TExp,NbParam,Reponse);

[EIBB EIBH EIHB EIHH] = EInterFactor(TExp,NbParam,Reponse,EFB,EFH)

[Indice ParetoName IndPareto] = Pareto(EIBB,EIBH,EIHB,EIHH,EFB,EFH);

[Variance Ftest Ftheo ddls FSnedTest] = ANOVA(Reponse,...
                                            EIBB,EIBH,EIHB,EIHH,EFB,EFH);
[EIBBOpt,EIBHOpt,EIHBOpt,EIHHOpt,...
    EFBOpt,EFHOpt] = SimpModele(EIBB,EIBH,EIHB,EIHH,EFB,EFH,FSnedTest);

CreerModMat(EIBBOpt,EIBHOpt,EIHBOpt,EIHHOpt,EFBOpt,EFHOpt,BVal,Reponse);

CreerLatex(NbParam,Name,BVal,Reponse,EIBB,EIBH,EIHB,EIHH,EFB,EFH,...
           Variance,Ftest,Ftheo,ddls,FSnedTest);