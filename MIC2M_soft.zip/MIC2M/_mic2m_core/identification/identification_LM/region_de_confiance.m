function [cout,para,coutit,parait]=region_de_confiance(fonction,V,enregistrement)

N=size(V,1) ;

j=0;
for i=1:N
   if abs(V(i,3)-V(i,2))>0
      j=j+1 ;
      nbp(j)=i ;
   end
end
nbp ;
nbparam=length(nbp);

P0=V(nbp(:),1);

gra=zeros(nbparam,1);
hessian=zeros(nbparam,nbparam);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%								%
%			Identification				%
%								%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

P=P0 ;
DP=P ;

landa=0.001;
alpha=10;
dopage=0.000001;


[cout]=feval(fonction,V) ; neval=1 ;
historique_cout=[cout];
historique_para=[V(:,1)']; 
coutit=[neval cout] ; 
parait=[neval V(:,1)'] ; 
if enregistrement==1 
   eval(['save  historique_cout_LM.txt historique_cout -ascii']) ;
   eval(['save  historique_para_LM.txt historique_para -ascii']) ;
   eval(['save  coutit_LM.txt coutit -ascii']) ;
   eval(['save  parait_LM.txt parait -ascii']) ;
end
   
boucle=0;
while  norm(DP)/norm(P)>0.0000001
   
   boucle=boucle+1 ;
   if boucle>1 ; landa=landa/alpha ; end
   cout0=cout 
   P0=P ;
  
   % gradient
   for i=1:nbparam
      P=P0 ;
      P(i)=P0(i)*(1+dopage) ;
      V(nbp(:),1)=P ;
      [cout]=feval(fonction,V) ; neval=neval+1 ;
      historique_cout=[historique_cout;cout]; 
      historique_para=[historique_para;V(:,1)']; 
      if enregistrement==1       
         eval(['save  historique_cout_LM.txt historique_cout -ascii']) ;
         eval(['save  historique_para_LM.txt historique_para -ascii']) ;
      end
      gra(i,1)=(cout-cout0)/(P(i)-P0(i));
   end
   
   P=P0;
   
   if boucle==1 
      hessian=eye(nbparam);
   else
      s=P-Pold ;
      q=gra-graold ;
      hessian=hessian+(q*q')/(q'*s)-(hessian'*s*s'*hessian)/(s'*hessian*s) ;
   end
   
   coutold=cout ; graold=gra ; Pold=P ;
   
   hessian;
   gra;
   
   %	calcul d'un incr�ment de param�tres possible		%
   cout=cout0 ;
   while cout>=cout0 | cout==i
      
      P=P0;
      borne=0;

      A=hessian ; b=-gra;
      landa;
      
      for i=1:nbparam
         for j=1:nbparam
            Ab(i,j)=A(i,j)/(A(i,i)*A(j,j))^0.5;
         end
         bb(i,1)=b(i,1)/(A(i,i))^0.5;
      end
      DPb=inv(Ab+landa*eye(nbparam))*bb ;
      
      for i=1:nbparam ; DP(i,1)=DPb(i,1)/(A(i,i))^0.5 ; end
      
      for l=1:nbparam ; P(l)=P0(l)+DP(l) ; end
      
      
      %	v�rification de la qualit� de la solution		%
      borne=0;
      for l=1:nbparam
            if P(l)>V(nbp(l),3) | P(l)<V(nbp(l),2)  ; borne =1 ; end  
      end
      
      if borne==1 ; landa=landa*alpha; end

      if borne==0
         V(nbp(:),1)=P;
         if enregistrement==1
            P_LM=V(:,1);
            eval(['save  P_LM.txt P_LM -ascii']) ;
         end
         [cout]=feval(fonction,V) ;
         neval=neval+1 ;
         historique_cout=[historique_cout;cout]; 
         historique_para=[historique_para;V(:,1)']; 
         if enregistrement==1 
            eval(['save  historique_cout_LM.txt historique_cout -ascii']) ;
            eval(['save  historique_para_LM.txt historique_para -ascii']) ;
         end
         if cout>=cout0 | cout==i ; landa=landa*alpha ; end
      end
        
   end
   
   for l=1:nbparam ;  V(nbp(l),1)=P(l);   end
   
   coutit(boucle+1,:)=[neval cout];
   parait(boucle+1,:)=[neval V(:,1)'];
   
   fin=(cout0-cout)/cout0;
   
   if enregistrement==1 
      eval(['save  parait_LM.txt parait -ascii']) ;
      eval(['save  coutit_LM.txt coutit -ascii']) ;
      eval(['save  meilleur_LM.txt V -ascii']) ;
   end
   
   
end

[cout ligne]=min(coutit(:,2)) ; para=parait(ligne,2:N+1)  ;

cout=real(cout) ;
para=real(para);

coutit=real(coutit);
parait=real(parait);



