function []=identification_batch(choix_modele,choix_optim)

k_iteration = 1 ; save k_iteration.txt k_iteration -ascii ; % initialisation du compteur

% CHOIX DU MODELE 
liste_modele = textread(['liste_modele','.txt'],'%s') ;
disp(' ')
for i=1:size(liste_modele,1) ; disp(['(',num2str(i),')','  ',char(liste_modele(i))]) ; end  
disp(' ') ; 
%choix = input('CHOIX : ') ; nom_du_modele = char(liste_modele(choix)) 
nom_du_modele = char(liste_modele(choix_modele))

fid = fopen('nom_du_modele.txt','w');
for i=1:size(char(nom_du_modele),2)   ;  fprintf(fid,'%s',char(nom_du_modele(i))) ; end
fclose('all');
% lecture parametre
fich_parametre = [char(nom_du_modele),'_parametres'] ;
[nom_para,para_nom,a,b,loi,CV] = textread([fich_parametre,'.txt'],'%s %f %f %f %f %f') ;
V=[para_nom,a,b,loi,CV] ;


% CHOIX DU MODELE DE RESOLUTION
liste_resolution = textread(['liste_resolution','.txt'],'%s') ;
disp(' ')
for i=1:size(liste_resolution,1) ; disp(['(',num2str(i),')','  ',char(liste_resolution(i))]) ; end  
disp(' ') ; 
%choix = input('CHOIX : ') ; nom_resolution = char(liste_resolution(choix)) 
nom_resolution = char(liste_resolution(choix_optim))

fid = fopen('methode de resolution.txt','w');

if strcmp(nom_resolution,'levenberg_marquardt')==1 ;
%minimisation de la fonction cout_LM
[S,meilleur_para,Sit,parait]=levenberg_marquardt('ferreur_LM',V,1) ;
%plot(Sit(:,1),Sit(:,2))
end 

if strcmp(nom_resolution,'algorithme_genetique')==1 | strcmp(nom_resolution,'hybride')==1;
%minimisation de la fonction cout_algge
[bestindiv,besterreur]=algorithme_genetique('ferreur_genetique',V) ;
%[S,meilleur_para,Sit,parait]=levenberg_marquardt('ferreur_LM',V,1) ;
end

quit
