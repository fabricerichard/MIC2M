function G=fonction_def(nom_para,valeur_para)


assignation_para(nom_para,valeur_para) ;

valeur_para
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ECRITURE DU FICHIER ANSYS inputansys.txt %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

fich_commande = 'input_ansys_initiation.txt' 

disp('traitement fichier commande')
B = remplace(fich_commande,'################','%16.10e',nom_para,valeur_para);


fid = fopen('inputansys.txt','w') ;
for i=1:size(B,1)   
    fprintf(fid,'%s\n',char(B(i))) ;
end
fclose('all');

%%%%%%%%%%%%%%%%%%%
% LANCEMENT ANSYS %
%%%%%%%%%%%%%%%%%%%
%sortie =0 ; save  sortie.txt sortie -ascii

%! "C:\Program Files\Ansys Inc\V70\ANSYS\bin\intel\ansys70.exe" -b -i inputansys.txt -o outputname
%! "C:\Program Files\Ansys Inc\V80\ANSYS\bin\intel\ansys80" -b -i inputansys.txt -o outputname -m 64 -db 64
%! "G:\a3p\Ansys Inc\V90\ANSYS\bin\intel\ansys90" -b -i inputansys.txt -o outputname -m 64 -db 64
! "C:\Program Files\ANSYS Inc\v145\ANSYS\bin\Intel\ansys145.exe"  -p aa_t_i -dir "C:\MIC2M" -j "file" -s read -l en-us -b -i "C:\MIC2M\inputansys.txt" -o "C:\MIC2M\file.out"   

%%%%%%%%%%%%%%%%%%%%%
% RECUPERATION DE G %
%%%%%%%%%%%%%%%%%%%%%
PAR = textread(['sortie.txt'],'%s','whitespace',',') 
G=char(PAR(7))  ;
G=str2num(G) 

