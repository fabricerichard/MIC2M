function [temps,sortie,test_rupture,aux]=lecture(nom_modele,nom_para,para,fich_entree,fich_var)

% lecture du fichier variables
[num_var,nom_var,var_0] = textread([fich_var,'.txt'],'%f %s %f') ;

% lecture du fichier entree
A = textread([fich_entree,'.txt'],'%s') ;
ncolonne=str2num(char(A(1)))  ; nligne=size(A,1)/ncolonne-2 ;

for i=2:ncolonne ; type_entree(i-1)=A(i) ; end
for i=ncolonne+2:2*ncolonne ; nom_entree(i-ncolonne-1)=A(i) ; end
l=2*ncolonne ; for i=1:nligne ; for j=1:ncolonne ; l=l+1 ; entree(i,j)=str2num(char(A(l))) ; end ; end
temps=entree(:,1) ; entree=entree(:,2:ncolonne) ;

assignation_entree(nom_entree,entree)
type_var = type_variable(nom_var,type_entree,nom_entree) ;

[nom_var,type_var]
[nom_entree;type_entree]
nligne
pause

[temps,sortie,test_rupture,aux]=calcul(nom_modele,nom_para,para,type_var,num_var,nom_var,var_0,type_entree,nom_entree,entree,temps,nligne) ;

sortie
assignation_sortie(nom_var,sortie)

