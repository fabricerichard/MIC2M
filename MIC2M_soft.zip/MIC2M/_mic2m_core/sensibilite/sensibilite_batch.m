function []=sensibilite_batch(choix_modeles)

% CHOIX DU MODELE 
%liste_modele = textread(['liste_modele','.txt'],'%s') ;
%disp(' ')
%for i=1:size(liste_modele,1) ; disp(['(',num2str(i),')','  ',char(liste_modele(i))]) ; end  
%disp(' ') ; 
%choix = input('CHOIX : ') ;
%nom_du_modele = char(liste_modele(choix_modeles)) 

%fid = fopen('nom_du_modele.txt','w');
%for i=1:size(char(nom_du_modele),2)   ;  fprintf(fid,'%s',char(nom_du_modele(i))) ; end
%fclose('all');
[s,ident,essais,model] = textread(['liste_experiences.txt'],'%s %s %s %s') ;
    for i=2:length(s) 
        if strcmp( ident(i),'%')==0
            nom_du_modele=char(model(i)) ;
        end
    end
% lecture parametre
fich_parametre = [char(nom_du_modele),'_parametres'] ;
[nom_para,para_nom,a,b,loi,CV] = textread([fich_parametre,'.txt'],'%s %f %f %f %f %f') ;
V=[para_nom,a,b,loi,CV] ;


% CHOIX DU MODELE DE RESOLUTION

[sensi]=derive1('fsensi',V,1) ;
%plot(Sit(:,1),Sit(:,2))
eval(['save  sensi.txt sensi -ascii']) ;

N=size(sensi,1) ;
np=size(sensi,2) ;

sensi=(sensi(2:N,:));
fisher=sensi'*sensi;
N=N-1;

for i = 1:np
    deltam_sqr(i)  = 1/N^.5 * norm((sensi(:,i)),2) ;
    deltam_abs(i)  = 1/N    * norm((sensi(:,i)),1) ;
    deltam_mean(i) = 1/N    * mean(sensi(:,i)) ;
    deltam_max(i)  = max (sensi(:,i)) ;
    deltam_min(i)  = min (sensi(:,i)) ;  
end

delta = [deltam_sqr ; deltam_abs ;  ; deltam_mean ; deltam_max ; deltam_min]

deltam_abs

bar(deltam_abs)

%plot(sensi)
hold on
quit




