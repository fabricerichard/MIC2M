function Bwqz=remplace(fich_commande,dwqz,format,nom_para,valeur_para)


assignation_para(nom_para,valeur_para) ;

awqz=textread(fich_commande,'%s','delimiter','\n','whitespace','') ; Bwqz=awqz(1:size(awqz,1),:) ;

for i=1:size(nom_para,1)
    fwqz=16-length(char(nom_para(i))) ;
    ptpwqz=[dwqz(1:fwqz),char(nom_para(i))]  ;
    tpwqz = fopen('tpwqz','w');fprintf(tpwqz,format,valeur_para(i)) ; fclose(tpwqz) ; tpwqz=textread('tpwqz','%s','delimiter','\n','whitespace','') ; fclose('all') ; delete tpwqz ;
    Bwqz = strrep(Bwqz,ptpwqz,tpwqz);
end
