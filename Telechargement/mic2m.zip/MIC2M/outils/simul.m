function [temps,sortie,test_rupture,aux]=simul(fich_essai,mode)

%mode='i'


nom_du_modele = textread(['nom du mod�le','.txt'],'%s') ;
nom_modele = [char(nom_du_modele),'_dot'] ;
fich_parametre = [char(nom_du_modele),'_parametres'] ;
fich_variable =  [char(nom_du_modele),'_variables'] ;

% lecture parametre
[nom_para,para_nom,a,b,loi,para_opt] = textread([fich_parametre,'.txt'],'%s %f %f %f %f %s') ;
load parametres.txt;
para_nom= parametres;

% lecture du fichier variables
[num_var,nom_var,var_0,graph] = textread([fich_variable,'.txt'],'%f %s %f %s') ;

% lecture du fichier essai
[temps,nom_entree,type_entree,entree]=lecture_fichier_essais(fich_essai) ;
assignation_entree(temps,nom_entree,entree)
nligne=length(temps);

type_var = type_variable(nom_var,type_entree,nom_entree) ;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[nom_var,type_var];
[nom_entree;type_entree];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

disp(' ')
disp(['nom du fichier essai : ',fich_essai])

fprintf('variables asservies : ') ; 
for i=1:length(type_var) ; if strcmp(type_var(i),'asservi')==1 ; fprintf('%s  ',char(nom_var(i))) ; end ; end
disp(' ')
fprintf('variables observ�es : ') 
for i=1:length(type_var) ; if strcmp(type_var(i),'observe')==1 ; fprintf('%s  ',char(nom_var(i))) ; end ; end
disp(' ')
fprintf('variables autres : ') 
for i=1:length(type_var) ; 
    if strcmp(type_var(i),'asservi')==0 & strcmp(type_var(i),'observe')==0 ; fprintf('%s  ',char(nom_var(i))) ;  end 
end
disp(' ')
disp(['nombre d''incr�ments de calcul : ',num2str(nligne)])
  

ndm=char(nom_du_modele) ;
if strcmp(ndm(1:3),'EF_')==1
    dopage=1e-3; save dopage.txt dopage -ASCII ;
    [temps,sortie,test_rupture,aux]=feval( ['calcul_',ndm],nom_modele,nom_para,para_nom,type_var,num_var,nom_var,var_0,type_entree,nom_entree,entree,temps,nligne,mode) ; 
else
    dopage=1e-4; save dopage.txt dopage -ASCII ;
    [temps,sortie,test_rupture,aux]=calcul(nom_modele,nom_para,para_nom,type_var,num_var,nom_var,var_0,type_entree,nom_entree,entree,temps,nligne,mode) ;
end

disp(' ')

%sortie
assignation_sortie(nom_var,sortie) ;

