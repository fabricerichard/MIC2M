cd ..

rand('state',sum(100*clock))

fprintf('PMM-tools \n')

fprintf('Fabrice RICHARD\n')
fprintf('2003\n\n\n')


fprintf('Creation des PATH \t')

addpath(GENPATH(pwd))

clear all