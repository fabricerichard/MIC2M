function assignation_var_asservi_dot(nom_var,var_asservi_dot)
% assigne a la chaine de caracteres nom_para(i) la valeur valeur_para(i)
% dans la fonction appelante

for i=1:size(nom_var,1) ; 
   nom=[char(nom_var(i)),'_dot'] ;
   if strcmp(var_asservi_dot(i),'?')==0
   	assignin('caller',nom,var_asservi_dot(i)) ;
   end
end