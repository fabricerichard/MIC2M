function  [Dt,Dvar,test_rupture,aux]=R_Kutta(nom_modele,nom_para,para,type_var,num_var,nom_var,var,var_asservi_dot,t,Dt,mode)

test_rupture=0 ;
var0  = var ;
VAR(1,:)=var0';

%[T,VAR] = ODE113(nom_modele,[t t+Dt],var0,[],nom_para,para,type_var,num_var,nom_var,var_asservi_dot); 
[T,VAR] = ODE15s(nom_modele,[t t+Dt],var0,[],nom_para,para,type_var,num_var,nom_var,var_asservi_dot); 
%[T,VAR] = ODE23s(nom_modele,[t t+Dt],var0,[],nom_para,para,type_var,num_var,nom_var,var_asservi_dot); 
%[T,VAR] = ODE87(nom_modele,[t t+Dt],var0,[],nom_para,para,type_var,num_var,nom_var,var_asservi_dot); 



% test_rupture=0;
% toler = 0.005 ; % 0.005
% ht    = Dt ; hmax  = Dt ;
% h     = hmax/100 ; %/100
% tau   = 0 ;
% i=1;T(1)=t;

% % Runge-Kutta
% while (tau+h<=ht)&(tau+h>tau)&(test_rupture<1);
%   [y1,test_rupture,aux]=feval(nom_modele,nom_para,para,type_var,num_var,nom_var,var,var_asservi_dot,h) ;
%   [y2,test_rupture,aux]=feval(nom_modele,nom_para,para,type_var,num_var,nom_var,var+h*y1,var_asservi_dot,h) ;
%   [y3,test_rupture,aux]=feval(nom_modele,nom_para,para,type_var,num_var,nom_var,var+h*(y1+y2)/4,var_asservi_dot,h);
%   % estimation de l'erreur
% 	err=norm(h*(y1-2*y3+4*y2)/3,'inf') ; tol=toler*max(norm(var,'inf'),1.0) ;
% 	% test de la solution
% 	if err<tol ; 
%         i=i+1; 
%         tau=tau+h ;
%         T(i)=t+tau ;
%         var=var+h*(y1+4*y3+y2)/6 ;
%         VAR(i,:)=var';
%     end
%   % test du pas
%   if err ~=0.0 & test_rupture<1 ; h=min(hmax,.9*h*(tol/err)^1/3) ;end
% 	% reduction du pas si besoin
% 	if tau+h>ht & test_rupture<1 ; h=ht-tau ;  end
% end



% inbt�gration bourrin
% h=Dt/10000 ;
% while (tau+h<=ht)&(tau+h>tau)&(test_rupture<1);
%   [y1,test_rupture,aux]=feval(nom_modele,nom_para,para,type_var,num_var,nom_var,var,var_asservi_dot,tau) ;
%         i=i+1; 
%         tau=tau+h ;
%         T(i)=t+tau ;
%         var=var+h*y1;
%         VAR(i,:)=var';
% end




%
n=length(T) ;

if strcmp(mode,'i')==1
	Dvar=VAR(n,:)'-var0 ;
   Dt=T(n)-t ;
   aux=NaN;
end
if strcmp(mode,'s')==1
   for i=1:n
		Dvar(i,:)=VAR(i,:)-var0' ;
      Dt(i,1)=T(i)-t ;
   end
   aux=NaN*ones(n,1);
end


