function [cout,para,coutit,parait]=LS(fonction,V,enregistrement)

ARRET=1e-3 ; % ( � diminuer pour un crit�re d'arret + s�v�re : 1e-4 par exemple )

enregistrement=1;

N=size(V,1);
j=0;
for i=1:N
   if abs(V(i,3)-V(i,2))>0
      j=j+1;
      nbp(j)=i ;
   end
end
nbp 
nbparam=length(nbp);
P0=V(nbp(:),1);

V(nbp(:),:) ;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%								%
%			Identification		%
%								%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

P=P0 ;
DP=P ;

landa=0.001;
alpha=10;
%dopage=1e-4;
[cout]=feval(fonction,V) ; neval=1 ;
load dopage.txt ;
S=(cout'*cout)/2 ;
historique_cout=[S];
historique_para=[V(:,1)']; 

coutit=[neval S] ; 
parait=[neval V(:,1)'] ; 
if enregistrement==1 
   eval(['save  historique_cout_LM.txt historique_cout -ascii']) ;
   eval(['save  historique_para_LM.txt historique_para -ascii']) ;
   eval(['save  coutit_LM.txt coutit -ascii']) ;
   eval(['save  parait_LM.txt parait -ascii']) ;
end

boucle=0;
NORMP = norm(P) ; if NORMP==0 ; NORMP=1e-12 ; end
NORMDP = norm(DP) ; if NORMDP==0 ; NORMDP=1e-12 ; end
S0=S;
S=S0-.01*S0;

while  (NORMDP/NORMP>ARRET) | (abs(S-S0)/S0>ARRET)

	if nbparam>1
   	c=[0];
      	for i=1:nbparam
           	if V(nbp(i),2)~=0 & V(nbp(i),3)~=0
          		if abs((P(i)-V(nbp(i),2))/V(nbp(i),2))<1e-4 ; 
           			V(nbp(i),1)=V(nbp(i),2) ; V(nbp(i),3)=V(nbp(i),2) ;
           		end
        			if abs((P(i)-V(nbp(i),3))/V(nbp(i),3))<1e-4
          			V(nbp(i),1)=V(nbp(i),3) ; V(nbp(i),2)=V(nbp(i),3) ;
            	end
            	if abs((P(i)-V(nbp(i),2))/V(nbp(i),2))>=1e-4 & abs((P(i)-V(nbp(i),3))/V(nbp(i),3))>=1e-4
            		V(nbp(i),1)=P(i) ;  c=[c,i] ;
            	end
           	end
  	 		end
  	 	c=c(2:length(c)) ;
   	N=size(V,1);
      j=0; clear nbp
      
		for i=1:N
  	 		if abs(V(i,3)-V(i,2))>0
      		j=j+1 ; nbp(j)=i ;
   		end
		end
     	if j==0
        	disp('toutes les bornes atteintes') ; 
        	[cout]=feval(fonction,V) ; neval=neval+1 ;
        	S=(cout'*cout)/2 ;
     		historique_cout=[historique_cout;S]; 
        	historique_para=[historique_para;V(:,1)']; 
        	cout=S ;
        	para=V(:,1)  ;
        	coutit(boucle+1,:)=[neval S];
   		    parait(boucle+1,:)=[neval V(:,1)'];
     		if enregistrement==1       
    			eval(['save  historique_cout_LM.txt historique_cout -ascii']) ;
                eval(['save  historique_para_LM.txt historique_para -ascii']) ;
                eval(['save  parait_LM.txt parait -ascii']) ;
      		    eval(['save  coutit_LM.txt coutit -ascii']) ;
      		    eval(['save  meilleur_LM.txt V -ascii']) ;
            end
        	return
      end
		nbparam=length(nbp);
   	P=V(nbp(:),1);
   end
   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
       
   boucle=boucle+1 ;
   if boucle>1 ; landa=landa/alpha ; end
   cout0=cout ;
   S0=S ;
   P0=P ;
   
   % gradient
   clear J ; 
   for i=1:nbparam
      P=P0 ;
      P(i)=P0(i)*(1+dopage);
      if P(i)==0 ; P(i)=dopage ; end
      V(nbp(:),1)=P ;
      [cout]=feval(fonction,V) ; neval=neval+1 ;
      S=(cout'*cout)/2 ;
      historique_cout=[historique_cout;S]; 
      historique_para=[historique_para;V(:,1)']; 
      if enregistrement==1       
         eval(['save  historique_cout_LM.txt historique_cout -ascii']) ;
         eval(['save  historique_para_LM.txt historique_para -ascii']) ;
      end
      J(:,i)=(cout-cout0)/(P(i)-P0(i));
   end
   hessian=J'*J ;
   gra=J'*cout0 ;
   A=hessian ; b=-gra;
   
   %	calcul d'un incr�ment de param�tres possible		%
   S=S0 ; testrup=0 ;borne=0; 
   while S>=S0 | testrup==1 | borne==1
      
      testrup=0 ;
      P=P0;
      borne=0;     
      
      clear Ab bb DP P
      for i=1:nbparam
         for j=1:nbparam
            Ab(i,j)=A(i,j)/(A(i,i)*A(j,j))^0.5;
         end
         bb(i,1)=b(i,1)/(A(i,i))^0.5;
      end
      DPb=inv(Ab+landa*eye(nbparam))*bb ;
      
      for i=1:nbparam ; DP(i,1)=DPb(i,1)/(A(i,i))^0.5 ; end
      for l=1:nbparam ; P(l)=P0(l)+DP(l) ; end
      
      %	v�rification de la qualit� de la solution		%
      for l=1:nbparam
         if P(l)>V(nbp(l),3) | P(l)<V(nbp(l),2) ; borne =1 ; end	
      end

		if borne==0
        	V(nbp(:),1)=P(:);
         if enregistrement==1
            P_LM=V(:,1);
            eval(['save  P_LM.txt P_LM -ascii']) ;
         end
         [cout,testrup]=feval(fonction,V) ; neval=neval+1 ;
         S=(cout'*cout)/2 ;
         if testrup==0
         	historique_cout=[historique_cout;S]; 
         	historique_para=[historique_para;V(:,1)']; 
         	if enregistrement==1 
           	 	eval(['save  historique_cout_LM.txt historique_cout -ascii']) ;
            	eval(['save  historique_para_LM.txt historique_para -ascii']) ;
         	end
         end
      end
    	if borne==1 | (testrup==1 & borne==0) | S>=S0 ; landa=landa*alpha ; end
   end
   
   for l=1:nbparam ; V(nbp(l),1)=P(l) ; end
   
   coutit(boucle+1,:)=[neval S];
   parait(boucle+1,:)=[neval V(:,1)'];
   
   
   if enregistrement==1 
      eval(['save  parait_LM.txt parait -ascii']) ;
      eval(['save  coutit_LM.txt coutit -ascii']) ;
      eval(['save  meilleur_LM.txt V -ascii']) ;
   end

 
   NORMP = norm(P) ; 
   NORMDP = norm(DP) ;

NORMDP/NORMP;
abs(S-S0)/S0;

end

[cout ligne]=min(coutit(:,2)) ; para=parait(ligne,2:N+1)  ;

cout=real(cout) ;
para=real(para);

coutit=real(coutit);
parait=real(parait);



