function [temps,nom_entree,type_entree,entree]=lecture_fichier_essais(fich_essai)

A = textread([fich_essai,'.txt'],'%s') ;
ncolonne=str2num(char(A(1)))  ; nligne=size(A,1)/ncolonne-2 ;

for i=2:ncolonne ; type_entree(i-1)=A(i) ; end
for i=ncolonne+2:2*ncolonne ; nom_entree(i-ncolonne-1)=A(i) ; end

l=2*ncolonne ;
for i=1:nligne ; 
   for j=1:ncolonne ; l=l+1 ;  

       if strcmp(char(A(l)),'?')==1 
           entree(i,j)=0;
       else
           entree(i,j)=str2num(char(A(l)));
       end    
       
   end 
end
type_entree;
temps=entree(:,1)  ;
entree=entree(:,2:ncolonne) ;

