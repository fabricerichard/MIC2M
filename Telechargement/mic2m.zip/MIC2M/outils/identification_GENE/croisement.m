function [nouveaux_gen] = croisement(vieux_gen,Pc)
% operateur genetique de croisement
% cree nouveaux_gen a partir de vieux_gen
% Pc: probabilite de croisement
% Fabrice RICHARD (1998)

nindividu=size(vieux_gen,1);
ngene = size(vieux_gen,2);

used=0;

matrice=ones(nindividu) ;
for i=1:nindividu
   matrice(i,i)=0;
end

matrice;


for ncouple = 1:nindividu/2
   ok=0;
   while ok==0
      couple(ncouple,:)=[1+fix(rand(1)*nindividu),1+fix(rand(1)*nindividu)];
      ok=1 ;
      if matrice(couple(ncouple,1),couple(ncouple,2))==0 
         ok=0 ; 
      end
   end
   matrice(couple(ncouple,1),1:nindividu)=0  ;
   matrice(couple(ncouple,2),1:nindividu)=0  ; 
   matrice(1:nindividu,couple(ncouple,1))=0  ;
   matrice(1:nindividu,couple(ncouple,2))=0  ;
end 



%for ncouple = 1:nindividu/2
%   ok=0;
 %  while ok==0
 %     couple(ncouple,:)=[1+fix(rand(1)*nindividu),1+fix(rand(1)*nindividu)];
 %     ok=1 ;
  %    if couple(ncouple,1)==couple(ncouple,2) ; ok=0 ; end
  %    for i=1:length(used)
      %   if used(i)==couple(ncouple,1) | used(i)==couple(ncouple,2) ; ok=0 ; end
     % end
   %end
   %used=[used,couple(ncouple,1),couple(ncouple,2)] ;  
%end 

couple;

for i = 1:nindividu/2
  
   if rand(1)<Pc
      a=rand(1);
      for j = 1:ngene;
         nouveaux_gen(i,j) = a*vieux_gen(couple(i,1),j)+(1-a)*vieux_gen(couple(i,2),j) ;
         nouveaux_gen(i+nindividu/2,j) = (1-a)*vieux_gen(couple(i,1),j)+a*vieux_gen(couple(i,2),j) ;
      end
   else
      nouveaux_gen(i,:) = vieux_gen(couple(i,1),:) ;
      nouveaux_gen(i+nindividu/2,:) = vieux_gen(couple(i,2),:) ;
   end
   
end
      


