function historique(individu,generation,X,err,nomw)

% historique

if individu==1 & generation==0 ;
   historique_parametre=X ;
   historique_erreur=err ;
else
   nom=['historique_parametre_','genetique',nomw] ; eval(['load ',nom]) ; historique_parametre=eval(nom) ;
   nom=['historique_erreur_','genetique',nomw] ; eval(['load ',nom]) ; historique_erreur=eval(nom) ;
   historique_parametre=[historique_parametre;X] ;
   historique_erreur=[historique_erreur;err] ;
end

eval(['save ',['historique_parametre_','genetique',nomw],' historique_parametre -ascii -double -tabs']) ;
eval(['save ',['historique_erreur_','genetique',nomw],' historique_erreur -ascii -double -tabs']) ;

