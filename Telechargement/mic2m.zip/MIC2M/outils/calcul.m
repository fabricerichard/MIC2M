function [time,sortie,test_rupture,sortie_aux]=calcul(nom_modele,nom_para,para,type_var,num_var,nom_var,var_0,type_entree,nom_entree,entree,temps,nligne,mode)
%mode='i';
% initialisation
var_ini  = var_initiale(nom_var,type_entree,nom_entree,entree,var_0) ;
var      = var_ini ;
sortie   = var' ;   
time = temps(1) ;

%calcul
for i=1:nligne-1
   fprintf('%i, ',i) ;
   t = temps(i) ;
   [Dvar_asservi,Dt]=var_increment(type_var,nom_var,var,type_entree,nom_entree,entree,temps,t) ;
   [Dt,Dvar,test_rupture,aux]=calcul_Dvar(nom_modele,nom_para,para,type_var,num_var,nom_var,var,Dvar_asservi,t,Dt,mode) ;
   
   if strcmp(mode,'i')==1
   	time = [time ; t+Dt ] ;
      var = var + Dvar ;
      sortie_aux(size(sortie,1)+1,:)=aux ;
      sortie=[sortie ; var'] ; 
   end
   
   if strcmp(mode,'s')==1
      time = [time ; t+Dt ] ;
      sortie_aux(size(sortie,1)+1:size(sortie,1)+size(aux,1),:)=aux;
      for i=1:length(Dt)
         sortie=[sortie;( var' + Dvar(i,:) )]  ;
      end
      var = var + Dvar(length(Dt),:)' ;
   end
   
 end

sortie_aux(1,:)=ones(1,size(aux,2))*NaN ;

