function [nf,nbtirage,Pf]=montecarlo(fonction_def,V,enregistrement)

nlancers = input('nombre de lancers : ')

% nombre de variables
N=size(V,1) ;
% moyennes
moy =V(:,1) ;
% �cart types
ET = V(:,4) ;

x=moy ; % initialisation des varialbes physiques

% identifiaction des variables al�atoires
j=0;
for i=1:N
   if ET(i)>0
      j=j+1;
      nbp(j)=i ;
   end
end
% position des variables al�atoires
nbp ; 
nbparam=length(nbp) ; % nombre de variables al�atoires

nf=0 ; % initialisation des d�faillances
for nbtirage=1:nlancers
    for i=1:nbparam
        % tirage d'une realisation suivant une gaussienne standard (�cart type = 1
        % et moyenne = 0
        y=Pf2indice(rand(1)) ;
        % variable dans l'espace physique
        x(nbp(i))=y*ET(nbp(i))+moy(nbp(i)) ;
    end
    x;
    G=feval(fonction_def,x);
    %plot(x(1),x(2))

    if G<0 nf=nf+1 ; end
end

Pf=nf/nbtirage ;
