function [beta,alpha,betait,alphait,v]=rackwitz(fonction_def,V,enregistrement)


%load dopage.txt
dopage=1e-3; disp('ATTENTION : d�riv�e num�rique � 1e-4')
ARRET=dopage ; % ( � diminuer pour un crit�re d'arret + s�v�re )


N=size(V,1);

moy =V(:,1) ;
ET = V(:,4) ;


V(:,2)=zeros(N,1) ; % bloquage de l'espace du hasard
V(:,3)=zeros(N,1) ;

j=0;
for i=1:N
   if ET(i)>0
      j=j+1;
      nbp(j)=i ;
   end
end

nbparam=length(nbp);
P0=V(nbp(:),1);

gene=zeros(2*N,1);

gradg=zeros(nbparam,1);
alphasol=zeros(1,N);

% point initial
y=zeros(nbparam,1) ;
beta=norm(y) ;

v=feval('invP',V,gene,beta) ;

g=feval(fonction_def,v);
alphait=[0 zeros(1,N)];
betait=[0 beta];

ok=1 ; premier=1 ; boucle=0 ;

while ok==1
   
   boucle=boucle+1;
   
   % calcul du gradient
   for i=1:nbparam
      
      yy=y ;
      if boucle==1 | yy(i)==0
         dx=dopage ;
      else
         dx=dopage*yy(i) ;
      end
      
      yy(i)=yy(i)+dx ;
      betabeta=norm(yy) ;
      alphaalpha=yy/betabeta ;
      for l=1:nbparam ; gene(N+nbp(l))=alphaalpha(l) ; end

      v=feval('invP',V,gene,betabeta) ;

      newg=feval(fonction_def,v);
      
      gradg(i)=(newg-g)/dx ;

      
   end
% y
% g
% gradg
% pause
      yyy=y;
      
   for i=1:nbparam
       if boucle<4

  
           y(i)=1*(1/(norm(gradg))^2) * ( gradg'*yyy-g ) * gradg(i);

       else
            y(i)=(1/(norm(gradg))^2) * ( gradg'*yyy-g ) * gradg(i);   
       end
   end

   %if abs(norm(y)-beta)<0.01 ; ok=0 ; end
   if abs(norm(y)-beta)<ARRET ; ok=0 ; end
   
   beta=norm(y) ; alpha=y/beta ;
   
   for l=1:nbparam
         gene(N+nbp(l))=alpha(l) ;
   end

   v=feval('invP',V,gene,beta) ;

   save v.txt v -ascii ;
   g=feval(fonction_def,v);

   premier==0 ;
   betait(boucle+1,:)=[1+boucle+boucle*nbparam,beta];
   
   for i=1:nbparam
      alphait(boucle+1,1) =1+boucle+boucle*nbparam;
      alphait(boucle+1,1+nbp(i)) =-alpha(i);
   end
   
   eval(['save  betait_RF.txt betait -ascii']) ;
   eval(['save  alphait_RF.txt alphait -ascii']) ;
   
end


alpha=alphait(size(alphait,1),2:size(alphait,2))' ;



  
