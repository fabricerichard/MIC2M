clear all

%nom_du_modele = textread(['nom du mod�le','.txt'],'%s') ;

% CHOIX DU MODELE 
liste_modele = textread(['liste_defaillance','.txt'],'%s') ;
disp(' ')
for i=1:size(liste_modele,1) ; disp(['(',num2str(i),')','  ',char(liste_modele(i))]) ; end  
disp(' ') ; 
choix = input('CHOIX : ') ; nom_du_modele = char(liste_modele(choix)) 

fid = fopen('nom_defaillance.txt','w');
for i=1:size(char(nom_du_modele),2)   ;  fprintf(fid,'%s',char(nom_du_modele(i))) ; end
fclose('all');
% lecture parametre
fich_parametre = [char(nom_du_modele),'_parametres'] ;

x='%s %f %f %f %f %f %f' ;
[nom_para,para_nom,a,b,ET,loi,q] = textread([fich_parametre,'.txt'],x) ;

V=[para_nom,a,b,ET,loi] ;
parametres=para_nom ;
% parametres courants
save parametres.txt parametres -ASCII ;


% CHOIX DU MODELE DE RESOLUTION
liste_resolution = textread(['liste_modele_fiabilite','.txt'],'%s') ;
disp(' ')
for i=1:size(liste_resolution,1) ; disp(['(',num2str(i),')','  ',char(liste_resolution(i))]) ; end  
disp(' ') ; 
choix = input('CHOIX : ') ; nom_resolution = char(liste_resolution(choix)) 

fid = fopen('algorithme fiabilite.txt','w');


format long
if strcmp(nom_resolution,'Rackwitz')==1 ;
    [beta,alpha,betait,alphait,Pet]=rackwitz('fonction_def',V,1) ;
    betait
    alphait
    Pet
    %indice2Pf(beta)
    %plot(Sit(:,1),Sit(:,2))
end 
if strcmp(nom_resolution,'MonteCarlo')==1 ;
    
    [nf,n,Pf]=montecarlo('fonction_def',V,1) 
    %indice2Pf(beta)
    %plot(Sit(:,1),Sit(:,2))
end 