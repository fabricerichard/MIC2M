function [Dt,Dvar,test_rupture,aux]=calcul_Dvar(nom_modele,nom_para,para,type_var,num_var,nom_var,var,Dvar_asservi,t,Dt,mode)
%                                             
test_rupture=0 ;
nbvar=length(var) ;

% calcul des vitesses
var_asservi_dot = Dvar_asservi ;
for i=1:length(var)
   if strcmp(type_var(i),'asservi')==1 
      var_asservi_dot(i)= Dvar_asservi(i)/Dt ;
   end
end   

[Dt,Dvar,test_rupture,aux]=R_Kutta(nom_modele,nom_para,para,type_var,num_var,nom_var,var,var_asservi_dot,t,Dt,mode) ;


%for i=1:length(var)
%   if strcmp(type_var(i),'asservi')==1 
%      Dvar(i)= Dvar_asservi(i) ;
%   end
%end   
