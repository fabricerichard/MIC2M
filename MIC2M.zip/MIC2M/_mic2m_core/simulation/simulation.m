clear all

k_iteration = 1 ; save k_iteration.txt k_iteration -ascii ; % initialisation du compteur

% CHOIX DU MODELE 
%liste_modele = textread(['liste_modele','.txt'],'%s') ;
%disp(' ')
%for i=1:size(liste_modele,1) ; disp(['(',num2str(i),')','  ',char(liste_modele(i))]) ; end  
%disp(' ') ; 
%choix = input('CHOIX : ') ; 

%nom_du_modele = char(liste_modele(choix)) 
%fid = fopen('nom_du_modele.txt','w');
%for i=1:size(char(nom_du_modele),2)   ;  fprintf(fid,'%s',char(nom_du_modele(i))) ; end
%fclose('all');

%if choix==0 ; nom_du_modele='BATCH' ; 
%[s,ident,essais,model] = textread(['liste_experiences.txt'],'%s %s %s %s') ; ancien code matlab
pwd
fid = fopen('liste_experiences.txt','r') ;X = fread(fid) ; fclose(fid) ; nombre_de_lignes = sum(X==10) ;
fid = fopen('liste_experiences.txt') ; C = textscan(fid, '%s %s %s %s', nombre_de_lignes) ; fclose(fid);
[s,ident,essais,model] = C{:} ;
		
		
%    for i=2:length(s) 
 %       if strcmp( model(i),'%')==0 
 %           nom_du_modele=char(model(i)) ;
 %       end
  %  end
%else
 %   nom_du_modele = char(liste_modele(choix)) 
%end

%fid = fopen('nom_du_modele.txt','w');
%for i=1:size(char(nom_du_modele),2)   ;  fprintf(fid,'%s',char(nom_du_modele(i))) ; end
%fclose('all');

% lecture parametre
%fich_parametre = [char(nom_du_modele),'_parametres'] 
%[nom_para,para_nom,a,b,loi,CV] = textread([fich_parametre,'.txt'],'%s %f %f %f %f %f') ;
%parametres=para_nom ;
% parametres courants
%save parametres.txt parametres -ASCII ;

% nom du fichier essai
%[s,i,essais] = textread([char(nom_du_modele),'_essais.txt'],'%s %s %s') ;
%[s,i,essais,model] = textread(['liste_experiences.txt'],'%s %s %s %s') ;

for i=2:length(s) 
    
    if strcmp( s(i),'%')==0 
        fich_essai=char(essais(i)) 
        nom_du_modele=char(model(i)) ;
        fid = fopen('nom_du_modele.txt','w');
        for i=1:size(char(nom_du_modele),2)   ;  fprintf(fid,'%s',char(nom_du_modele(i))) ; end
        fclose('all');
        nom_fich = [char(nom_du_modele),'_parametres'] ;
        %[nom_para,para_nom,a,b,loi,CV] = textread([fich_parametre,'.txt'],'%s %f %f %f %f %f') ; ancien code matlab
        %T = textread([fich_parametre,'.txt'],'%s','delimiter','\n');nombre_de_lignes = size(T,1) ;
		nom_fich
        fid = fopen([nom_fich,'.txt'],'r') ; X = fread(fid) ; fclose(fid) ; nombre_de_lignes = sum(X==10) ;
	    fid = fopen([nom_fich,'.txt']) ; C = textscan(fid, '%s %f %f %f %f %f', nombre_de_lignes) ; fclose(fid) ;
        [nom_para,para_nom,a,b] = C{:} ;
				        
        parametres=para_nom 
        % parametres courants
        save parametres.txt parametres -ascii ;
        % simulation
        [temps,sortie,test_rupture,aux] = simul(fich_essai,'s') ;

        a=[temps,sortie];
        eval(['save  resultat.txt a -ascii']) ;

        visualisation
    end 

end
