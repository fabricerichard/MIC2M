function CreerModMat(EIBBOpt,EIBHOpt,EIHBOpt,EIHHOpt,EFBOpt,EFHOpt,BVal,Reponse)

NbParam = size(EFHOpt,2);

fichierMAT = fopen('ModeleMat.m','w+');
fprintf(fichierMAT,'function Rep = ModeleMat(param)\n\n');

% Creation des Indicateurs
IterP = 1;
for i=1:1:NbParam
    NomParMin = ['Ind',char([64+i]),num2str(1)];
    NomParMax = ['Ind',char([64+i]),num2str(2)];
    if(EFHOpt(i) == 0.)
        Val = mean(BVal(i,:));             
        fprintf(fichierMAT,'%s = %-8.5f;\n',...
                NomParMin,(Val-BVal(i,2))/(BVal(i,1)-BVal(i,2)));
        fprintf(fichierMAT,'%s = %-8.5f;\n\n',...
                NomParMax,(Val-BVal(i,1))/(BVal(i,2)-BVal(i,1)));     

    else
        Val = ['param(',num2str(IterP),')'];
        fprintf(fichierMAT,'%s = (%s -%-8.5f)/%-8.5f;\n',...
                NomParMin,Val,BVal(i,2),BVal(i,1)-BVal(i,2));
        fprintf(fichierMAT,'%s = (%s -%-8.5f)/%-8.5f;\n\n',...
                NomParMax,Val,BVal(i,1),BVal(i,2)-BVal(i,1)); 

        IterP = IterP+1;
    end
        fprintf(fichierMAT,'Ind%c = [%s %s];\n\n',char([64+i]),...
                           NomParMin,NomParMax);
end

% Creation des matrices du mod�le
for i=1:1:NbParam
    NomMatrice = ['Mat',char([64+i])];
    fprintf(fichierMAT,'%s = [%-12.8f %12.8f];\n',NomMatrice,...
               EFBOpt(i),EFHOpt(i));    
end
min = 1;
max = 2*NbParam-1;
j=1;
k=2;
NbTotPI = NbParam*(NbParam-1)/2;
for i=1:1:NbTotPI
    NomMatrice = ['Mat',char([64+j]),char([64+k])];
    fprintf(fichierMAT,'%s = [%-12.8f %12.8f;%-12.8f %12.8f];\n',NomMatrice,...
               EIBBOpt(i),EIBHOpt(i),EIHBOpt(i),EIHHOpt(i));   
           if (i == NbTotPI)
              fprintf(fichierMAT,'\n\n');               
           end
           if((i<=max)&&(k<NbParam))
             k=k+1;
           else
            j=j+1;
            k=j+1;
            max = max+NbParam-j;           
           end 
end

fprintf(fichierMAT,'Rep = %12.8f +...\n',mean(Reponse));

for i=1:1:NbParam
    NomMatrice = ['Mat',char([64+i])];
    IndVec = ['Ind',char([64+i]),''''];
    fprintf(fichierMAT,'%s*%s+...\n',NomMatrice,IndVec);   
end

min = 1;
max = 2*NbParam-1;
j=1;
k=2;
for i=1:1:NbTotPI
  NomMatrice = ['Mat',char([64+j]),char([64+k])];
  IndVec1 = ['Ind',char([64+j])];
  IndVec2 = ['Ind',char([64+k]),''''];
  
  if(i<NbTotPI)
    fprintf(fichierMAT,'%s*%s*%s+...\n',IndVec1,NomMatrice,IndVec2);  
  else
    fprintf(fichierMAT,'%s*%s*%s;\n',IndVec1,NomMatrice,IndVec2);      
  end
  if((i<=max)&&(k<NbParam))
             k=k+1;
  else
            j=j+1;
            k=j+1;
            max = max+NbParam-j;           
  end 
end
fclose(fichierMAT);

fichierPARAM = fopen('ParamGene.txt','w+');
for i=1:1:NbParam
    if(EFHOpt(i) ~= 0.)
        fprintf(fichierPARAM,'%12.8f %12.8f\n',BVal(i,1),BVal(i,2));
    end
end
fclose(fichierPARAM);
