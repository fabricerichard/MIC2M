function G=fonction_def(nom_para,valeur_para)


assignation_para(nom_para,valeur_para) ;


S=[1/E1 -Nu12/E1 0 ; -Nu12/E1 1/E2 0 ; 0 0 1/G12] ;
Q=inv(S) ;

ang=ang/180*pi ;

angle=ang ;


Ts1= [cos(angle)^2 sin(angle)^2 2*sin(angle)*cos(angle);
		  sin(angle)^2 cos(angle)^2 -2*sin(angle)*cos(angle);
        -sin(angle)*cos(angle) sin(angle)*cos(angle) cos(angle)^2-sin(angle)^2];
    
Te1= [cos(angle)^2 sin(angle)^2 sin(angle)*cos(angle);
		  sin(angle)^2 cos(angle)^2 -sin(angle)*cos(angle);
        -2*sin(angle)*cos(angle) 2*sin(angle)*cos(angle) cos(angle)^2-sin(angle)^2];

angle=-ang ;

Ts2= [cos(angle)^2 sin(angle)^2 2*sin(angle)*cos(angle);
		  sin(angle)^2 cos(angle)^2 -2*sin(angle)*cos(angle);
        -sin(angle)*cos(angle) sin(angle)*cos(angle) cos(angle)^2-sin(angle)^2];
    
Te2= [cos(angle)^2 sin(angle)^2 sin(angle)*cos(angle);
		  sin(angle)^2 cos(angle)^2 -sin(angle)*cos(angle);
         -2*sin(angle)*cos(angle) 2*sin(angle)*cos(angle) cos(angle)^2-sin(angle)^2];  
       
Q1b=inv(Ts1)*Q*Te1 ;
Q2b=inv(Ts2)*Q*Te2 ;

QQb=(.5*Q1b+.5*Q2b);


k=.5 ; sigtt=20 ;
sig0 = [k;1;0]*sigtt ;
s1=Ts1*Q1b*inv(QQb)*sig0 ;
s2=Ts2*Q2b*inv(QQb)*sig0 ;


YI =0.5*s1(2)^2/E2 ; YII=0.5*s1(3)^2/G12 ;
chiII=(1/(E1*E2))^0.5*G12 ;


%YI =  sigtt^2*( 1/2*(sin(ang)^2*k+cos(ang)^2-2*sin(ang)*cos(ang)*((2*Nu12*E2*sin(4*ang)*G12+2*E2*sin(2*ang)*G12-E1*E2*sin(4*ang)+E2*sin(4*ang)*G12-2*E1*sin(2*ang)*G12+G12*sin(4*ang)*E1)/(4*E2*Nu12*G12*cos(4*ang)-4*E2*Nu12*G12-2*E1*E2*cos(4*ang)-2*E1*E2+2*E2*G12*cos(4*ang)-2*E2*G12+2*G12*E1*cos(4*ang)-2*G12*E1)*k+(-2*Nu12*E2*sin(4*ang)*G12+2*E2*sin(2*ang)*G12-E2*sin(4*ang)*G12+E1*E2*sin(4*ang)-G12*sin(4*ang)*E1-2*E1*sin(2*ang)*G12)/(4*E2*Nu12*G12*cos(4*ang)-4*E2*Nu12*G12-2*E1*E2*cos(4*ang)-2*E1*E2+2*E2*G12*cos(4*ang)-2*E2*G12+2*G12*E1*cos(4*ang)-2*G12*E1)))^2/E2 ) ;
%YII = sigtt^2*( 1/2*(-sin(ang)*cos(ang)*k+sin(ang)*cos(ang)+(cos(ang)^2-sin(ang)^2)*((2*Nu12*E2*sin(4*ang)*G12+2*E2*sin(2*ang)*G12-E1*E2*sin(4*ang)+E2*sin(4*ang)*G12-2*E1*sin(2*ang)*G12+G12*sin(4*ang)*E1)/(4*E2*Nu12*G12*cos(4*ang)-4*E2*Nu12*G12-2*E1*E2*cos(4*ang)-2*E1*E2+2*E2*G12*cos(4*ang)-2*E2*G12+2*G12*E1*cos(4*ang)-2*G12*E1)*k+(-2*Nu12*E2*sin(4*ang)*G12+2*E2*sin(2*ang)*G12-E2*sin(4*ang)*G12+E1*E2*sin(4*ang)-G12*sin(4*ang)*E1-2*E1*sin(2*ang)*G12)/(4*E2*Nu12*G12*cos(4*ang)-4*E2*Nu12*G12-2*E1*E2*cos(4*ang)-2*E1*E2+2*E2*G12*cos(4*ang)-2*E2*G12+2*G12*E1*cos(4*ang)-2*G12*E1)))^2/G12 ) ; 
% simplif
DD = ( E1*(E2+G12) + E2*G12*(2*Nu12+1) + (E1*(E2-G12)-E2*G12*(2*Nu12+1))*cos(4 *ang) )^2 ;
YI  =  sigtt^2* ( E2*  ((k + 1)*(E1 + 2*G12*(Nu12 + 1) +  (E1 - 2*G12*(Nu12 + 1))*cos(4*ang)) -  2*E1*(k - 1)*cos(2*ang)) ^ 2 ) / ( 8*DD ) ;  
YII =  sigtt^2* ( G12* ((k - 1)*(E1 + E2 + 2 *E2 *Nu12) - (E1 - E2)* (k + 1)* cos(2*ang))^2 *(sin(2*ang))^2 )                   / ( 2*DD ) ; 

Y=YI+chiII*YII ;

G=.002-Y ;

