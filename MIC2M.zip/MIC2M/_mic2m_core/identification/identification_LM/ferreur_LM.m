function [r,test_rupture]=ferreur(P)

% calcul de l'erreur entre l'experience et le modele
%nom_du_modele = textread(['nom_du_modele','.txt'],'%s') ;
%nom_modele = [char(nom_du_modele),'_dot'] ;
%fich_parametre = [char(nom_du_modele),'_parametres'] ;
%fich_variable =  [char(nom_du_modele),'_variables'] ;

% parametres courants
parametres=P(:,1) ;
save parametres.txt parametres -ascii ;


% lecture du fichier variables
%[num_var,nom_var,var_0,graph] = textread([fich_variable,'.txt'],'%f %s %f %s') ;

[s,ident,essais,model] = textread(['liste_experiences.txt'],'%s %s %s %s') ;
fcourant=ones(length(s),1)*NaN ;
save fcourant.txt fcourant -ascii ;

nb=0 ; nobs=0 ;     

for i=2:length(s) 
   if strcmp( ident(i),'%')==0 
      fich_essai=char(essais(i)) ; nb=nb+1 ;
      %%%�%%
      %fid = fopen('nom_experience.txt','w');
      %for i=1:size(char(fich_essai),2)   ;  fprintf(fid,'%s',char(fich_essai(i))) ; end
      %fclose('all');
      %%%%%%%
      % chargement et reponse experimentale
      [temps,nom_entree,type_entree,entree] = experience(fich_essai) ;
      
      % reponse du modele au chargement experimental
      nom_du_modele = char(model(i)) ;
      fid = fopen('nom_du_modele.txt','w') ; fprintf(fid,'%s',char(model(i))) ; fclose('all');
      [temps,sortie,test_rupture,aux] = modele(fich_essai) ;
      a=[temps,sortie] ; eval(['save  resultat.txt a -ascii']) ;
      
      fich_variable =  [char(nom_du_modele),'_variables'] ;
      [num_var,nom_var,var_0,graph] = textread([fich_variable,'.txt'],'%f %s %f %s') ;

      nligne=size(entree,1) ;

      for j=1:length(type_entree)    
         if strcmp(char(type_entree(j)),'observe')==1
                poids=ones(nligne,1) ;
            if strcmp(char(nom_entree(j)),'poids')==1
                poids=entree(:,j);
            end 
         end
      end
      nligne=nnz(poids )  ;% prise en compte des 0 
      
      for j=1:length(type_entree)
         if strcmp(char(type_entree(j)),'observe')==1 & strcmp(char(nom_entree(j)),'poids')==0
            nobs=nobs+1 ;
            for k=1:length(nom_var)
               if strcmp(char(nom_entree(j)),char(nom_var(k)))==1
								     
										 %entree(:,j)=entree(:,j).*(1+normrnd(0,1e-4,size(entree(:,j),1),1)); disp('Attention bruit sur l entree !!!!!!!!!!!!!!!!!!!!!') ;
                     
										 maxe = max( abs( entree(:,j)) ) ; maxm = max( abs( sortie(:,k)) ) ; %PAR DEFAUT incertitude ABSOLUE sur chaque observable
										 %maxe = entree(:,j) ; maxm = sortie(:,k) ; disp('Attention incertitude RELATIVE !!!!!!!!!!!!!!!!!!!!!') ;							 
										 %maxe = ones(size(entree(:,j),1),1) ; maxm = ones(size(sortie(:,k),1),1)  ; disp('Attention fonction cout non adimensionalisee !!!!!!!!!!!!!!!!!!!!!') ;
										 
                  if nobs==1 
                     scm = (1./poids.^.5)/(str2num(char(ident(i))))^.5 .* maxm * nligne^.5 ;
                     sce = (1./poids.^.5)/(str2num(char(ident(i))))^.5 .* maxe * nligne^.5 ;
                     r =  ( entree(:,j) - sortie(:,k) )./sce ;
										 r(isnan(r))=0 ; 
	                else
                     scm = [scm ; (1./poids.^.5)/(str2num(char(ident(i))))^.5 .* maxm * nligne^.5] ;
                     sce = [sce ; (1./poids.^.5)/(str2num(char(ident(i))))^.5 .* maxe * nligne^.5] ;
                     r = [ r ; ( entree(:,j) - sortie(:,k) )./((1./poids.^.5)/(str2num(char(ident(i))))^.5 .* maxe * nligne^.5) ] ;
										 r(isnan(r))=0 ;
                  end
               end
            end
         end
      end
   end
end

eval(['save  scm.txt scm -ascii']) ;
eval(['save  sce.txt sce -ascii']) ;
eval(['save  Nvar_obs.txt nobs -ascii']) ;

load k_iteration.txt
k_iteration = k_iteration-1 ;
if k_iteration>0
   % eval(['save ',['r_iteration',num2str(k_iteration),'.txt'],' r -ascii']) ;  
   % eval(['save ',['scm_iteration',num2str(k_iteration),'.txt'],' scm -ascii']) ; 
   % eval(['save ',['sce_iteration',num2str(k_iteration),'.txt'],' sce -ascii']) ;    
end

