function [temps,nom_entree,type_entree,entree]=experience(fich_essai)

[temps,nom_entree,type_entree,entree]=lecture_fichier_essais(fich_essai) ;
entree(isnan(entree))=0 ;


