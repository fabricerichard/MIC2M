cd ..

rand('state',sum(100*clock))

fprintf('\n')

fprintf('MIC2M \n')
fprintf('Modelisation et Identification du Comportement Mecanique des Materiaux\n')
fprintf('Fabrice RICHARD, 1999-2023 [mic2m.univ-fcomte.fr]\n\n')

fprintf('Copyright\n')
fprintf('logiciel regi par la licence CeCILL-B soumise au droit francais [www.cecill.info].\n')
fprintf('\n')

fprintf('Pour les tutos avec Octave, utiliser ode45 a la place de ode15s (voir fichier R_Kutta.m).\n')
fprintf('\n')

%fprintf('Creation des PATH \t')
warning('off','MATLAB:dispatcher:InexactMatch')
addpath(genpath(pwd))

isOctave = exist('OCTAVE_VERSION', 'builtin') ~= 0;
if (isOctave)
  warning ('off', 'Octave:data-file-in-path');
  warning('off','all');
end
setenv('KMP_STACKSIZE','8192k')
warning('off','all');

clear all

% LISTES DES MODULES  
%fprintf('liste des modules disponibles :\n')
%liste_modules = textread(['liste_modules','.txt'],'%s') ;
%for i=1:size(liste_modules,1) ; disp(['  ',char(liste_modules(i))]) ; end  
%disp(' ') ; 


%valueansys = [getenv('ANSYS192_DIR'),'\bin\winx64\MAPDL.exe -p aa_t_a -dir ',pwd,'\ -j file -s read -l en-us -b -i ',pwd,'\inputansys.txt -o ',pwd,'\file.out'] ;
%cd modele
%fid = fopen('ansys.txt','w') ;
%for i=1:size(valueansys,2)   
 %   fprintf(fid,'%s',char(valueansys(i))) ;
%end
%fclose('all');
%cd ..



%module load matlab 
%/share/apps/matlab/2019b/bin/matlab -nojvm -nodesktop -nologo -singleCompThread -r "cd /home/fabrice.richard/MIC2M/_start ; startup;simulation"

