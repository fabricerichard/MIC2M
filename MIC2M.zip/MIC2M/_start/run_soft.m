function []=run_soft(input,soft)
%run_soft(fich_commande,'ansys')

disp('')

disp('external soft run using run_soft function')
soft='matlab'
%soft='octave'


if strcmp(soft,'matlab')==1
    disp('lancement ANSYS via Matlab')
    pwd
    %system('SET KMP_STACKSIZE=2048k & "C:\Applications-FEMTO-ST\Ansys19.2\v192\ansys\bin\winx64\MAPDL.exe"  -p aa_r -dir "C:\MIC2M" -j "file" -s read -l en-us -b -i "C:\MIC2M\inputansys.txt" -o "C:\MIC2M\file.out" ')
    %system('SET KMP_STACKSIZE=2048k & "C:\Applications-FEMTO-ST\Ansys19.2\v192\ansys\bin\winx64\MAPDL.exe"  -p aa_r -dir "G:\MIC2M" -j "file" -s read -l en-us -b -i "G:\MIC2M\inputansys.txt" -o "G:\MIC2M\file.out" ')
    %system('SET KMP_STACKSIZE=8092k & "C:\Applications-FEMTO-ST\Ansys16.2_Academic_Associate\v162\ANSYS\bin\winx64\ansys162.exe"  -p aa_a -np 4 -dir "G:\Utilisateurs\vincent.fauvel\Documents\FEMTO\Simulation_numerique\MIC2M_MATLAB" -j "file" -s read -l en-us -b -i "G:\Utilisateurs\vincent.fauvel\Documents\FEMTO\Simulation_numerique\MIC2M_MATLAB\inputansys.txt" -o "G:\Utilisateurs\vincent.fauvel\Documents\FEMTO\Simulation_numerique\MIC2M_MATLAB\file.out"')
    %system('SET KMP_STACKSIZE=2048k & "C:\Applications-FEMTO-ST\Ansys19.2\v192\ansys\bin\winx64\MAPDL.exe"  -p aa_r -np 2 -dir "G:\MIC2M" -j "file" -s read -l en-us -b -i "G:\MIC2M\inputansys.txt" -o "G:\MIC2M\file.out" ')
    %system('SET KMP_STACKSIZE=2048k & "G:\ANSYS Student\v202\ansys\bin\winx64\MAPDL.exe"  -aa_t_i -np 2 -dir "G:\MIC2M" -j "file" -s read -l en-us -b -i "G:\MIC2M\inputansys.txt" -o "G:\MIC2M\file.out" ')
   
    currentdirectory = pwd;
    valueansys = ['"',getenv('ANSYS192_DIR'),'\bin\',getenv('ANSYS_SYSDIR'),'\MAPDL.exe','"',' -p ansys -np 2 -dir "',currentdirectory,'" -j "file" -s read -l en-us -b -i "',currentdirectory,'\inputansys.txt" -o "',currentdirectory,'\file.out"'] ;
    [status,cmdout] = system(valueansys);
    disp('gag')
end

if strcmp(soft,'octave')==1
    disp('lancement ANSYS via octave')
    pwd
    %system('"C:\Applications-FEMTO-ST\Ansys19.2\v192\ansys\bin\winx64\MAPDL.exe"  -p aa_t_a -dir "C:\MIC2M\" -j "file" -s read -l en-us -b -i "C:\MIC2M\inputansys.txt" -o "C:\MIC2M\file.out"');
    %valueansys = [getenv('ANSYS192_DIR'),'\bin\winx64\MAPDL.exe -p aa_t_a -dir ',pwd,'\ -j file -s read -l en-us -b -i ',pwd,'\inputansys.txt -o ',pwd,'\file.out'] ;
    %valueansys = [getenv('ANSYS192_DIR'),'\bin\winx64\MAPDL.exe -p aa_r -dir ',pwd,'\ -j file -s read -l en-us -b -i ',pwd,'\inputansys.txt -o ',pwd,'\file.out'] ;
    %valueansys = [getenv('ANSYS162_DIR'),'\bin\winx64\MAPDL.exe -p aa_t_a -dir ',pwd,'\ -j file -s read -l en-us -b -i ',pwd,'\inputansys.txt -o ',pwd,'\file.out'] ;
	
    valueansys = [getenv('ANSYS202_DIR'),'\bin\winx64\MAPDL.exe -p aa_t_i -dir ',pwd,'\ -j file -s read -l en-us -b -i ',pwd,'\inputansys.txt -o ',pwd,'\file.out'] ;
	valueansys
	system(valueansys);
end


% pour executer sur le cluster
%disp('lancement ANSYS via MATLAB sur le cluster')
%system('/share/apps/ansys/v160/ansys/bin/ansys160 -j inputansys -p aa_r -b < inputansys.txt  >& /home/fabrice.richard/MIC2M/file.out');


%else 
%  disp('MIC2M ne sais pas quel soft lancer')
%end