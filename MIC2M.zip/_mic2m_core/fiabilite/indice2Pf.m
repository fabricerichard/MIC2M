function [Pf]=indice2Pf(indice) ;


% conversion de l'indice de fiabilit� � Pf ;
Pf=0.5*erfc(indice/2^0.5) ;