function sortie=fonction_pro(nom_para,valeur_para)

assignation_para(nom_para,valeur_para) ;

test_rupture=0 ;
sortie_aux=0 ;

%mode='i'
format long

valeur_para ;
nom_para ;

% d�finition des entr�es
%d = 25.0; % dimension de l'outil : demi-longueur libre du tube en mm (incertitude : delta = +-0.1 mm)
%r = 17.5; % dimension du tube : rayon ext�rieur du tube en mm (incertitude : delta = +-0.1 mm)
%h = 10.0 % mesure : hauteur de gonflement en mm (incertitude : delta = +-0.1 mm)

% calcul de eps
eps = log((h*h+d*d)/2/h/r);
 
sortie=[eps]' ;