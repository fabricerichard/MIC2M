function sauvegarde(sortie,nom_fichier)

fichier = fopen(nom_fichier,'w+');

for j=1:size(sortie,1)
    for i=1:1:size(sortie,2)
        fprintf(fichier,'%5.20d\t',sortie(j,i));
    end
    fprintf(fichier,'\n');
end

fclose(fichier) ;