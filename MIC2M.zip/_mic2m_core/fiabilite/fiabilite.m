clear all

fprintf('Module Fiabilit� \n')
fprintf('Fabrice RICHARD\n')
fprintf('2000-2010\n\n\n')

% CHOIX DU MODELE 
liste_modele = textread(['liste_defaillance','.txt'],'%s') ;
disp(' ')
for i=1:size(liste_modele,1) ; disp(['(',num2str(i),')','  ',char(liste_modele(i))]) ; end  
disp(' ') ; 
choix = input('CHOIX : ') ; nom_du_modele = char(liste_modele(choix)) 


fid = fopen('nom_defaillance.txt','w');
for i=1:size(char(nom_du_modele),2)   ;  fprintf(fid,'%s',char(nom_du_modele(i))) ; end
fclose('all');
% lecture parametre
fich_parametre = [char(nom_du_modele),'_parametres'] ;

x='%s %f %f %f %f %f %f' ;
[nom_para,para_nom,a,b,ET,loi,q] = textread([fich_parametre,'.txt'],x) ;

V=[para_nom,a,b,ET,loi] ;
parametres=para_nom ;
% parametres courants
save parametres.txt parametres -ASCII ;


% CHOIX DU MODELE DE RESOLUTION
liste_resolution = textread(['liste_modele_fiabilite','.txt'],'%s') ;
disp(' ')
for i=1:size(liste_resolution,1) ; disp(['(',num2str(i),')','  ',char(liste_resolution(i))]) ; end  
disp(' ') ; 
choix = input('CHOIX : ') ; nom_resolution = char(liste_resolution(choix)) 

fid = fopen('algorithme fiabilite.txt','w');


format long
if strcmp(nom_resolution,'FORM(Rackwitz-Fiessler)')==1 ;
    [beta,alpha,betait,alphait,Pet]=rackwitz('fonction_def',V,1) ;
    nbit=length(betait) ;
    nbvar=length(Pet) ;
    disp(' ')
    disp('evolution de beta au cours des it�rations')
    betait
    disp('evolution de alpha au cours des it�rations')
    alphait
    disp('[beta et alpha lors de la convergence]')
    beta 
    alpha   
    disp('le point de conception dans l''espace standard')
    beta*alpha    
    disp('le point de conception dans l''espace physique')
    Pet
    %indice2Pf(beta)
    %plot(Sit(:,1),Sit(:,2))
end 
if strcmp(nom_resolution,'MonteCarlo')==1 ;
    nombretirage = input('nombre de tirages : ') ; 
    save nombretirage.txt nombretirage -ascii
    [nf,n,Pf]=montecarlo('fonction_def',V,1) 
    %indice2Pf(beta)
    %plot(Sit(:,1),Sit(:,2))
end 