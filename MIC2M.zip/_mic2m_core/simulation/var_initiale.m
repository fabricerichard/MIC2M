function var_ini=var_initiale(nom_var,type_entree,nom_entree,entree,var_0)
%

var_ini=var_0 ;


% 
% nentree=length(nom_entree) ;
% nvar=length(nom_var) ;
% 
% 
% for i=1:nvar
%    for j=1:nentree
%       if j<=nvar
%       	if strcmp(nom_var(i),nom_entree(j))==1
%             type_var{i,1}=type_entree{j} ;
%             var_ini(i,1)=entree(1,j) ;
%          end 
%       end
%    end
% end
% 
