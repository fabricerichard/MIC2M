function assignation_para(nom_para,valeur_para)
% assigne a la chaine de caracteres nom_para(i) la valeur valeur_para(i)
% dans la fonction appelante


for i=1:size(nom_para,1) ; 
   
   nom=char(nom_para(i)) ;
   assignin('caller',nom,valeur_para(i))  ;
   
end
