function [temps,nom_entree,type_entree,entree]=lecture_fichier_essais(fich_essai)

% attention court-cicuit 02-2009 pour identification asservissement %%%
%nom_experience = char(textread(['nom_experience','.txt'],'%s')) ; 
%fich_essai = nom_experience ;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

A = textread([fich_essai,'.txt'],'%s') ;

char(A(1));
size(A,1);
ncolonne=str2num(char(A(1))) ; 
nligne=size(A,1)/ncolonne-2 ;

for i=2:ncolonne ; type_entree(i-1)=A(i) ; end
for i=ncolonne+2:2*ncolonne ; nom_entree(i-ncolonne-1)=A(i) ; end
nom_entree;
l=2*ncolonne ;
for i=1:nligne ; 
   for j=1:ncolonne ; l=l+1 ; 
       if strcmp(char(A(l)),'?')==1 
           entree(i,j)=0 ;
       else
           entree(i,j)=str2num(char(A(l)));
       end  
       entree;
   end
  i ;
end


% % si modification de l'asservissement
% % lecture parametre
% nom_du_modele = textread(['nom_du_modele','.txt'],'%s') ;
% nom_modele = [char(nom_du_modele),'_dot'] ;
% fich_parametre = [char(nom_du_modele),'_parametres'] ;
% fich_variable =  [char(nom_du_modele),'_variables'] ;
% [nom_para,para_nom,a,b,loi,para_opt] = textread([fich_parametre,'.txt'],'%s %f %f %f %f %s') ;
% 
% for j=1:length(nom_para)
%     x=char(nom_para(j)) ;
%     if length(x)>5
%          if strcmp(x(1:5),'DECAL')==1 
%             numparadecal=j;
%             % decalage asservissement j
%             disp('d�calage fichier experimental')
%             vardecal=x(6:length(x));
%             nom_entree;
%             for k=1:length(nom_entree)
%                 if strcmp(vardecal,nom_entree(k))==1 
%                     vardecal;
%                     nom_entree(k);
%                     numvardecal=k;
%                 end
%             end
%             
%             parametres = char(textread(['parametres','.txt'],'%s')) ;
%             str2num(parametres(numparadecal,:));
%             for i=1:length(entree)
%             entree(i,numvardecal)=entree(i,numvardecal)+str2num(parametres(numparadecal,:));
%             end   
%          end
%     end
% end


type_entree;
nom_entree;
temps=entree(:,1)  ;
entree=entree(:,2:ncolonne) ;



