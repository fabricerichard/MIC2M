function EcrireTableExp(MatExp,Name)

fichierTExp = fopen('TableExp.txt','w+');
fprintf(fichierTExp,'Experience Number\t');
for i=1:1:size(MatExp,2)
    %fprintf(fichierTExp,'%3s\t',char([64+i]));    
     fprintf(fichierTExp,'%s\t',Name(i+1,:));    
end
fprintf(fichierTExp,'Response\n'); 
for j=1:1:size(MatExp,1)
    fprintf(fichierTExp,'%9i\t',j);
    for i=1:1:size(MatExp,2)
        fprintf(fichierTExp,'%3i\t',MatExp(j,i));    
    end
    fprintf(fichierTExp,'\n');
end


fclose(fichierTExp);