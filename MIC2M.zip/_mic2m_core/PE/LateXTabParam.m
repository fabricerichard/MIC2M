function LateXTabParam(Name,BVal)

fichierLATEX = fopen('TabParam.tex','w+');
fprintf(fichierLATEX,'\\begin{center}\n');
fprintf(fichierLATEX,'\\begin{tabular}{|c|c|c|c|}\n');
fprintf(fichierLATEX,'\\hline\n');
Text = ['\\textbf{Nom param�tre} & \\textbf{Facteur} & ',...
       '\\textbf{Niveau -1} & \\textbf{Niveau 1}\\\\ \n'];
fprintf(fichierLATEX,Text);
fprintf(fichierLATEX,'\\hline\n');
for i=1:1:size(BVal,1)
    fprintf(fichierLATEX,'%s & %c & %6.3f & %6.3f\\\\ \n',Name(i+1,:),...
    char([64+i]),BVal(i,1),BVal(i,2));
    fprintf(fichierLATEX,'\\hline\n');
end
fprintf(fichierLATEX,'\\end{tabular}\n');
fprintf(fichierLATEX,'\\end{center}\n');
fclose(fichierLATEX);