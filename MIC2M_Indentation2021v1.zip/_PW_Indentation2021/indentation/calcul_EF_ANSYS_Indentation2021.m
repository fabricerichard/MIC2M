function [time,sortie,test_rupture,sortie_aux]=calcul_EF_ANSYS_nano2D(nom_modele,nom_para,valeur_para,type_var,num_var,nom_var,var_0,type_entree,nom_entree,entree,temps,nligne,mode)

%format SHORT
ANGLE=70.3

test_rupture=0 ;
sortie_aux=0 ;

%mode='i'
load k_iteration.txt ;

% entree : on retrouve 2 colonnes UY et FY exp�rience
% sortie : on retrouve 2 colonnes UY et FY mod�le
% en mode identification, l'erreur est au sens des moindres carr�s sur les
% observations (entree-sortie)

assignation_para(nom_para,valeur_para) ;
nom_para;
valeur_para;

% r�cup�ration de la force et du deplacement
nbligne=cellstr('nbligne') ;
TF=cellstr('TF') ;
prof=cellstr('prof') ;

UY=entree(:,1);
FY=entree(:,2);

essai =[temps UY FY] ;
save temps.txt temps -ascii
save UY.txt UY -ascii
save FY.txt FY -ascii

for i=1:length(temps)
charge(2*i-1,1)   = temps(i);
charge(2*i,1) = -UY(i)*hmax;
save charge.txt charge -ascii
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ECRITURE DU FICHIER ANSYS inputansys.txt %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
fich_commande = 'input_ansys_Indentation2021.txt' ;
%fich_commande = 'input_ansys_R_Indentation2021.txt' 

ccc=0.5;
cc=1;

eeps(1)=sigy/E ; ssig(1)=sigy;
eeps(2)=3 ; ssig(2)=sigy;

if n>0     
    while cc==1
     ccc=ccc*2;
     clear eeps ssig
     eeps(1)=sigy/E ; ssig(1)=sigy;
     K=sigy*(E/sigy)^n;
     ddd1=(1.001*sigy/K)^(1/n)-eeps(1);

     i=1;
     while eeps(i)<3
         eeps(i+1)=eeps(i)+(ddd1*i^1)*ccc;
          ssig(i+1)=K*eeps(i+1)^n ;
          i=i+1;
     end
     if i<99 ; cc=0 ; end
    end
end

courbe=[0,eeps;0,ssig]';
%plot(courbe(:,1)*100,courbe(:,2),'-ro') ; hold on
%pause
save courbe.txt courbe -ascii
eval(['copyfile courbe.txt ',['courbe',num2str(k_iteration),'.txt']])  


com='! zoubidou' ; B=[cellstr(com)] ;
llc=['TB,MISO,2,1,',num2str(size(courbe,1),'%16.10g')] ; B=[B;cellstr(llc)] ;
llc=['TBPT,,0,0'] ; B=[B;cellstr(llc)] ;
for i=1:size(courbe,1)-1   ;  
    llc=['TBPT,,',num2str(eeps(i),'%16.10g'),',',num2str(ssig(i),'%16.10g')] ; B=[B;cellstr(llc)] ;
  end
fid = fopen('courbebis.txt','w'); 
for i=1:size(B,1)   ;  fprintf(fid,'%s\n',char(B(i))) ; end
fclose('all');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ccc=0.5;
cc=1;

eeps(1)=sigys/Es ; ssig(1)=sigys;
eeps(2)=3 ; ssig(2)=sigys;

if ns>0     
    while cc==1
     ccc=ccc*2;
     clear eeps ssig
     eeps(1)=sigys/Es ; ssig(1)=sigys;
     Ks=sigys*(Es/sigys)^ns;
     ddd1=(1.001*sigys/Ks)^(1/ns)-eeps(1);

     i=1;
     while eeps(i)<3
         eeps(i+1)=eeps(i)+(ddd1*i^1)*ccc;
          ssig(i+1)=Ks*eeps(i+1)^ns ;
          i=i+1;
     end
     if i<99 ; cc=0 ; end
    end
end

courbe=[0,eeps;0,ssig]';
%plot(courbe(:,1)*100,courbe(:,2),'-ro') ; hold on
%pause
com='! zoubidou2' ; B=[cellstr(com)] ;
llc=['TB,MISO,3,1,',num2str(size(courbe,1),'%16.10g')] ; B=[B;cellstr(llc)] ;
llc=['TBPT,,0,0'] ; B=[B;cellstr(llc)] ;
for i=1:size(courbe,1)-1   ;  
    llc=['TBPT,,',num2str(eeps(i),'%16.10g'),',',num2str(ssig(i),'%16.10g')] ; B=[B;cellstr(llc)] ;
  end
fid = fopen('courbebiss.txt','w'); 
for i=1:size(B,1)   ;  fprintf(fid,'%s\n',char(B(i))) ; end
fclose('all');


disp('script APDL creation: inputansys.txt')
%dd=[nom_para' nbligne TF prof]'
%dd{2}
%cell(dd)
%cell([nom_para' nbligne TF prof]')
%B = remplace(fich_commande,'################','%16.10e',cell([nom_para' nbligne TF prof]'),[valeur_para' length(temps) temps(length(temps)) max(UY)]') ;

B = remplace(fich_commande,'################','%16.10e',[nom_para' nbligne TF prof]',[valeur_para' length(temps) temps(length(temps)) max(UY)]') ;

fid = fopen('inputansys.txt','w') ;
for i=1:size(B,1) 
    fprintf(fid,'%s\n',char(B(i))) ;
end
fclose('all');
eval(['copyfile inputansys.txt ',['inputansys',num2str(k_iteration),'.txt']]) ;



%%%%%%%%%%%%%%%%%%%
% LANCEMENT ANSYS %
%%%%%%%%%%%%%%%%%%%
run_soft(fich_commande,'ansys')
%eval(['copyfile ',['res',num2str(k_iteration),'.txt']],'res.txt')  ;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% traitement des sorties pour les modes simulation et identification %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%eval(['load ',['res',num2str(k_iteration),'.txt']]) ;
%eval(['save ',['res.txt'],[' res',num2str(k_iteration),' -ascii']]) ;
load res.txt
load AC.txt
load profil.txt ; profil = sortrows(profil,1);

temps_sim=[0;res(:,1)] ;
h=[0;-res(:,2)];
P=[0;-res(:,3)];
AC=[0;AC(:,1)];
X=profil(:,1) ; Y=profil(:,2);

%plot(h,P,'k+') ; hold on ; % affichage resultat EF brut
%plot(h,AC,'k+') ; hold on ; % affichage resultat EF brut
%figure(10) ; hold on ; plot(X,Y,'k+') ; hold on ; % affichage resultat EF brut

% reechantillonage du profil sur 10hmax
Xq=0:10*hmax/(length(temps)-1):hmax*10 ;
Zq = interp1(X,Y,Xq) ;
w=[Xq',Zq'];
save profil_re.txt w -ascii
%plot(Xq,Zq,'bo'); hold on
%sortie_Z=[Xq',-Zq'./min(Zq)+1] ;
sortie_Z=[Xq',Zq'./hmax+1] ;

[Zmax I_Zmax] = max(Zq) ; 
for i=1:length(temps) ; 
    %sortie_Z(i,2)=sortie_Z(i,2)-1;
    if i<1*I_Zmax ; 
        %sortie_Z(i,2)=0 ; %
    end 
end

 % prend que le bourrelet
%plot(hcharge,Pcharge,'g*') ; hold on
%plot(hdecharge,Pdecharge,'k*')

mode='i';
if strcmp(mode,'i')==1
    time=temps;
    sortie=[h(1),P(1)] ; time(1,1)=temps_sim(1,1) ;
    sortie_AC=AC(1) ; 
    for i=2:length(temps)-1
        time(i,1)=temps(i,1);
        j = min(find(temps_sim>temps(i))) ;
        sortie(i,1)=((h(j)-h(j-1))/(temps_sim(j)-temps_sim(j-1))*(temps(i)-temps_sim(j-1))+h(j-1)) ;
        sortie(i,2)=(P(j)-P(j-1))/(temps_sim(j)-temps_sim(j-1))*(temps(i)-temps_sim(j-1))+P(j-1) ;
        sortie_AC(i,1)=(AC(j)-AC(j-1))/(temps_sim(j)-temps_sim(j-1))*(temps(i)-temps_sim(j-1))+AC(j-1) ;
    end
    i=i+1 ;
    time(i,1)=temps(i,1);
    j = length(temps_sim) ;

    sortie(i,1)=((h(j)-h(j-1))/(temps_sim(j)-temps_sim(j-1))*(temps(i)-temps_sim(j-1))+h(j-1)) ;
    sortie(i,2)=(P(j)-P(j-1))/(temps_sim(j)-temps_sim(j-1))*(temps(i)-temps_sim(j-1))+P(j-1) ;
    sortie_AC(i,1)=(AC(j)-AC(j-1))/(temps_sim(j)-temps_sim(j-1))*(temps(i)-temps_sim(j-1))+AC(j-1) ;

end   

%if strcmp(mode,'s')==1
% time=temps_sim;
% sortie=[h,P,AC,Xq',Zq'] ; 
%end

%plot(sortie(:,1),sortie(:,2), 'ro') ; hold on  ; % fittage lin�aire
%plot(sortie(:,1),sortie_AC(:,1), 'ro') ; hold on  ; % fittage lin�aire

test_rupture=0 ;
sortie_aux=sortie ;

FY=sortie(:,2);UY=sortie(:,1);
%courbe de charge
[Pmax I_Pmax] = max(FY) ;
hmax=max(UY) ;
Pcharge=FY(1:I_Pmax) ; hcharge=UY(1:I_Pmax) ;
%area(hcharge,Pcharge) ;
Wt = trapz(hcharge,Pcharge) ;
%courbe de decharge
Pdecharge=FY(I_Pmax:length(FY)) ; hdecharge=UY(I_Pmax:length(FY)) ;
%area(hdecharge,Pdecharge) ;
We = -trapz(hdecharge,Pdecharge) ;
Wp = Wt - We  ;

EPHI1=Pmax/hmax^2 ;
PHI2 = Wp/Wt ;

% lissage
t=time; h=sortie(:,1) ; P=sortie(:,2) ; % plot(h,P,'b') ; hold on 
AC=sortie_AC(:,1) ;  %plot(h,AC,'b') ; hold on 
Ps=P ; ACs=AC;
Pmax = P(I_Pmax) ; hmax = h(I_Pmax) ;

I_P0=max(find(P(I_Pmax:length(P))>Pmax*1/1000))+I_Pmax ;
%I_Pmax
%I_P0
%pause
%t_P0 = t(I_P0) ; P(I_P0) ;


% fit de la charge 
deg_inter=6 ; %degr� d'interpolation polynomiale
[p,S,mu]  = polyfitB0(t(1:I_Pmax),P(1:I_Pmax),deg_inter,0) ; %voir la commande polyfitB0
[yest,derr] = polyval(p,t(1:I_Pmax),S,mu) ; Ps(1:I_Pmax) = yest ; %plot(t(1:I_Pmax),Ps(1:I_Pmax),'k')

[p,S,mu]  = polyfitB0(t(1:I_Pmax),AC(1:I_Pmax),deg_inter,0) ; %voir la commande polyfitB0
[yest,derr] = polyval(p,t(1:I_Pmax),S,mu) ; ACs(1:I_Pmax) = yest ; 

PsmaxC=Ps(I_Pmax)  ;%P(I_Pmax)=Ps(I_Pmax);
ACsmaxC=ACs(I_Pmax) ;

Psmax=PsmaxC;
ACsmax=ACsmaxC;


% fit de la d�charge (pas tr�s utile, peu de perturbation numerique en d�charge) 
deg_inter=6 ; %degr� d'interpolation polynomiale
[p,S,mu]  = polyfit(t(I_Pmax+1:I_P0),P(I_Pmax+1:I_P0),deg_inter) ;%plot(t(I_Pmax),Ps(I_Pmax),'o') ;
[yest,derr] = polyval(p,t(I_Pmax+1:I_P0-1),S,mu) ; Ps(I_Pmax+1:I_P0-1) = yest ; %plot(t(I_Pmax+1:I_P0),Ps(I_Pmax+1:I_P0),'r') ;

[p,S,mu]  = polyfit(t(I_Pmax+1:I_P0),AC(I_Pmax+1:I_P0),deg_inter) ;%plot(t(I_Pmax),ACs(I_Pmax),'o') ;
[yest,derr] = polyval(p,t(I_Pmax+1:I_P0-1),S,mu) ; ACs(I_Pmax+1:I_P0-1) = yest ; %plot(t(I_Pmax+1:I_P0),ACs(I_Pmax+1:I_P0),'r') ;

PsmaxD=Ps(I_Pmax+1) ; %P(I_Pmax)=Ps(I_Pmax);
ACsmaxD=ACs(I_Pmax+1);

%Psmax=(PsmaxC*I_Pmax+PsmaxD*(I_P0-I_Pmax))/I_P0 ; Ps(I_Pmax)=Psmax ; ; Ps(I_Pmax+1)=Psmax ;%Psmax=PsmaxC;
%ACsmax=(ACsmaxC*I_Pmax+ACsmaxD*(I_P0-I_Pmax))/I_P0 ; ACs(I_Pmax)=ACsmaxC ; ACs(I_Pmax)=ACsmaxC ;%ACsmax=ACsmaxC;

for i=1:length(Ps) ; if Ps(i)>Psmax ; Ps(i)=Psmax ; end ; end
for i=1:length(Ps) ; if Ps(i)<0 ; Ps(i)=0 ; end ; end
for i=1:length(Ps) ; if ACs(i)>ACsmax ; ACs(i)=ACsmax ; end ; end

%plot(h,Ps,'go') ; hold on ; % affichage avec interpolation polynomiale
%plot(h,ACs,'go') ; hold on ; % affichage avec interpolation polynomiale
%plot(h,ACs,'g') ; hold on ; % affichage avec interpolation polynomiale


%length(Ps)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%sortie=[h,PHI1*ones(length(Ps),1)] ;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%courbe de charge
%[Pmax I_Pmax] = max(FY) ;
Pcharge = Ps(1:I_Pmax) ; hcharge=h(1:I_Pmax) ;
%area(hcharge,Pcharge) ;
Wt_fit = trapz(hcharge,Pcharge) ;
%courbe de decharge
Pdecharge=Ps(I_Pmax:length(Ps)) ; hdecharge=h(I_Pmax:length(Ps)) ;
%area(hdecharge,Pdecharge) ;
We_fit = -trapz(hdecharge,Pdecharge) ;
Wp_fit = Wt_fit - We_fit  ;


%We
%We_fit
%Wp
%Wp_fit
%Wt
%Wt_fit
%max(FY)
%max(Ps)

%plot(hcharge,Pcharge,'go')
%plot(hdecharge,Pdecharge,'ko')

EPHI1s = Psmax/(hmax^2)  ;
PHI2s = Wp_fit/Wt_fit  ;


%sortie=[sortie,sortie_AC,sortie_Z,ones(length(temps),1)*EPHI1,ones(length(temps),1)*PHI2] ; 
%disp(' lissage polynomial !') ; 
sortie=[h,Ps,sortie_Z] ;%sortie=[h,Ps,sortie_Z,ones(length(temps),1)*EPHI1s,ones(length(temps),1)*PHI2s] ;

%[p,S,mu]  = polyfitB0(h(1:I_Pmax),P(1:I_Pmax),2,0) 
%[yest,derr] = polyval(p,h(1:I_Pmax),S,mu) ;
%C=yest(I_Pmax)/h(I_Pmax)^2
%plot(h,C*h.^2,'og')

% approximation Ma2012
%PHI1 = ( -0.01569 + 0.6358*n + 104.64*sigy/E ) / ( 1 - 0.494*n + 45.33*sigy/E ) ; 
%E*PHI1
%PHI2 = 1.4070 - 0.5*n^1.5 + 2.614/log(sigy/E)  
%PHI3 = ( 0.2509 - 0.4727*n - 6.9912*sigy/E ) / ( 1 + 0.9807*n + 114.555*sigy/E - 4039.79*(sigy/E)^2 ) 
%pause
%for i = 1:length(sortie) ; PMa(i) = PHI1*E*(sortie(i,1))^2 ; end 
%plot(sortie(:,1),PMa, 'g') ; hold on
%hmax
%ANGLE
%A = hmax^2*tan(ANGLE/180*3.1416)/2
%DeltaA = A*PHI3


%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%% OP sans lissage Ph
%%%%%%%%%%%%%%%%%%%%%%%%%%
%aire projettee
aire=AC(:,1).*sin(ANGLE*pi/180);
%debut de decharge
FM=Pmax ;
DC=I_Pmax ;
%Fin de decharge
%Attention au seuil 0.5*force max
FC=DC+length(find (P(DC:end)>0.5*FM))-1 ;
%on isole la decharge
SegDeg(:,1)=temps(DC:FC);
SegDeg(:,2)=h(DC:FC);
SegDeg(:,3)=P(DC:FC);

%Profondeur residuelle
hr=h(FC) ;
%Regression lineaire
abs=SegDeg(:,2);
ord=SegDeg(:,3);
plot(abs,ord,'ro')
a=[abs,abs];
a(:,1)=1;
M1=a'*a;
M2=a'*ord;
sol=inv(M1)*M2;
Stiff=sol(2,1);

%Module et dureté
%figure(4)
Dur=P./aire; %plot(h,Dur,'o'); hold on
%figure(5)
Mod=0.5*Stiff/(aire(DC)/pi)^0.5 ;

HC=hmax-0.75.*Pmax./Stiff;
ACOP=pi*(tan(ANGLE/180*pi))^2.*HC.^2 ; %ACOP=24.56.*HC.^2;
DurOP=Pmax./ACOP;
ModOP=0.5*Stiff/(ACOP/pi)^0.5;

%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%% OP avec lissage Ph
%%%%%%%%%%%%%%%%%%%%%%%%%%
%aire projette
aires=ACs(:,1).*sin(ANGLE*pi/180);
%de�but de decharge
FM=Psmax ;
DC=I_Pmax;

%Fin de d�charge
%Attention au seuil 0.5*force max
FC=DC+length(find (Ps(DC:end)>0.5*FM))-1 ;

%on isole la decharge
clear SegDeg
SegDeg(:,1)=temps(DC:FC);
SegDeg(:,2)=h(DC:FC);
SegDeg(:,3)=Ps(DC:FC);

%Profondeur residuelle
hr=h(FC) ;
%Regression lineaire
abs=SegDeg(:,2);
ord=SegDeg(:,3);
plot(abs,ord,'b+')

a=[abs,abs];
a(:,1)=1;
M1=a'*a;
M2=a'*ord;
sol=inv(M1)*M2;
Stiff=sol(2,1) ;
%Module et durete
%figure(4)
Durs=Ps./aires ;%plot(h,Durs,'-'); hold on
%figure(5)
Mods=0.5*Stiff/(aires(DC)/pi)^0.5 ;%plot(h,Mod,'o') ; hold on

HCs=hmax-0.75.*Psmax./Stiff;
ACOPs=pi*(tan(ANGLE/180*pi))^2.*HCs.^2 ; %ACOPs=24.56.*HCs.^2;
DurOPs=Ps./ACOPs;
ModOPs=0.5*Stiff/(ACOPs/pi)^0.5;

EE = Mod*(1-0.3^2);
EEs = Mods*(1-0.3^2);

EOP = ModOP*(1-0.3^2);
EOPs = ModOPs*(1-0.3^2);

DureteOP = Pmax/ACOP;
DureteOPs = Psmax/ACOPs;

EE;
EEs;
Dur(I_Pmax);
Durs(I_Pmax);

EOP=EOP  ; ['Module d''Young (mod�le Oliver & Pharr avec Nu=0.3): ',num2str(EOP),' GPa']
HOP=DureteOP ; ['Hardness (modele Oliver & Pharr avec Nu=0.3): ',num2str(HOP),' GPa']
['hpile-up/hmax: ',num2str(max(Y/hmax)*100),' %']

save hmax.txt hmax -ascii
save Pmax.txt Psmax -ascii
save I_Pmax.txt I_Pmax -ascii

save EOP.txt EOP -ascii
save HOP.txt HOP -ascii

save Mod.txt EE -ascii
save Mods.txt EEs -ascii
save Dur.txt Dur -ascii
save Durs.txt Durs -ascii
%figure(10)
%subplot(2,2,1) ; plot(h,Ps,'go') ; hold on ; 
%subplot(2,2,3) ; plot(h,ACs,'go') ; hold on ; 
%subplot(2,2,2) ; plot(h,Durs,'go') ; hold on ; 
%subplot(2,2,4) ; plot(h,Durs,'go') ; hold on ; 

%figure(11)
%plot(Xq,Zq,'go')

disp('Pour afficher des champs m�caniques : ouvrir le fichier file.db avec Ansys Mechanical APDL') 
disp('Pour afficher courbe Ph et profil d''empreinte : taper visu dans la fenetre de commande Matlab/Octave') 


