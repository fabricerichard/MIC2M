function G=fonction_def(P)

fich_essai='essai_fiab' ;
mode='s' ;

nom_du_modele = textread(['nom_defaillance','.txt'],'%s') ;
fich_parametre = [char(nom_du_modele),'_parametres'] ;


% lecture parametre
[nom_para,para_nom,a,b,loi,para_opt] = textread([fich_parametre,'.txt'],'%s %f %f %f %f %s') ;
%load parametres.txt;
para_nom= P;


dopage=1e-3; save dopage.txt dopage -ASCII ;

ndm=char(nom_du_modele) ;
if strcmp(ndm(1:3),'EF_')==1
    G=feval( ['fonction_def_',ndm],nom_para,para_nom) ; 
else
    %dopage=1e-4; save dopage.txt dopage -ASCII ;
    G=feval( ['fonction_def_',ndm],nom_para,para_nom) ; 
end
