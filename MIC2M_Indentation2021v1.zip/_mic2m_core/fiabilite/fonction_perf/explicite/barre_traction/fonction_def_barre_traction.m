function G=fonction_def(nom_para,valeur_para)


assignation_para(nom_para,valeur_para) ;

%G=sigu-(F/A) ;
%G=R-S ;
G=sigu*pi*d^2/4-S ;

%G=sigu*d-S ;