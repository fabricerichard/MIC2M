clear all
load sensi.txt

% (ro, E, pr, Sigy, Hardi, Beta, Epsd, S, T et Dc). On trouve le crit�re JE=164.

for j=1:size(sensi,2)-1
    s(:,j)=sensi(:,j);
end

for i=1:size(sensi,2)-1
    for j=1:size(sensi,2)-1
        MAC(i,j)=abs(s(:,i)'*s(:,j))^2/( norm(s(:,i))^2*norm(s(:,j))^2 );
    end    
end