function var_dot=ec_cine_nl_iso_1D_dot(t,var,flag,nom_para,para,type_var,num_var,nom_var,var_asservi_dot)
 

% parametres
assignation_para(nom_para,para)

% variables
assignation_var(nom_var,var) 
assignation_var_asservi_dot(nom_var,var_asservi_dot) 


A = [	 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 ;
	-1 , 0 , E , 0 , 0 , 0 , 0 , 0 , 0 ;
	 0 ,-1 , 1 , 1 , 0 , 0 , 0 , 0 , 0 ;...
	 0 , 0 , 0 ,-1 , 0 , 0 , sign(sigz-X) , 0, 0  ;...
	 sign(sigz-X) , 0 , 0 , 0 ,-1 , 0 , 0 , -sign(sigz-X) , 0 ;... 
	 0 , 0 , 0 , 0 , 0 ,-1 , 1 , 0 , 0 ;...
	 0 , 0 , 0 , C , 0 , -g*X , 0 , -1 , 0 ;...
	 0 , 0 , 0 , 0 , 0 , 0 , -1, 0 , 0 ; ...
	 0 , 0 , 0 , 0 , 0 , b*(Q-R) , 0 , 0 , -1 ] ;


% asservissement

impose =  [ 0 ; 0 ; 0 ; 0 ; 0 ; 0 ; 0 ; 0 ; 0]  ;
j=0 ;
for i=1:length(type_var)
    if strcmp(type_var(i),'asservi')==1
        j=j+1 ;
        A(j,i)  = 1 ;
        impose(j)=var_asservi_dot(i) ; 
    end
end 

var_dot = A \ impose ; 
sigeq_dot = var_dot(5) ;

if (sigeq-R-sigy)>0 & sigeq_dot>0
    A (8,7)=0 ; A (8,5)=-1 ; A (8,9)=1 ;
    var_dot = A \ impose ; 
end