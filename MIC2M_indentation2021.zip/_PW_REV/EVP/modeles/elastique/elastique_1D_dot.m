function var_dot=elastique_1D_dot(t,var,flag,nom_para,para,type_var,num_var,nom_var,var_asservi_dot)

% parametres
assignation_para(nom_para,para)

% variables
assignation_var(nom_var,var) 
assignation_var_asservi_dot(nom_var,var_asservi_dot) 


epsinz_dot = 0 ;

A = [ 0 , 0 , 0 , 0 ; ...
	-1 , 0 , E , 0 ; ...
	 0 ,-1 , 1 , 1 ; ...
	 0 , 0 , 0 , -1	] ;

% asservissement
impose = [ 0 ; 0  ; 0 ; epsinz_dot ] ;

j=0 ;
for i=1:length(type_var)
    if strcmp(type_var(i),'asservi')==1
        j=j+1 ;
        A(j,i)  = 1 ;
        impose(j)=var_asservi_dot(i) ; 
    end
end 

var_dot = A \ impose ;  