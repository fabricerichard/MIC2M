function [var_dot] = elastique_3D_dot(t,var,flag,nom_para,para,type_var,num_var,nom_var,var_asservi_dot)

% parametres
assignation_para(nom_para,para)

% variables
assignation_var(nom_var,var) 
assignation_var_asservi_dot(nom_var,var_asservi_dot) 

sig     = [ sigr     ; sigt     ; sigz  ; sigtz ;  sigrz  ; sigrt  ] ;
eps     = [ epsr     ; epst     ; epsz  ; epstz  ; epsrz  ; epsrt  ] ; 

G = E/ (2*(1+Nu)) ;

Sij = [	1/E,-Nu/E,-Nu/E,0,0,0 ;...
 	-Nu/E,1/E,-Nu/E,0,0,0 ;...
 	-Nu/E,-Nu/E,1/E,0,0,0 ;...
	0,0,0,1/G,0,0         ;...
	0,0,0,0,1/G,0         ;...
	0,0,0,0,0,1/G ] ;
Cij = inv(Sij) ;

epsin_dot = zeros(6,1) ;

A = [ 	zeros(6,24) ; ...
	-eye(6,6) , zeros(6,6) , Cij        , zeros(6,6) ; ...
	zeros(6,6), -eye(6,6)  , eye(6,6)   , eye(6,6)   ; ...
	zeros(6,6), zeros(6,6) , zeros(6,6) , eye(6,6) ] ;

% asservissement
impose = [ zeros(6,1) ; zeros(6,1) ; zeros(6,1) ; epsin_dot ] ;

j=0 ;
for i=1:length(type_var)
    if strcmp(type_var(i),'asservi')==1
        j=j+1 ;
        A(j,i)  = 1 ;
        impose(j)=var_asservi_dot(i) ; 
    end
end   

var_dot = A \ impose ;  