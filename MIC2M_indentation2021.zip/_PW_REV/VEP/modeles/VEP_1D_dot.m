function [var_dot] = linv2_1D_dot(t,var,flag,nom_para,para,type_var,num_var,nom_var,var_asservi_dot)

% parametres
assignation_para(nom_para,para)

% variables
assignation_var(nom_var,var) 
assignation_var_asservi_dot(nom_var,var_asservi_dot) 

% anelastique
epsanz_dot = (1/n*(sigz-X1)) ;
a1_dot = 1/n*(sigz-X1) ;
X1_dot = C1*a1_dot ;

% viscoplastique
%f = abs(sigz-X2) - sigY + 0.5*g/C2*X2^2 - 0.5*g*C2*a2^2 ; % equivalent � f = abs(sigz-X2) - sigY
%epseq_dot = (max(f,0)/K) ;
%epsvpz_dot = epseq_dot * sign(sigz-X2) ;
%a2_dot = epseq_dot * ( sign(sigz-X2)- g/C2*X2 ) ; 
%X2_dot = C2*a2_dot ;

% inelastique
epsinz_dot =  epsanz_dot + epsvpz_dot  ;

% asservissement
impose = zeros(5,1) ;
impose(4) = epsvpz_dot  ;
impose(5) = epsanz_dot  ;

%%%%%%%%%%%%%%%%%%%%%%%%
A =		[ 0 ,0, 0, 0,0   ;                % sigz_dot
       	  0 ,1,-1,-1,-1  ;                % epsz_dot - epsez_dot - epsvpz_dot - epsvez_dot= 0
	      -1 ,0, E, 0, 0 ;                % E*epsez_dot - sigz_dot = 0
          0 ,0, 0, 1, 0  ;                % epsvpz_dot 
		  0 ,0, 0, 0, 1  ] ;              % epsanz_dot
      
% asservissement
j=0 ;
for i=1:length(type_var)
    if strcmp(type_var(i),'asservi')==1
        j=j+1 ;
        A(j,i)  = 1 ;
        impose(j)=var_asservi_dot(i) ;
    end
end   
var_dot = A \ impose ;  

var_dot = [ var_dot ; a1_dot ; a2_dot ; X1_dot ; X2_dot ] ;


