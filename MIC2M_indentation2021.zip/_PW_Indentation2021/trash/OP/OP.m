load res.txt;
load AC.txt;
ANGLE=70.3;

%aire projettée
aire=AC(:,1).*sin(ANGLE*pi/180);
%début de décharge
DC=find (res(:,1)==50);
FM=-res(DC,3);
%Fin de décharge
%Attention au seuil 0.5*force max
FC=DC+length (find (-res(DC:end,3)>0.5*FM))-1;
%on isole la décharge
SegDeg=res(DC:FC,:);
%Profondeur résiduelle
hr=-res(FC,2);
%Régression linéaire
abs=-SegDeg(:,2);
ord=-SegDeg(:,3);
a=[abs,abs];
a(:,1)=1;
M1=a'*a;
M2=a'*ord;
sol=inv(M1)*M2;
Stiff=sol(2,1);
%Module et dureté
Dur=-res(:,3)./aire ; plot(-res(:,2),Dur,'o'); hold on
Mod=0.5*Stiff/(aire(DC)/pi)^0.5;
