

% resultat EF brut
load res.txt 
load AC.txt
load profil.txt ; profil = sortrows(profil,1);
load profil_re.txt ; profil_re = sortrows(profil,1);

% resultat EF fitte
load hmax.txt
load Pmax.txt
load I_Pmax.txt I_Pmax -ascii
load EOP.txt
load HOP.txt
load Mod.txt
load Mods.txt
load Dur.txt
load Durs.txt


%close all
figure(10)

subplot(2,2,1) ; 
xx='\it{h }\rm(\mum)' ;
yy='\it{P }\rm(mN)' ; 
tt='Indentation curve' ;
plot(-res(:,2),-res(:,3),'+r') ; hold on ; 
plot(h,P) ; hold on ; 
a=title(tt)  ; set(a,'fontsize',15,'FontName','Cambria') ; 
legend('FE result','fitted')  ;
a=xlabel(xx) ; set(a,'fontsize',25,'FontName','Cambria')
a=ylabel(yy) ; set(a,'fontsize',25,'Rotation',90,'FontName','Cambria')
axis square ; box on ; grid on; 
V=axis ;
%axis([V(1) V(2) V(3) V(4)]);

subplot(2,2,2) ; 
xx='\it{(h/h_m_a_x)^2 }' ;
yy='\it{P/P_m_a_x }' ;
tt='Non-dimensional indentation curve' ;
plot(h.^2/hmax^2,P./Pmax) ; hold on
%plot(h(1:I_Pmax).^2./hmax^2,(h(1:I_Pmax)./hmax).^2,'o') ; hold on
a=title(tt)  ; set(a,'fontsize',15,'FontName','Cambria') ; 
a=xlabel(xx) ; set(a,'fontsize',25,'FontName','Cambria') ; 
a=ylabel(yy) ; set(a,'fontsize',25,'Rotation',90,'FontName','Cambria')
axis square ; box on ; grid on; 


subplot(2,2,3) ; 
xx='\it{X }\rm(\mum)' ;
yy='\it{Z \rm(\mum)}' ; 
tt='Residual profil' ;
plot(profil(:,1),profil(:,2),'+r') ; hold on ; 
plot(profil_re(:,1),profil_re(:,2)) ; hold on ; 
a=title(tt)  ; set(a,'fontsize',15,'FontName','Cambria') ; 
legend('FE result','resample')  ;
a=xlabel(xx) ; set(a,'fontsize',25,'FontName','Cambria') ; 
a=ylabel(yy) ; set(a,'fontsize',25,'Rotation',90,'FontName','Cambria')
axis square ; box on ; grid on; 
%axis([V(1) V(2)*10 -V(2) V(2)/5]);

subplot(2,2,4) ; 
xx='\it{X/h_m_a_x}' ;
yy='\it{Z/h_m_a_x}' ; 
tt='Non-dimensional residual profil' ;
%plot(profil(:,1),profil(:,2),'+k') ; hold on ; 
plot(X/hmax,Z-1) ; hold on ; 
a=title(tt)  ; set(a,'fontsize',15,'FontName','Cambria') ; 
a=xlabel(xx) ; set(a,'fontsize',25,'FontName','Cambria') ; 
a=ylabel(yy) ; set(a,'fontsize',25,'Rotation',90,'FontName','Cambria')
axis square ; box on ; grid on; 
%axis([V(1) V(2)*10 -V(2) V(2)/5]);


% 
% figure(11)
% subplot(2,1,1) ; 
% xx='\it{h_m_a_x }\rm(\mum)' ;
% yy='\it{Modulus }\rm(GPa)' ; 
% tt='OP Modulus' ;
% %plot(hmax,Mod,'+k') ; hold on ; 
% %plot(hmax,Mods,'or') ; hold on ; 
% plot(hmax,EOP,'sk') ; hold on ; 
% 
% hLine =plot(hmax,EOP,'ok') ; hold on ; 
% cursorMode = datacursormode(gcf);
% set(cursorMode, 'enable','on')
% datatip = cursorMode.createDatatip(handle(hLine));
% % X,Y position at which to place the datatip
% set(datatip, 'Position', [h(I_Pmax),EOP])
% a=title(tt)  ; set(a,'fontsize',15,'FontName','Cambria') ; 
% a=xlabel(xx) ; set(a,'fontsize',25,'FontName','Cambria')
% a=ylabel(yy) ; set(a,'fontsize',25,'Rotation',90,'FontName','Cambria')
% axis square ; box on ; grid on ; 
% axis([0 2 150 400]);
% 
% subplot(2,1,2) ; 
% xx='\it{h_m_a_x }\rm(\mum)' ;
% yy='\it{Hardness }\rm(GPa)' ; 
% tt='OP Hardness' ;
% %plot(h,Dur,'+k') ; hold on ; 
% %plot(h,Durs,'.-') ; hold on ;
% hLine = plot(hmax,HOP,'sk') ; hold on ; 
% cursorMode = datacursormode(gcf);
% set(cursorMode, 'enable','on')
% datatip = cursorMode.createDatatip(handle(hLine));
% % X,Y position at which to place the datatip
% set(datatip, 'Position', [hmax,HOP])
% 
% a=title(tt)  ; set(a,'fontsize',15,'FontName','Cambria') ; 
% a=xlabel(xx) ; set(a,'fontsize',25,'FontName','Cambria')
% a=ylabel(yy) ; set(a,'fontsize',25,'Rotation',90,'FontName','Cambria')
% axis square ; box on ; grid on ; 
% axis([0 2 0 50]);
% 
% figure(10)
