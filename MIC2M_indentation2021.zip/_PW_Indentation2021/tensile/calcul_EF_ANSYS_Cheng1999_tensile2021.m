function [time,sortie,test_rupture,sortie_aux]=calcul_EF_ANSYS_nano2D(nom_modele,nom_para,valeur_para,type_var,num_var,nom_var,var_0,type_entree,nom_entree,entree,temps,nligne,mode)

test_rupture=0 ;
sortie_aux=0 ;

%mode='i'
format long

% entree : on retrouve 2 colonnes UY et FY exp�rience
% sortie : on retrouve 2 colonnes UY et FY mod�le
% en mode identification, l'erreur est au sens des moindres carr�s sur les
% observations (entree-sortie)

assignation_para(nom_para,valeur_para) ;
valeur_para
nom_para

% % r�cup�ration de la force et du deplacement
nbligne=cellstr('nbligne') ;
TF=cellstr('TF') ;

sigz=-entree(:,1);
epsz=entree(:,2);

essai =[temps sigz epsz] ;
save temps.txt temps -ascii
save sigz.txt sigz -ascii
save epsz.txt epsz -ascii

for i=1:length(temps)
charge(2*i-1,1)   = temps(i);
%charge(2*i,1) = sigz(i);
charge(2*i,1) = exp(epsz(i))-1;

end
save charge.txt charge -ascii

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ECRITURE DU FICHIER ANSYS inputansys.txt %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

fich_commande = 'input_ansys_Cheng1999_tensile2021.txt' 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ccc=0.5;
cc=1;

eeps(1)=sigy/E ; ssig(1)=sigy;
eeps(2)=3 ; ssig(2)=sigy;

if n>0     
    while cc==1
     ccc=ccc*2;
     clear eeps ssig
     eeps(1)=sigy/E ; ssig(1)=sigy;
     K=sigy*(E/sigy)^n;
     ddd1=(1.001*sigy/K)^(1/n)-eeps(1);

     i=1;
     while eeps(i)<3
         eeps(i+1)=eeps(i)+(ddd1*i^1)*ccc;
          ssig(i+1)=K*eeps(i+1)^n ;
          i=i+1;
     end
     if i<99 ; cc=0 ; end
    end
end

courbe=[0,eeps;0,ssig]';
%plot(courbe(:,1),courbe(:,2),'-ro')
%plot(courbe(:,1),courbe(:,2)./1000,'-ro')
%pause

%save courbe.txt courbe -ascii
com='! zoubidou' ; B=[cellstr(com)] ;
com=['TB,MISO,1,1,',num2str(size(courbe,1),'%16.10g')] ; B=[cellstr(com)] ;
llc=['TBPT,,0,0'] ; B=[B;cellstr(llc)] ;
for i=1:size(courbe,1)-1   ;  
    llc=['TBPT,,',num2str(eeps(i),'%16.10g'),',',num2str(ssig(i),'%16.10g')] ; B=[B;cellstr(llc)] ;
  end
fid = fopen('courbebis.txt','w');
for i=1:size(B,1)   ;  fprintf(fid,'%s\n',char(B(i))) ; end
fclose('all');


disp('traitement fichier commande')

B = remplace(fich_commande,'################','%16.10g',([nom_para' nbligne TF]'),[valeur_para' length(temps) temps(length(temps))]');

fid = fopen('inputansys.txt','w') ;
for i=1:size(B,1)   
    fprintf(fid,'%s\n',char(B(i))) ;
end
fclose('all');

%%%%%%%%%%%%%%%%%%%
% LANCEMENT ANSYS %
%%%%%%%%%%%%%%%%%%%

%! "C:\Program Files\ANSYS Inc\v145\ANSYS\bin\Intel\ansys145.exe"  -p aa_t_i -dir "C:\MIC2M" -j "file" -s read -l en-us -b -i "C:\MIC2M\inputansys.txt" -o "C:\MIC2M\file.out"   
%! "C:\Applications-FEMTO-ST\Ansys16\v160\ANSYS\bin\winx64\ansys160.exe"  -p aa_t_i -dir "C:\MIC2M" -j "file" -s read -l en-us -b -i "C:\MIC2M\inputansys.txt" -o "C:\MIC2M\file.out"   
run_soft(fich_commande,'ansys')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%traitement des sorties pour les modes simulation et identification %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

load 'fdisp.txt';
temps_sim=fdisp(:,1);
sigz=fdisp(:,2)/1000 % passage en GPa !!
epsez=fdisp(:,3);
epsinz=fdisp(:,4);
epser=fdisp(:,5);
epsinr=fdisp(:,6);


mode='i'
if strcmp(mode,'i')==1
     
    %load temps.txt ;
   % res=textread('res.txt','%f','delimiter','\n','whitespace','','headerlines',1) ;
    temps_sim=[0;temps_sim] ; 
    sigz=[0;sigz] ;  epsz=[0;epsez+epsinz] ; epsez=[0;epsez] ;  epsinz=[0;epsinz] ;  %epsr=[0;epsr] ;  epsinr=[0;epsinr] ;
   % for i=1:length(temps_sim)
   %     if (res(i)~=0) & (res(i+1)~=0)
   %         temps_sim = [temps_sim ; res(i)] ;
   %         UY = [UY;res(i+2)]  ;%%%%%%%%%%%%%%%%ATTENTION
   %         FY = [FY;res(i+1)]  ;
   %     end
   % end

    sortie=[sigz(1),epsz(1),epsez(1),epsinz(1)] ; time(1,1)=temps_sim(1,1) ;
    for i=2:length(temps)-1
        time(i,1)=temps(i,1);
        length(temps);
        length(temps_sim);

        j = min(find(temps_sim>=temps(i))) ;
        sortie(i,1)=((sigz(j)-sigz(j-1))/(temps_sim(j)-temps_sim(j-1))*(temps(i)-temps_sim(j-1))+sigz(j-1)) ;
        sortie(i,2)=(epsz(j)-epsz(j-1))/(temps_sim(j)-temps_sim(j-1))*(temps(i)-temps_sim(j-1))+epsz(j-1) ;
        sortie(i,3)=(epsez(j)-epsez(j-1))/(temps_sim(j)-temps_sim(j-1))*(temps(i)-temps_sim(j-1))+epsez(j-1) ;
        sortie(i,4)=(epsinz(j)-epsinz(j-1))/(temps_sim(j)-temps_sim(j-1))*(temps(i)-temps_sim(j-1))+epsinz(j-1) ;

    end
    i=i+1 ;
    time(i,1)=temps(i,1);
    j = length(temps_sim) ;
    sortie(i,1)=((sigz(j)-sigz(j-1))/(temps_sim(j)-temps_sim(j-1))*(temps(i)-temps_sim(j-1))+sigz(j-1)) ;
    sortie(i,2)=(epsz(j)-epsz(j-1))/(temps_sim(j)-temps_sim(j-1))*(temps(i)-temps_sim(j-1))+epsz(j-1) ;
    sortie(i,3)=(epsinz(j)-epsinz(j-1))/(temps_sim(j)-temps_sim(j-1))*(temps(i)-temps_sim(j-1))+epsinz(j-1) ;
    %ajout de l'empreinte (ici pas d'interpolation, donc le maillage
    %experimenatl doit correspondre au maillage du mod�le)
    sortie=[sortie];
    
end    

if strcmp(mode,'s')==1
    temps_sim=[0;temps_sim] ; 
    sigz=[0;sigz] ;  epsez=[0;epsez] ;  epsinz=[0;epsinz] ;% epser=[0;epser] ;  epsinr=[0;epsinr] ;
    time = temps_sim ;
    %sortie=[sigz epsez+epsinz epser+epsinr epsez epser epsinz epsinr];  
    sortie=[sigz epsez+epsinz  epsez epsinz];   

    %disp('partie non valide')
%     res=textread('res.txt','%f','delimiter','\n','whitespace','','headerlines',1) ;
%     time=0 ; UY=0 ;   FY=0 ;
%     for i=1:3:length(res)
%         if (res(i)~=0) & (res(i+1)~=0)
%             time = [time;res(i)] ;
%             UY = [UY;res(i+2)]  ;%%%%%%%%%%%%%%%%ATTENTION
%             FY = [FY;res(i+1)]  ;
%         end  
%     end
%     sortie=[UY,FY] ;
%     time;
end

test_rupture=0 ;
sortie_aux=sortie ;




   

