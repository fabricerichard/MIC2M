clear all
hold on

k_iteration = 1 ; save k_iteration.txt k_iteration -ascii ; % initialisation du compteur

% CHOIX DU MODELE 
%liste_modele = textread(['liste_modele','.txt'],'%s') ;
%disp(' ')
%for i=1:size(liste_modele,1) ; disp(['(',num2str(i),')','  ',char(liste_modele(i))]) ; end  
%disp(' ') ; 
%choix = input('CHOIX : ') ; 

%if choix==0 ; nom_du_modele='BATCH' ; 
    [s,ident,essais,model] = textread(['liste_experiences.txt'],'%s %s %s %s') ;
    for i=2:length(s) 
        if strcmp( ident(i),'%')==0 
            nom_du_modele=char(model(i)) ;
        end
    end
%else
    %nom_du_modele = char(liste_modele(choix)) 
%end

fid = fopen('nom_du_modele.txt','w');
for i=1:size(char(nom_du_modele),2)   ;  fprintf(fid,'%s',char(nom_du_modele(i))) ; end
fclose('all');


% lecture parametre
%fich_parametre = [char(nom_du_modele),'_parametres'] ;
%[nom_para,para_nom,a,b,loi,CV] = textread([fich_parametre,'.txt'],'%s %f %f %f %f %f') 
%V=[para_nom,a,b,loi,CV] ;


% lecture parametre
nom_fich = [char(nom_du_modele),'_parametres'] 
%[nom_para,para_nom,a,b,loi,CV] = textread([fich_parametre,'.txt'],'%s %f %f %f %f %f') ; ancien code matlab
%T = textread([fich_parametre,'.txt'],'%s','delimiter','\n');nombre_de_lignes = size(T,1) ;
fid = fopen([nom_fich,'.txt'],'r') ; X = fread(fid) ; fclose(fid) ; nombre_de_lignes = sum(X==10) ;
fid = fopen([nom_fich,'.txt']) ; C = textscan(fid, '%s %f %f %f %f %f', nombre_de_lignes) ; fclose(fid) ;
[nom_para,para_nom,a,b,loi,CV] = C{:} ;
V=[para_nom,a,b,loi,CV] ;



% CHOIX DU MODELE DE RESOLUTION
[sensi]=derive1('fsensi',V,1) ;
%plot(Sit(:,1),Sit(:,2))
eval(['save  sensi.txt sensi -ascii']) ;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%close all

clear all
load sensi.txt

etude=[1];
for i=2:size(sensi,2)
      etude=[etude,i] ;
end

etude
%etude=[1 2  4  ]

%load sensi1.txt ; %load sensi2.txt ; %sensi=[sensi1;sensi2];
%load sensi_film_emmousse.txt
%sensi=sensi_film_emmousse(1:100,:);
%sensi=sensiH;cloase
%sensi=sensiBR;
% E, pr, Sigy, Hardi, Beta, Epsd, S, T
% Je
% load J_LM.txt
% load P_LM.txt
% et_essai=1e-4
% inv(J_LM(:,etude)'*J_LM(:,etude))
% c_v1=2*diag(inv(J_LM(:,etude)'*J_LM(:,etude))).^.5./P_LM*et_essai
% %bar(c_v1)
% 
% 
% load J.txt
% load P.txt
% et_essai=1e-4
% inv(J(:,etude)'*J(:,etude))
% c_v2=2*diag(inv(J(:,etude)'*J(:,etude))).^.5./P*et_essai
% c_v2=(2*diag(inv(J(:,etude)'*J(:,etude))).*et_essai).^.5
% 
% bar(c_v2)


N=size(sensi,1) ;
np=size(sensi,2) ;


sensi=(sensi(1:1:N,:));
N=size(sensi,1) ;


%fisher=sensi'*sensi;
%real(max(eig(fisher)))/min(eig(fisher))

for i = 1:np
    deltam_sqr(i)  = 1 * norm((sensi(:,i)),2) ; %/N^.5 deja dans sensi
    deltam_abs(i)  = 1/N^.5 * norm((sensi(:,i)),1) ; %/N^.5 deja dans sensi
    deltam_mean(i) = N^.5 * mean(sensi(:,i)) ; %/N^.5 deja dans sensi
    deltam_max(i)  = N^.5 * max (sensi(:,i)) ; %/N^.5 deja dans sensi
    deltam_min(i)  = N^.5 * min (sensi(:,i)) ;  %/N^.5 deja dans sensi
end

delta = [deltam_sqr ; deltam_abs  ; deltam_mean ; deltam_max ; deltam_min] ;
%delta = deltam_sqr
delta = deltam_abs ;
%delta = deltam_mean
%delta = deltam_max


%deltam_min]
%fisher=sensi(:,[1,2,3,4])'*sensi(:,[1,2,3,4]);e=eig(fisher);Je=max(e)/min(e)
figure(1) ; %hold on
bar(delta(etude))


% E, pr, Sigy, Hardi, Beta, Epsd, S, T
%plot(sensi)
save delta.txt delta -ascii


Je(1)=1e10 ;
%for i=round(N/100):N
N;
for i=1:N

    fisher=sensi(1:i,etude)'*sensi(1:i,etude);e=eig(fisher);
    Je(i)=real(max(e)/min(e)) ; 
    detJe(i)=real(det(fisher)^(1/length(etude))) ;
    if Je(i)<1e-4 ;  Je(i)=1e10  ; end
    I(i) = log10(Je(i)) ;

end
save fisher.txt fisher -ascii

%load P.txt

%erreur=1e-2
%c_v=(diag(inv(fisher(:,etude)'*fisher(:,etude)))).^.5./P
%c_v=(diag(inv(fisher'*fisher))).^.5

IndiceI=log10(Je(length(Je))) ;
['I-index = ',num2str(IndiceI)]

% 
figure(2)
%load temps.txt
%plot(temps,log10(Je)); hold on
plot(log10(Je)); hold on
set(gca,'FontName','Times New Roman','fontsize',35)
%title('I-Index')
axis([0 length(Je) 0 6])
%xlabel('% de l''essai','FontSize',35,'FontName','Times New Roman');
xlabel('nombre de mesures','FontSize',35,'FontName','Times New Roman');

ylabel('{I-index}','FontSize',35,'FontName','Times New Roman');
axis square
box on
grid


% % BRUN
% %load sensi.txt
% %N=size(sensi,1) ;
% %np=size(sensi,2) ;
% %sensi=(sensi(2:N,:));
% %N=N-1;
% 
% Jb(1)=100 ; 
% for i=round(N/5):N
%     for u=1:np
%         %if norm(sensi(1:i,u))>1e-12
%             sensit(1:i,u) = sensi(1:i,u)/norm(sensi(1:i,u)) ;
%         %else
%         %    sensit(1:i,u) = 1e-12*sensi(1:i,u) ;
%         %end
%         deltam_abs(i,u)  = 1/N    * norm((sensi(1:i,u)),1) ;
%     end
%     rapport_deltam_abs(i)  = max(deltam_abs(i,:))./min(deltam_abs(i,:)) ;
% 
%     fishert=sensit(1:i,etude)'*sensit(1:i,etude);e=eig(fishert);
%     Jb(i)=real(1/(min(e))^.5) ; detJb(i)=det(fishert)^(1/length(etude)) ;
%     if Jb(i)<1e-3 ; Jb(i)=100 ;end ;
%     if Jb(i)>100 ; Jb(i)=100  ;end
%    
% end
% 
% %diag(inv(fisher(:,etude)'*fisher(:,etude))).^.5
% figure(3)
% load temps.txt
% %plot(temps/max(temps)*100,Jb); hold on
% plot(Jb); hold on
% set(gca,'FontName','Times New Roman','fontsize',35)
% title('critere BRUN')
% axis([0 length(Jb) 0 50])
% xlabel('nombre de mesures','FontSize',35,'FontName','Times New Roman');
% ylabel('{J_B}','FontSize',35,'FontName','Times New Roman');
% axis square
% grid
% 
% 
% IndiceBrun=Jb(length(Jb))
% 
% 
% 
% %figure(5)
% %subplot(1,2,1)
% %load resultat
% %sigz=resultat(:,2);
% %epsz=resultat(:,3);
% %plot(epsz,sigz,'ok'); hold on
% 
% %set(gca,'FontName','Cambria','fontsize',35)
% %title('critere JE')
% %axis([0 epsz(length(Je)) 0 sigz(length(Je))])
% %xlabel('% de l''essai','FontSize',35,'FontName','Times New Roman');
% %xlabel('\it{\epsilon} \rm','FontSize',35,'FontName','Cambria');
% %ylabel('\it{\sigma} \rm(MPa)','FontSize',35,'FontName','Cambria');
% %axis square
% %box on
% %axis square
% %grid
% 
% %subplot(1,2,2)
% %load temps.txt
% %plot(temps,log10(Je)); hold on
% %load epsz.txt
% %epsz=log(1+epsz)
% %plot(epsz,log10(Je),'ok'); hold on
% %set(gca,'FontName','Cambria','fontsize',35)
% %title('critere JE')
% %axis([0 epsz(length(Je)) 0 6])
% %xlabel('% de l''essai','FontSize',35,'FontName','Times New Roman');
% %xlabel('\it{\epsilon} \rm','FontSize',35,'FontName','Cambria');
% %ylabel('indice J','FontSize',35,'FontName','Script MT Bold');
% %axis square
% %box on
% %grid
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
% 
% % for i=1:size(sensi,2)
% %     for j=1:size(sensi,2)
% %         MACMat(i,j)=abs(sensi(:,i)'*sensi(:,j))^2/( norm(sensi(:,i))^2*norm(sensi(:,j))^2 );
% %         if norm(sensi(:,i))<1e-6 | norm(sensi(:,j))<1e-6 
% %             MACMat(i,j)=1 ; disp('attention faible norme'); 
% %         end 
% %     end
% % end
% % 
% % 
% % for i=1:size(sensi,2)
% %     for j=1:size(sensi,2)
% %         MACMatBRUN=[sensit(:,i) sensit(:,j)]'*[sensit(:,i) sensit(:,j)] ;
% %         e=eig(MACMatBRUN) ;
% %         MACJb(i,j)=(1/(min(e))^.5) ; 
% %         %if MACJb(i,j)>20 ; MACJb(i,j)=20 ; end
% %     end
% % end
% % 
% % for i=1:size(sensi,2)
% %     for j=1:size(sensi,2)
% %         MACMatJe=[sensi(:,i) sensi(:,j)]'*[sensi(:,i) sensi(:,j)] ;
% %         e=eig(MACMatJe) ;
% %         MACJe(i,j)=max(eig(MACMatJe))/min(eig(MACMatJe));
% %         %if MACJe(i,j)>1000 ; MACJe(i,j)=1000 ; end
% %     end  
% % end
% % 
% % MACJb
% % MACJe
% %  
% % 
% %    
% % 
% % figure(6)
% % [l c] = size(MACJb) ;
% % MACJb = [MACJb zeros(l,1)] ;
% % MACJb = [MACJb ; zeros(1,c+1)] ;
% % [l c] = size(MACJb) ;
% % colormap(cool) ;
% % colormap(gray(4))
% % pcolor(MACJb) ;
% % colorbar ;
% % xlabel('\it{\theta_i}','FontSize',30,'FontName','Times New Roman');
% % ylabel('\it{\theta_j}','FontSize',30,'FontName','Times New Roman');
% % title('JB matrix (Brun criteria)','FontSize',20,'FontName','Times New Roman');
% % axis square    
% % 
% % 
% % figure(7)
% % [l c] = size(MACJe) ;
% % MACJe = [log10(MACJe) zeros(l,1)] ;
% % MACJe = [MACJe ; zeros(1,c+1)] ;
% % [l c] = size(Je) ;
% % colormap(cool) ;
% % colormap(gray(4))
% % pcolor(MACJe) ;
% % colorbar ;
% % tiX2tle('Je matrix') ;
% % xlabel('parameter 2') ;
% % ylabel('parameter 1') ;
% % axis square    
% % 
% % 
% % %[Y,I] = min(Je)
% % [log10(min(Je)) min(Jb)]
% 
