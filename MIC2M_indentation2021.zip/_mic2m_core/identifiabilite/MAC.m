clear all

load fisher.txt

real(max(eig(fisher))/min(eig(fisher)))
CV=pinv(fisher) 
diag(CV)
s

for i=1:size(fisher,2)
    for j=1:size(fisher,2)
        MACMat(i,j)=abs(s(:,i)'*s(:,j))^2/( norm(s(:,i))^2*norm(s(:,j))^2 );
        if norm(s(:,i))<1e-6 | norm(s(:,j))<1e-6 
            MACMat(i,j)=1 ; disp('attention faible norme'); 
        end
       
        CR(i,j)= CV(i,j)/(CV(i,i)*CV(j,j))^.5 ;
        CR=abs(CR);
        
        MACMatBRUN=[st(:,i) st(:,j)]'*[st(:,i) st(:,j)] ;
        e=eig(MACMatBRUN) ;
        Jb(i,j)=(1/(min(e))^.5) ;
        
        MACMatJe=(max(eig(fisher))/min(eig(fisher)))
        Jb(i,j)=(1/(min(e))^.5) ;

        
        %MACMatfisher(i,j)=max(e)/min(e);
        %if i==j ; Je(i,j)=1;  end
        %if Je(i,j)>10000; Je(i,j)=10000 ; end

       end    
end


%MACMat
CR
%Jb
% 
% figure(1)
% 
% [l c] = size(MACMat) ;
%     MACMat = [MACMat zeros(l,1)] ;
%     MACMat = [MACMat ; zeros(1,c+1)] ;
%     [l c] = size(MACMat) ;
%     colormap(cool) ;
%     colormap(gray(4))
%     pcolor(MACMat) ;
%     colorbar ;
%     title('MACMat matrix') ;
%     xlabel('parameter 2') ;
%     ylabel('parameter 1') ;
  
    

figure

[l c] = size(CR) ;
    CR = [CR zeros(l,1)] ;
    CR = [CR ; zeros(1,c+1)] ;
    [l c] = size(CR) ;
    colormap(cool) ;
    colormap(gray(10))
    pcolor(CR) ;
    colorbar ;
xlabel('\it{\theta_i}','FontSize',30,'FontName','Times New Roman');
ylabel('\it{\theta_j}','FontSize',30,'FontName','Times New Roman');
title('Correlation Matrix (CR)','FontSize',20,'FontName','Times New Roman');
axis square    
   


figure
[l c] = size(Jb) ;
    Jb = [Jb zeros(l,1)] ;
    Jb = [Jb ; zeros(1,c+1)] ;
    [l c] = size(Jb) ;
    colormap(cool) ;
    colormap(gray(4))
    pcolor(Jb) ;
    colorbar ;
    title('Jb matrix') ;
    xlabel('parameter 2') ;
    ylabel('parameter 1') ;

TraceMac(MACMat)
