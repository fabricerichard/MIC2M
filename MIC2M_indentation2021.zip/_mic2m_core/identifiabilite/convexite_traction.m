%close all
clear all

% valeur des parametres identifies (nombre egale au nombre de colonnes du
% fichier sensi.txt
%P = [417.2 5.66 404.9]
%P = [5.66 404.9]
P = [200000 1240]

% valeur la fonction objective obtenue
%w=8.1e-6
w=1e-6
%
% le set de parametres etudie
etude=[1 2 ]

% recuperation des sensibilites calculees a l'aide de <identifiabilite.m>
load sensi.txt
sensi=sensi;
%sensi=sensi(1:62,:).*(size(sensi,1)/62)^.5*3.22/1.43;
%sensi=sensi(1:21,:).*(size(sensi,1)/21)^.5*(82/20);
%npara=size(sensi,2);
%P=zeros(1,npara)
%P(etude(1))=para(1);
%P(etude(2))=para(2);

fisher=sensi(:,etude)'*sensi(:,etude);e=eig(fisher);
Hb=fisher;

log10(real(max(e)/min(e)))

nbpara=length(P);

for i =1:nbpara
for j =1:nbpara
H(i,j)=Hb(i,j)/P(i)/P(j);
end
end

% incertitude relative
Vb=inv(Hb)
for i =1:nbpara
    Dr(i)=(2*Vb(i,i)*w)^0.5;
end
Dr
% incertitude absolue
V=inv(H)
for i =1:nbpara
    D(i)=(2*V(i,i)*w)^0.5;
    %D(i)=(2*Vb(i,i)*w)^0.5*P(i);
end
D


%%%%%%%%%%%%%%%%%%%%%%%%%%
%%graphe si 2 param�tres
%%%%%%%%%%%%%%%%%%%%%%%%%%
pp1=1;
pp2=2;

P1=P(pp1);
P2=P(pp2);

%[x,y] = meshgrid(-5e-1:1e-3:5e-1);
[x,y] = meshgrid(-.15:1e-3:.15);

X=x ;
Y=y ;

X=x*P1+P1 ;
Y=y*P2+P2 ;

xx=x*P1 ;
yy=y*P2 ;

z= 0.5*((Hb(pp1,pp1)*x+Hb(pp1,pp2)*y).*x+(Hb(pp2,pp1)*x+Hb(pp2,pp2)*y).*y) ;
%Z= 0.5*((H(pp1,pp1)*xx+H(pp1,pp2)*yy).*xx+(H(pp2,pp1)*xx+H(pp2,pp2)*yy).*yy) ;


figure(10)
hold on

[C,h] = contour(x,y,z,[1e-4 1e-5 1e-6],'r');

%set(h,'ShowText','on','TextStep',get(h,'LevelStep')*2)
%colormap cool
%colormap gray
axis square

%plot(P1,P2,'ob')
%plot(0,0,'ob')


%(Vb(1,1)/Vb(2,2))^.5

VVb = inv([Hb(pp1,pp1) Hb(pp1,pp2) ; Hb(pp2,pp1) Hb(pp2,pp2)]) ;
Dx_x=(2*VVb(1,1)*w)^0.5
Dy_y=(2*VVb(2,2)*w)^0.5

%Dx=(2*VVb(1,1)*w)^0.5*P1;
%Dy=(2*VVb(2,2)*w)^0.5*P2;


%make some arbitrary rectangle (in this case, located at (0,0) with [width, height] of [10, 20])
rect_H = rectangle('Position', [-Dx_x, -Dy_y, 2*Dx_x, 2*Dy_y],'LineWidth',2,'LineStyle','--'); 
%rect_H = rectangle('Position', [P1-Dx, P2-Dy, 2*Dx, 2*Dy]); 

%set(rect_H, 'EdgeColor', [0, 1, 0])%sets the edge to be green
%set(rect_H, 'EdgeColor', [0, 0, 0])%sets the edge to be noir
set(rect_H, 'EdgeColor', [1, 0, 0])%sets the edge to be rouge
%griset(rect_H, 'EdgeColor', [0, 0, 1])%sets the edge to be bleu

hold on


set(gca,'FontName','Cambria','fontsize',35)
title('isovaleurs de la fonction erreur')
xlabel('\DeltaE/E','FontSize',35,'FontName','Cambria');
ylabel('\Delta\sigma_{y}/\sigma_{y}','FontSize',35,'FontName','Cambria');
%xlabel('E (MPa)','FontSize',35,'FontName','Cambria');
%ylabel('\sigma_{y} (MPa)','FontSize',35,'FontName','Cambria');
axis square ; box on ; grid

%E,\sigma_{y},n