function TraceMac(MACMat)

nbCol = size(MACMat,1);

nbNoeuds = nbCol+1;
vertex=zeros(nbNoeuds,3);
faces=zeros(4,nbCol*nbCol);

%Creation des noeuds
for i=1:1:nbNoeuds
    for j=1:1:nbNoeuds
       vertex(i+(j-1)*nbNoeuds,1)=i-1;
       vertex(i+(j-1)*nbNoeuds,2)=j-1;
    end
end
numFaces=1;
for i=1:1:nbCol
    for j=1:1:nbCol            
      faces(:,numFaces)=[i i+1 i+j*nbNoeuds i+1+(j+1)*nbNoeuds];  
      numFaces=numFaces+1;
    end
end

faces
plot3(vertex(:,1),vertex(:,2),vertex(:,3),'o');
vertex