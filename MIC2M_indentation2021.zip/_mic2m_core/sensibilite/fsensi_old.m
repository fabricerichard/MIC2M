function [r,test_rupture]=fsensi(P)

% calcul de l'erreur entre l'experience et le modele

%nom_du_modele = textread(['nom_du_modele','.txt'],'%s') ;
%nom_modele = [char(nom_du_modele),'_dot'] ;
%fich_parametre = [char(nom_du_modele),'_parametres'] ;
%fich_variable =  [char(nom_du_modele),'_variables'] ;

% parametres courants
parametres=P(:,1) ;
save parametres.txt parametres -ascii ;

% lecture du fichier variables
%[num_var,nom_var,var_0,graph] = textread([fich_variable,'.txt'],'%f %s %f %s') ;

[s,ident,essais,model] = textread(['liste_experiences.txt'],'%s %s %s %s') ;

fcourant=ones(length(s),1)*NaN ;
save fcourant.txt fcourant -ascii ;

nb=0; nobs=0;       
for i=2:length(s) 
   if strcmp( ident(i),'%')==0 
      fich_essai=char(essais(i)) ; nb=nb+1 ;
      % chargement et reponse experimentale
      [temps,nom_entree,type_entree,entree] = experience(fich_essai) ;
      eval(['save  temps.txt temps -ascii']) ;
      % reponse du modele au chargement experimental
      nom_du_modele = char(model(i)) ;
      fid = fopen('nom_du_modele.txt','w') ; fprintf(fid,'%s',char(model(i))) ;fclose('all');
      [temps,sortie,test_rupture,aux] = modele(fich_essai) ;
      fich_variable =  [char(nom_du_modele),'_variables'] ;
      [num_var,nom_var,var_0,graph] = textread([fich_variable,'.txt'],'%f %s %f %s') ;
   
      nligne=size(entree,1) ;

      for j=1:length(type_entree)    
         if strcmp(char(type_entree(j)),'observe')==1
            poids=ones(nligne,1) ;
            if strcmp(char(nom_entree(j)),'poids')==1
               poids=entree(:,j);
            end 
         end
      end

      for j=1:length(type_entree)
         if strcmp(char(type_entree(j)),'observe')==1 & strcmp(char(nom_entree(j)),'poids')==0
            nobs=nobs+1 ;
            for k=1:length(nom_var)
               if strcmp(char(nom_entree(j)),char(nom_var(k)))==1
                     maxe = max( abs( entree(:,j)) ) ;
                     maxm = max( abs( sortie(:,k)) ) ;
                  if nobs==1 
                     r =  sortie(:,k)  ;
                     %sc =(1./poids)/str2num(char(ident(i)))*nligne ;
                     scm = (1./poids) / (str2num(char(ident(i))))^.5*maxm * nligne^.5 ;
                     
                  else
                     r = [ r ; sortie(:,k) ] ; % ATTENTION AU nombre de ligne si plusieurs essais !!!!
                     %sc = [ sc ; (1./poids)/str2num(char(ident(i)))*nligne ] ;
                     scm = [ scm ; (1./poids) / (str2num(char(ident(i))))^.5*maxm * nligne^.5  ] ;
    
                  end
               end
            end
         end
      end

      %if nb==1
          %char(ident(i))
          %r
          %pause
   		 %r = str2num(char(ident(i)))*r ;
         %sc = sc./str2num(char(ident(i))) ;
      %else
      %   erreur=[erreur;str2num(char(ident(i)))*r] ;
      %   sc = [sc ; sc./str2num(char(ident(i)))]  ;
      %end
      %fcourant(i,1)=str2num(char(ident(i)))*r'*r ;
      %fcourant(i,1)=r'*r ;
      
   end
end

eval(['save  Nvar_obs.txt nobs -ascii']) ;
eval(['save  scm.txt scm -ascii']) ;

load k_iteration.txt
k_iteration = k_iteration-1 ;
if k_iteration>0
    eval(['save ',['r_iteration',num2str(k_iteration),'.txt'],' r -ascii']) ;  
    eval(['save ',['scm_iteration',num2str(k_iteration),'.txt'],' scm -ascii']) ;  
end