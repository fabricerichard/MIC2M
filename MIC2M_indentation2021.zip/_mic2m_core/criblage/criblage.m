clear all


% CHOIX DU MODELE 
[s,ident,essais,model] = textread(['liste_experiences.txt'],'%s %s %s %s') ;
for i=2:length(s) 
    if strcmp( ident(i),'%')==0
        nom_du_modele=char(model(i)) ;
    end
end
%    save model
%else
%    nom_du_modele = char(liste_modele(choix)) 
%end

%fid = fopen('nom_du_modele.txt','w');
%for i=1:size(char(nom_du_modele),2)   ;  fprintf(fid,'%s',char(nom_du_modele(i))) ; end
%fclose('all');

% lecture parametre
fich_parametre = [char(nom_du_modele),'_parametres'] ;
[nom_para,para_nom,a,b,loi,CV] = textread([fich_parametre,'.txt'],'%s %f %f %f %f %f') ;

for i=2:length(s) 
    
    if strcmp( s(i),'%')==0 
        fich_essai=char(essais(i)) ;
        nom_du_modele=char(model(i)) ;
        fid = fopen('nom_du_modele.txt','w');
        for i=1:size(char(nom_du_modele),2)   ;  fprintf(fid,'%s',char(nom_du_modele(i))) ; end
        fclose('all');
        fich_parametre = [char(nom_du_modele),'_parametres'] 
        [nom_para,para_nom,a,b,loi,CV] = textread([fich_parametre,'.txt'],'%s %f %f %f %f %f') ;
        V=[para_nom,a,b,loi,CV] ;
        % creation des points de calculs
                
        parametre{1}=V(:,1) ;
        parametre{2}=V(:,4) ;
        parametre{3}=V(:,5) ;

        % cribblage 2 parametres 
        numparaX=3 ; %coeff ecrouissage
        numparaY=2 ; %limite elastique
        minX = V(numparaX,2) ;  maxX = V(numparaX,3) ;
        minY = V(numparaY,2) ;  maxY = V(numparaY,3) ;
        nsegment=30 ;
        [X,Y] = meshgrid(minX:(maxX-minX)/nsegment:maxX, minY:(maxY-minY)/nsegment:maxY) ;
        save X ; save Y ;
        %pause
        
        % initialisation du compteur
        k_iteration = 1 ; save k_iteration.txt k_iteration -ascii ; 
        %k_iteration = 25*23+1 ; 
 
        for kx=1:(nsegment+1)
            for ky=1:(nsegment+1)
                P=V(:,1) ; 
                P(numparaX,1) = minX+(maxX-minX)/nsegment*(kx-1) ; 
                P(numparaY,1) = minY+(maxY-minY)/nsegment*(ky-1) ; 
                [r,test_rupture]=ferreur_LM(P)  ;  
                %load k_iteration.txt ; k_iteration = k_iteration-1 
                w(k_iteration) = (r'*r) ; save w ; 
                Z(ky,kx)=(w(k_iteration))^0.5 ; save Z ;
                plot3(P(numparaX,1),P(numparaY,1),Z(ky,kx),'o'); hold on
            end
        end
    end
end
 
load X ; load Y ; load Z ;

%Z=log10(fV);

%Z=V_sqrt


figure(1) ; hold on

plot3(0.1,2,0,'MarkerFaceColor',[1 0 0],'MarkerEdgeColor',[1 0 0],...
    'MarkerSize',15,...
    'Marker','hexagram',...
    'LineStyle','none',...
    'Color',[1 0 0]);

%surf(X,Y,Z,'EdgeColor','black')
[xi, yi] = meshgrid(minX:(maxX-minX)/nsegment/10:maxX, minY:(maxY-minY)/nsegment/10:maxY);
zi = interp2(X, Y, Z, xi, yi,'cubic' );
%mesh(X,Y,Z)
mesh(xi,yi,zi)

contour3(xi, yi, zi,[2e-2],'k')
contour(xi, yi, zi,[2e-2],'k')
%surf(xi, yi, zi, 'LineStyle', 'none', 'FaceColor', 'interp')
mesh(xi, yi, zi, 'LineStyle', 'none', 'FaceColor', 'interp')
colormap('pink')
camproj('perspective');
%camlight right
set(gca, 'CameraPosition', [-1.4 1.4 1])

axis([minX maxX minY maxY 0 .3])
axis square
grid

load parait_LM.txt
xit=parait_LM(:,4) ; yit=parait_LM(:,3) ; 
load coutit_LM.txt
zit=(coutit_LM(:,2 )*2).^0.5 ;
plot3(xit,yit,zit,'-o')


figure(2); ; hold on              
contour(X,Y,Z,[2e-2],'k')
axis([minX maxX minY maxY])
plot3(xit,yit,zit.*0,'-o')
plot3(0.1,2,0,'MarkerFaceColor',[1 0 0],'MarkerEdgeColor',[1 0 0],...
    'MarkerSize',15,...
    'Marker','hexagram',...
    'LineStyle','none',...
    'Color',[1 0 0]);
