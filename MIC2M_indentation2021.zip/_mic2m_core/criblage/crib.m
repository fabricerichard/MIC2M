clear all

load exp.txt ; sortie_exp = exp ;
N=length(sortie_exp) ;
sortie_expperturb =  sortie_exp ;
%sortie_expperturb(:,2) = sortie_exp(:,2) + sortie_exp(:,2).*((.01).*randn(N,1)) ;
sortie_expperturb(:,2) = sortie_exp(:,2) + max(sortie_exp(:,2))*((.01).*randn(N,1)) ;


figure(2)
plot(sortie_exp(:,1),sortie_exp(:,2),'o') ; hold on
plot(sortie_expperturb(:,1),sortie_expperturb(:,2),'s') ; hold on

nsegment=24
k=0 ;
figure
for kx=1:(nsegment+1)
    for ky = 1:(nsegment+1)
        k = k+1;
        a = ['parametres_iteration',num2str(k)] ; eval(['load ',a,'.txt']) ; parametres{k}=eval(a);
        a = ['sortie_iteration',num2str(k)] ; eval(['load ',a,'.txt'])     ; sortie{k}=eval(a)    ;
   
        X(ky,kx)=parametres{k}(3) ;
        Y(ky,kx)=parametres{k}(2) ;
        Z(ky,kx)=norm((sortie{k}(:,2)- sortie_exp(:,2))/max(sortie_exp(:,2))/N^0.5) ;
        %Z(ky,kx)=norm((sortie{k}(:,2)- sortie_exp(:,2))/sortie_exp(:,2)/N^0.5) ;
   
        figure(1) ; plot3(X(ky,kx),Y(ky,kx),Z(ky,kx),'o') ; hold on
        %if k == 213 ;
        if  Z(ky,kx)<= 0.01 ;     
            figure (2)
            plot(sortie_exp(:,1),sortie_exp(:,2),'o') ; hold on
            plot(sortie{k}(:,1),sortie{k}(:,2),'r') ; hold on
            figure(1) ; plot3(X(ky,kx),Y(ky,kx),Z(ky,kx),'rs') ; hold on
            %r=(sortie{k}(:,2)- sortie_exp(:,2))/max_sortie/N^0.5
            %Z=2*norm(r)
            %pause
        end
    end
end

save X ; save Y ; save Z


load X ; load Y ; load Z ; 

minX = min(min(X)) ; maxX = max(max(X)) ;
minY = min(min(Y)) ; maxY = max(max(Y)) ;
%X
%[X,Y] = meshgrid(minX:(maxX-minX)/nsegment:maxX, minY:(maxY-minY)/nsegment:maxY) ;
%X
%pause
%Y

[xi, yi] = meshgrid(minX:(maxX-minX)/nsegment/3:maxX, minY:(maxY-minY)/nsegment/3:maxY);
zi = interp2(X, Y, Z, xi, yi,'pchip' );

%mesh(X,Y,Z)
mesh(xi,yi,zi)


contour3(X, Y, Z,[1e-2 1e-1],'k')
contour3(xi, yi, zi,[1e-2 1e-1],'r')

%figure
%z3 = griddata(X,Y,Z,xi,yi,'cubic');
%mesh(xi,yi,z3)
%contour3(xi, yi, z3,[5e-2 1e-2 1e-1],'b')

plot3(0.1,2,0,'MarkerFaceColor',[1 0 0],'MarkerEdgeColor',[1 0 0],...
    'MarkerSize',15,...
    'Marker','hexagram',...
    'LineStyle','none',...
    'Color',[1 0 0]);
