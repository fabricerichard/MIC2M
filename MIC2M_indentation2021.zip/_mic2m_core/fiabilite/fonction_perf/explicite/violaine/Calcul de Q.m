clear all
syms E1 E2 Nu12 G12 ang k
%syms S11 S22 S12 S66 ang k

%syms Q11 Q12 Q22 Q66 ang 

%S=[S11 S12 0 ; S12 S22 0 ; 0 0 S66] ;

S=[1/E1 -Nu12/E1 0 ; -Nu12/E1 1/E2 0 ; 0 0 1/G12] ;
Q=inv(S) ;
(Q) ;

Q11=Q(1,1);Q12=Q(1,2);Q16=Q(1,3);
Q26=Q(2,3);
Q22=Q(2,2);Q66=Q(3,3);

Q=[Q11 Q12 0 ; Q12 Q22 0 ; 0 0 Q66] ;

Ts1= [cos(ang)^2 sin(ang)^2 2*sin(ang)*cos(ang);
		  sin(ang)^2 cos(ang)^2 -2*sin(ang)*cos(ang);
        -sin(ang)*cos(ang) sin(ang)*cos(ang) cos(ang)^2-sin(ang)^2];

Ts1inv =   [cos(ang)^2 sin(ang)^2 -2*sin(ang)*cos(ang);
		  sin(ang)^2 cos(ang)^2 2*sin(ang)*cos(ang);
        sin(ang)*cos(ang) -sin(ang)*cos(ang) cos(ang)^2-sin(ang)^2];
    
Te1= [cos(ang)^2 sin(ang)^2 sin(ang)*cos(ang);
		  sin(ang)^2 cos(ang)^2 -sin(ang)*cos(ang);
        -2*sin(ang)*cos(ang) 2*sin(ang)*cos(ang) cos(ang)^2-sin(ang)^2];

 
Ts2= [cos(ang)^2 sin(ang)^2 2*sin(-ang)*cos(ang);
		  sin(ang)^2 cos(ang)^2 -2*sin(-ang)*cos(ang);
        -sin(-ang)*cos(ang) sin(-ang)*cos(ang) cos(ang)^2-sin(ang)^2];

Ts2inv =   [cos(ang)^2 sin(ang)^2 -2*sin(-ang)*cos(ang);
		  sin(ang)^2 cos(ang)^2 2*sin(-ang)*cos(ang);
        sin(-ang)*cos(ang) -sin(-ang)*cos(ang) cos(ang)^2-sin(ang)^2];
    
Te2= [cos(ang)^2 sin(ang)^2 sin(-ang)*cos(ang);
		  sin(ang)^2 cos(ang)^2 -sin(-ang)*cos(ang);
        -2*sin(-ang)*cos(ang) 2*sin(-ang)*cos(ang) cos(ang)^2-sin(ang)^2];
    
Q1b=inv(Ts1)*Q*Te1 ;
Q2b=inv(Ts2)*Q*Te2 ;

QQb=(.5*Q1b+.5*Q2b);
II=simple(Q1b*inv(QQb))



% Q1b11=Q1b(1,1) ; Q1b12=Q1b(1,2) ; Q1b16=Q1b(1,3);
% Q1b22=Q1b(2,2) ; Q1b26=Q1b(2,3) ;
% Q1b66=Q1b(3,3);

xx=II*[k;1;0]

s1=Ts1*xx;


AA=(s1(2)^2) ;
BB=(s1(3)^2) ;


YI =simple(0.5*s1(2)^2/E2) 
YII=simple(0.5*s1(3)^2/G12) 
chiII=(1/(E1*E2))^0.5*G12 ;
Y=simple(YI+chiII*YII) 
pause


%simple(1/(AA+BB))
%Y=simple(Y)

pause

f=simple(diff(Y,ang)) ;


%solve('f',ang)

solve('1/E2*(sin(ang)^2+2*cos(ang)^2-2*sin(ang)*cos(ang)*((2*Nu12*E2*sin(4*ang)*G12+2*E2*sin(2*ang)*G12-E1*E2*sin(4*ang)+E2*sin(4*ang)*G12-2*E1*sin(2*ang)*G12+G12*sin(4*ang)*E1)/(-4*E2*Nu12*G12+4*E2*Nu12*G12*cos(4*ang)-2*E1*E2*cos(4*ang)-2*E1*E2-2*E2*G12+2*E2*G12*cos(4*ang)-2*G12*E1+2*G12*E1*cos(4*ang))+2*(-2*Nu12*E2*sin(4*ang)*G12-E2*sin(4*ang)*G12+2*E2*sin(2*ang)*G12+E1*E2*sin(4*ang)-G12*sin(4*ang)*E1-2*E1*sin(2*ang)*G12)/(-4*E2*Nu12*G12+4*E2*Nu12*G12*cos(4*ang)-2*E1*E2*cos(4*ang)-2*E1*E2-2*E2*G12+2*E2*G12*cos(4*ang)-2*G12*E1+2*G12*E1*cos(4*ang))))*(-2*sin(ang)*cos(ang)-2*cos(ang)^2*((2*Nu12*E2*sin(4*ang)*G12+2*E2*sin(2*ang)*G12-E1*E2*sin(4*ang)+E2*sin(4*ang)*G12-2*E1*sin(2*ang)*G12+G12*sin(4*ang)*E1)/(-4*E2*Nu12*G12+4*E2*Nu12*G12*cos(4*ang)-2*E1*E2*cos(4*ang)-2*E1*E2-2*E2*G12+2*E2*G12*cos(4*ang)-2*G12*E1+2*G12*E1*cos(4*ang))+2*(-2*Nu12*E2*sin(4*ang)*G12-E2*sin(4*ang)*G12+2*E2*sin(2*ang)*G12+E1*E2*sin(4*ang)-G12*sin(4*ang)*E1-2*E1*sin(2*ang)*G12)/(-4*E2*Nu12*G12+4*E2*Nu12*G12*cos(4*ang)-2*E1*E2*cos(4*ang)-2*E1*E2-2*E2*G12+2*E2*G12*cos(4*ang)-2*G12*E1+2*G12*E1*cos(4*ang)))+2*sin(ang)^2*((2*Nu12*E2*sin(4*ang)*G12+2*E2*sin(2*ang)*G12-E1*E2*sin(4*ang)+E2*sin(4*ang)*G12-2*E1*sin(2*ang)*G12+G12*sin(4*ang)*E1)/(-4*E2*Nu12*G12+4*E2*Nu12*G12*cos(4*ang)-2*E1*E2*cos(4*ang)-2*E1*E2-2*E2*G12+2*E2*G12*cos(4*ang)-2*G12*E1+2*G12*E1*cos(4*ang))+2*(-2*Nu12*E2*sin(4*ang)*G12-E2*sin(4*ang)*G12+2*E2*sin(2*ang)*G12+E1*E2*sin(4*ang)-G12*sin(4*ang)*E1-2*E1*sin(2*ang)*G12)/(-4*E2*Nu12*G12+4*E2*Nu12*G12*cos(4*ang)-2*E1*E2*cos(4*ang)-2*E1*E2-2*E2*G12+2*E2*G12*cos(4*ang)-2*G12*E1+2*G12*E1*cos(4*ang)))-2*sin(ang)*cos(ang)*((8*E2*Nu12*G12*cos(4*ang)+4*E2*cos(2*ang)*G12-4*E1*E2*cos(4*ang)+4*E2*G12*cos(4*ang)-4*E1*cos(2*ang)*G12+4*G12*E1*cos(4*ang))/(-4*E2*Nu12*G12+4*E2*Nu12*G12*cos(4*ang)-2*E1*E2*cos(4*ang)-2*E1*E2-2*E2*G12+2*E2*G12*cos(4*ang)-2*G12*E1+2*G12*E1*cos(4*ang))-(2*Nu12*E2*sin(4*ang)*G12+2*E2*sin(2*ang)*G12-E1*E2*sin(4*ang)+E2*sin(4*ang)*G12-2*E1*sin(2*ang)*G12+G12*sin(4*ang)*E1)/(-4*E2*Nu12*G12+4*E2*Nu12*G12*cos(4*ang)-2*E1*E2*cos(4*ang)-2*E1*E2-2*E2*G12+2*E2*G12*cos(4*ang)-2*G12*E1+2*G12*E1*cos(4*ang))^2*(-16*Nu12*E2*sin(4*ang)*G12+8*E1*E2*sin(4*ang)-8*E2*sin(4*ang)*G12-8*G12*sin(4*ang)*E1)+2*(-8*E2*Nu12*G12*cos(4*ang)-4*E2*G12*cos(4*ang)+4*E2*cos(2*ang)*G12+4*E1*E2*cos(4*ang)-4*G12*E1*cos(4*ang)-4*E1*cos(2*ang)*G12)/(-4*E2*Nu12*G12+4*E2*Nu12*G12*cos(4*ang)-2*E1*E2*cos(4*ang)-2*E1*E2-2*E2*G12+2*E2*G12*cos(4*ang)-2*G12*E1+2*G12*E1*cos(4*ang))-2*(-2*Nu12*E2*sin(4*ang)*G12-E2*sin(4*ang)*G12+2*E2*sin(2*ang)*G12+E1*E2*sin(4*ang)-G12*sin(4*ang)*E1-2*E1*sin(2*ang)*G12)/(-4*E2*Nu12*G12+4*E2*Nu12*G12*cos(4*ang)-2*E1*E2*cos(4*ang)-2*E1*E2-2*E2*G12+2*E2*G12*cos(4*ang)-2*G12*E1+2*G12*E1*cos(4*ang))^2*(-16*Nu12*E2*sin(4*ang)*G12+8*E1*E2*sin(4*ang)-8*E2*sin(4*ang)*G12-8*G12*sin(4*ang)*E1)))+1/(E1*E2)^(1/2)*(sin(ang)*cos(ang)+(cos(ang)^2-sin(ang)^2)*((2*Nu12*E2*sin(4*ang)*G12+2*E2*sin(2*ang)*G12-E1*E2*sin(4*ang)+E2*sin(4*ang)*G12-2*E1*sin(2*ang)*G12+G12*sin(4*ang)*E1)/(-4*E2*Nu12*G12+4*E2*Nu12*G12*cos(4*ang)-2*E1*E2*cos(4*ang)-2*E1*E2-2*E2*G12+2*E2*G12*cos(4*ang)-2*G12*E1+2*G12*E1*cos(4*ang))+2*(-2*Nu12*E2*sin(4*ang)*G12-E2*sin(4*ang)*G12+2*E2*sin(2*ang)*G12+E1*E2*sin(4*ang)-G12*sin(4*ang)*E1-2*E1*sin(2*ang)*G12)/(-4*E2*Nu12*G12+4*E2*Nu12*G12*cos(4*ang)-2*E1*E2*cos(4*ang)-2*E1*E2-2*E2*G12+2*E2*G12*cos(4*ang)-2*G12*E1+2*G12*E1*cos(4*ang))))*(cos(ang)^2-sin(ang)^2-4*sin(ang)*cos(ang)*((2*Nu12*E2*sin(4*ang)*G12+2*E2*sin(2*ang)*G12-E1*E2*sin(4*ang)+E2*sin(4*ang)*G12-2*E1*sin(2*ang)*G12+G12*sin(4*ang)*E1)/(-4*E2*Nu12*G12+4*E2*Nu12*G12*cos(4*ang)-2*E1*E2*cos(4*ang)-2*E1*E2-2*E2*G12+2*E2*G12*cos(4*ang)-2*G12*E1+2*G12*E1*cos(4*ang))+2*(-2*Nu12*E2*sin(4*ang)*G12-E2*sin(4*ang)*G12+2*E2*sin(2*ang)*G12+E1*E2*sin(4*ang)-G12*sin(4*ang)*E1-2*E1*sin(2*ang)*G12)/(-4*E2*Nu12*G12+4*E2*Nu12*G12*cos(4*ang)-2*E1*E2*cos(4*ang)-2*E1*E2-2*E2*G12+2*E2*G12*cos(4*ang)-2*G12*E1+2*G12*E1*cos(4*ang)))+(cos(ang)^2-sin(ang)^2)*((8*E2*Nu12*G12*cos(4*ang)+4*E2*cos(2*ang)*G12-4*E1*E2*cos(4*ang)+4*E2*G12*cos(4*ang)-4*E1*cos(2*ang)*G12+4*G12*E1*cos(4*ang))/(-4*E2*Nu12*G12+4*E2*Nu12*G12*cos(4*ang)-2*E1*E2*cos(4*ang)-2*E1*E2-2*E2*G12+2*E2*G12*cos(4*ang)-2*G12*E1+2*G12*E1*cos(4*ang))-(2*Nu12*E2*sin(4*ang)*G12+2*E2*sin(2*ang)*G12-E1*E2*sin(4*ang)+E2*sin(4*ang)*G12-2*E1*sin(2*ang)*G12+G12*sin(4*ang)*E1)/(-4*E2*Nu12*G12+4*E2*Nu12*G12*cos(4*ang)-2*E1*E2*cos(4*ang)-2*E1*E2-2*E2*G12+2*E2*G12*cos(4*ang)-2*G12*E1+2*G12*E1*cos(4*ang))^2*(-16*Nu12*E2*sin(4*ang)*G12+8*E1*E2*sin(4*ang)-8*E2*sin(4*ang)*G12-8*G12*sin(4*ang)*E1)+2*(-8*E2*Nu12*G12*cos(4*ang)-4*E2*G12*cos(4*ang)+4*E2*cos(2*ang)*G12+4*E1*E2*cos(4*ang)-4*G12*E1*cos(4*ang)-4*E1*cos(2*ang)*G12)/(-4*E2*Nu12*G12+4*E2*Nu12*G12*cos(4*ang)-2*E1*E2*cos(4*ang)-2*E1*E2-2*E2*G12+2*E2*G12*cos(4*ang)-2*G12*E1+2*G12*E1*cos(4*ang))-2*(-2*Nu12*E2*sin(4*ang)*G12-E2*sin(4*ang)*G12+2*E2*sin(2*ang)*G12+E1*E2*sin(4*ang)-G12*sin(4*ang)*E1-2*E1*sin(2*ang)*G12)/(-4*E2*Nu12*G12+4*E2*Nu12*G12*cos(4*ang)-2*E1*E2*cos(4*ang)-2*E1*E2-2*E2*G12+2*E2*G12*cos(4*ang)-2*G12*E1+2*G12*E1*cos(4*ang))^2*(-16*Nu12*E2*sin(4*ang)*G12+8*E1*E2*sin(4*ang)-8*E2*sin(4*ang)*G12-8*G12*sin(4*ang)*E1)))',ang) ;




for i=0:1:90
ang=i/180*pi;
 E1=59000;E2=20000;Nu12=.2;G12=9800;
YY=eval(Y);
ff=eval(f);
 plot(i,YY,'o')
 plot(i,ff,'o')
 hold on
end
% 
% QQb= ...
% [                                           1,                                           0,                                   Qb16/Qb66 ;...
%                                             0,                                           1,                                   Qb26/Qb66 ;...
%    (-Qb16*Qb22+Qb26*Qb12)/(-Qb11*Qb22+Qb12^2), -(-Qb16*Qb12+Qb26*Qb11)/(-Qb11*Qb22+Qb12^2),                                           1] ... ;
% 
