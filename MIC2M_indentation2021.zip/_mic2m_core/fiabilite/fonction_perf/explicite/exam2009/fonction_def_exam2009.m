function G=fonction_def(nom_para,valeur_para)

assignation_para(nom_para,valeur_para) ;

G = sigY - F/(pi*d^2) ;



