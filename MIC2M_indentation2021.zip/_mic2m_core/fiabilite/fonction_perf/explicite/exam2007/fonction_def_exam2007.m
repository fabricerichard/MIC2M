function G=fonction_def(nom_para,valeur_para)

assignation_para(nom_para,valeur_para) ;

E=200000 ;
Re=300 ; 

L=250 ;

%F=1 ;
I=a^4/12 ;
Fc=pi^2*E*I/L^2 ;

G=Fc-F ;

S=a^2;
r=(I/S)^.5;
l=L/r;


