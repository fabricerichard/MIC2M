function G=fonction_def(nom_para,valeur_para)

assignation_para(nom_para,valeur_para) ;

R=3.75 ;%m
e=.1 ;%m
%P=2 ; %MPa
n=3;
C=2.2e-12;%m/cycle et MPa.m1/2
KIC=200 ;


Dsig=P*R/e;
a0=e; %

%KIC=200;
%ac= (KIC/(P*R/e)/pi^.5)^2 ; %mm

ac= (KIC/(P*R/e)/pi^.5)^2  ;%mm


%NR=(C*(Dsig)^n*pi^(n/2)*(1-n/2))^-1*( ac^(1-n/2)-a0^(1-n/2) )
NR =(C*(R*P/e)^n*pi^(n/2)*(1-n/2))^-1*( ac^(1-n/2)-a0^(1-n/2) );


%x = 2:.1:5
%for i=1:length(x)
%y(i) = (C*(R*x(i)/e).^n*pi^(n/2)*(1-n/2)).^-1*( ((KIC/(R*x(i)/e)/pi^.5))^(2-n)-a0^(1-n/2) )
%end
%plot(x,y,'--rs','LineWidth',2,...
%                       'MarkerEdgeColor','k',...
%                       'MarkerFaceColor','g',...
%                       'MarkerSize',10)
%
G=NR-1e5 ;



