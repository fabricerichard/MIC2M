function G=fonction_def(nom_para,valeur_para)


assignation_para(nom_para,valeur_para) ;

%G=sigu-(F/A) ;
%G=R-S ;
G=MR/.496/p-1 ;

%G=sigu*d-S ;