function G=fonction_def(nom_para,valeur_para)


assignation_para(nom_para,valeur_para) ;

valeur_para
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ECRITURE DU FICHIER ANSYS inputansys.txt %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

fich_commande = 'input_ansys_barre_traction.txt' 

disp('traitement fichier commande')
B = remplace(fich_commande,'################','%16.10e',nom_para,valeur_para);


fid = fopen('inputansys.txt','w') ;
for i=1:size(B,1)   
    fprintf(fid,'%s\n',char(B(i))) ;
end
fclose('all');

%%%%%%%%%%%%%%%%%%%
% LANCEMENT ANSYS %
%%%%%%%%%%%%%%%%%%%
! "C:\Program Files\ANSYS Inc\v130\ANSYS\bin\Intel\ansys130.exe"  -p aa_t_i -dir "C:\MIC2M" -j "file" -s read -l en-us -b -i "C:\MIC2M\inputansys.txt" -o "C:\MIC2M\file.out"   

%! "C:\Program Files\ANSYS Inc\v120\ANSYS\bin\Intel\ansys120.exe"  -p aa_t_i -dir "C:\MIC2M" -j "file" -s read -l en-us -b -i "C:\MIC2M\inputansys.txt" -o "C:\MIC2M\file.out"   
%! "C:\Program Files\Ansys Inc\V70\ANSYS\bin\intel\ansys70.exe" -b -i inputansys.txt -o outputname
%! "C:\Program Files\Ansys Inc\V80\ANSYS\bin\intel\ansys80" -b -i inputansys.txt -o outputname -m 64 -db 64

% salles TP MECA 2004-05 :
%! "D:\Mecanique\Ansys81\v81\ANSYS\bin\intel\ansys81" -b -p ansysuh -i inputansys.txt -o outputname

%%%%%%%%%%%%%%%%%%%%%
% RECUPERATION DE G %
%%%%%%%%%%%%%%%%%%%%%
PAR = textread(['sortie.txt'],'%s','whitespace',',') 
G=char(PAR(4))  ;
G=str2num(G) 
