function [indice]=Pf2indice(Pf) ;


% conversion de Pf � l'indice de fiabilit� ;
indice=-2^0.5*erfinv(2*Pf-1) ;