function [nbtirage]=montecarlo(fonction_propagation,V,enregistrement)

% nombre de variables
N=size(V,1) ;
% moyennes
moy =V(:,1) ;
% �cart types
ET = V(:,4) ;

typeloi = V(:,5) ;

x=moy ; % initialisation des varialbes physiques

% identification des variables al�atoires
j=0;
for i=1:N
   if ET(i)>0
      j=j+1;
      nbp(j)=i ;
   end
end
% position des variables al�atoires
nbp ;
nbparam=length(nbp) ; % nombre de variables al�atoires

nf=0 ; % initialisation des d�faillances
nbtiragemax = input('nombre de tirages : ') ;

name=[] ; for i=1:N ; name=[name,'0'] ; end
%sauvegarde(sauvegarde_sortie_stat,['sauvegarde_sortie_stat',name,'.txt'])

for nbtirage=1:nbtiragemax
    for i=1:nbparam
        % tirage d'une realisation suivant une gaussienne standard (�cart type = 1
        % et moyenne = 0
        y=Pf2indice(rand(1)) ;
        % variable dans l'espace physique
        x(nbp(i))=y*ET(nbp(i))+moy(nbp(i)) ;
        if typeloi(nbp(i))==1 ; 
            b = moy(nbp(i)) + ET(nbp(i))*3^.5 ;
            a = 2*moy(nbp(i)) - b  ;
            x(nbp(i))= a + (b-a).*rand(1) ;
        end
        name(nbp(i))='1' ;
    end

    sortie = feval(fonction_propagation,x) ;
    if nbtirage==1
        sauvegarde_sortie=[x' sortie' ] ;
    else
        sauvegarde_sortie=[sauvegarde_sortie ; x' sortie' ] ;
    end
    sauvegarde_sortie ;
       
end

eval(['save sauvegarde_sortie.txt sauvegarde_sortie -ascii']) ;
A = sauvegarde_sortie ;
sauvegarde_sortie_stat = [mean(A) ; var(A) ; std(A) ; abs(std(A)./mean(A))] 
eval(['save ',['sauvegarde_sortie_stat',name,'.txt'],' sauvegarde_sortie_stat -ascii']) ;
