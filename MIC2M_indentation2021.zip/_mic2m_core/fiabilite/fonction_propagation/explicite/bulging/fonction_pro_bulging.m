function sortie=fonction_pro(nom_para,valeur_para)

assignation_para(nom_para,valeur_para) ;

test_rupture=0 ;
sortie_aux=0 ;

%mode='i'
format long

valeur_para ;
nom_para ;

% d�finition des entr�es
%long = 25.0; % dimension de l'outil : demi-longueur libre du tube en mm (incertitude : delta = +-0.005 mm)
%position = 0.0 %dimension de l'outil : positionnement central du capteur de d�placement (incertitude : delta = +-0.005 mm)
%radius = 17.5; % dimension du tube : rayon ext�rieur du tube en mm (incertitude : relatif = +-1%)
%thickin = 1.0; % dimension du tube : �paisseur initiale du tube en mm (incertitude : relatif = +-10%)
%pression = 34.02 % mesure : pression interne en MPa (incertitude : relatif = +-0.3%)
%hauteur = 7.656 % mesure : hauteur de gonflement en mm (incertitude : relatif = +-0.02%)

% calcul du rayon de courbure de l'arc de cercle approchant le
% profil du tube 
R = (hauteur*hauteur+long*long)/2.0/hauteur;
% calcul de la coordonn�e du centre de l'arc de cercle repr�sentant
% le profil du tube
centre = radius+hauteur-R;

% calcul des coordonn�es du point de mesure
Z = position;
Y = centre + sqrt(R*R-Z*Z);
 
% calcul des d�formations au "p�le"
eps_theta = log(Y/radius);
PHI_MAX = asin(long/R);
eps_phi = log(R*PHI_MAX/long);
eps_r = -eps_theta-eps_phi;
 
% calcul de l'�paisseur courante au "p�le"
thickcur = thickin*exp(eps_r);

% calcul des contraintes au p�les
sig_r = 0.0;
phi = atan(Z/Y);
sig_theta = pression*Y*(1-Y/2.0/R/cos(phi))/thickcur/cos(phi);
sig_phi = pression*Y/2.0/thickcur/cos(phi);


sortie=[R centre Z Y thickcur PHI_MAX eps_theta eps_phi eps_r sig_theta sig_phi]' ;