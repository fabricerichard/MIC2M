function sortie=fonction_pro(nom_para,valeur_para)

assignation_para(nom_para,valeur_para) ;

test_rupture=0 ;
sortie_aux=0 ;

%mode='i'
format long

valeur_para ;
nom_para ;

%X1=8*X1-4 ;
%X2=8*X2-4 ;
%X3=8*X3-4 ;
F = X1^2 + X2^4 + X1*X2 + X2*X3^4 ;


 
sortie=[F]' ;