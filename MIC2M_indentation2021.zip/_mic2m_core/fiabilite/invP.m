function v=invP(V,G,y) ;

% V=incertitudes et hasard sur les parametres
% y=norme dans l'espace du hasard
% G=coordonnes dans l'espace de l'incertain et cosdir dans l'espace du hasard

nbpara=size(V,1) ;
moy=zeros(nbpara,1) ;
v=zeros(nbpara,1) ;

% traitement des moyennes

for i=1:nbpara
   
   if G(i)>=0 moy(i,1)=V(i,1)+(V(i,3)-V(i,1))*G(i) ; end
   if G(i)<0  moy(i,1)=V(i,1)-(V(i,2)-V(i,1))*G(i) ; end

end



% les valeurs

for i=1:nbpara
   % loi normale
   %if V(i,5)==0
      %Et=V(i,4)/100*moy(i,1);
      v(i,1)=y*G(nbpara+i)*V(i,4) + moy(i,1) ;
      %v(i,1)=y*G(nbpara+i)*Et + moy(i,1) ;
      %else
      %disp('autre loi')
      %end
   
end

