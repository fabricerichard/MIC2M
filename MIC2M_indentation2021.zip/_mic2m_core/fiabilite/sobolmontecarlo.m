function [nbtirage]=sobolmontecarlo(fonction_propagation,V,enregistrement)

fprintf('Module Sobol Monte-Carlo \n')
fprintf('Fabrice RICHARD\n')
fprintf('12/2010\n\n\n')

% nombre de variables
N=size(V,1) ;
% moyennes
moy =V(:,1) ;
% �cart types
ET = V(:,4) ;

typeloi = V(:,5) ;

x=moy ; % initialisation des varialbes physiques

% identification des variables al�atoires
j=0;
for i=1:N
   if ET(i)>0
      j=j+1;
      nbp(j)=i ;
   end
end
% position des variables al�atoires
nbp ;
nbparam=length(nbp) ; % nombre de variables al�atoires

nf=0 ; % initialisation des d�faillances
nbtiragemax = input('nombre de tirages : ') ;

name=[] ; for i=1:N ; name=[name,'0'] ; end

for nbtirage=1:nbtiragemax
    for i=1:nbparam
        % tirage d'une realisation suivant une gaussienne standard N(0,1)
        y=Pf2indice(rand(1)) ; 
        x(nbp(i))=y*ET(nbp(i))+moy(nbp(i)) ;
        % tirage d'une realisation suivant une uniforme U(0,1)
        if typeloi(nbp(i))==1 ; 
            b = moy(nbp(i)) + ET(nbp(i)) ; a = moy(nbp(i)) - ET(nbp(i))  ; 
            %b = moy(nbp(i)) + ET(nbp(i))*3^.5 ; a = 2*moy(nbp(i)) - b  ;
            x(nbp(i))= a + (b-a).*rand(1) ;
        end
        name(nbp(i))='1' ;
    end
    sortie = feval(fonction_propagation,x) ; % calcul de la r�ponse du mod�le

    if nbtirage==1 ; 
        sauvegarde_sortie=[x' sortie' ] ;
    else
        sauvegarde_sortie=[sauvegarde_sortie ; x' sortie' ] ;
    end
end

eval(['save ',['sauvegarde_sortie',name,'.txt'],' sauvegarde_sortie -ascii']) ;
A = sauvegarde_sortie ;
sauvegarde_sortie_stat = [ mean(A) ; std(A) ; min(A) ;  max(A)] ;
eval(['save ',['sauvegarde_sortie_stat',name,'.txt'],' sauvegarde_sortie_stat -ascii']) ;
A1=A ;


name=[] ; for i=1:N ; name=[name,'0'] ; end

for nbtirage=1:nbtiragemax
    for i=1:nbparam
        % tirage d'une realisation suivant une gaussienne standard N(0,1)
        y=Pf2indice(rand(1)) ;
        x(nbp(i))=y*ET(nbp(i))+moy(nbp(i)) ;
        % tirage d'une realisation suivant une uniforme U(0,1)
        if typeloi(nbp(i))==1 ; 
            b = moy(nbp(i)) + ET(nbp(i)) ; a = moy(nbp(i)) - ET(nbp(i))  ; 
            %b = moy(nbp(i)) + ET(nbp(i))*3^.5 ; a = 2*moy(nbp(i)) - b  ;
            x(nbp(i))= a + (b-a).*rand(1) ;
        end
        name(nbp(i))='2' ;
    end
    sortie = feval(fonction_propagation,x) ; % calcul de la r�ponse du mod�le
    if nbtirage==1
        sauvegarde_sortie=[x' sortie' ] ;
    else
        sauvegarde_sortie=[sauvegarde_sortie ; x' sortie' ] ;
    end
    sauvegarde_sortie ;
end    

eval(['save ',['sauvegarde_sortie',name,'.txt'],' sauvegarde_sortie -ascii']) ;
A = sauvegarde_sortie ;
sauvegarde_sortie_stat = [ mean(A) ; std(A) ; min(A) ;  max(A)] ;
eval(['save ',['sauvegarde_sortie_stat',name,'.txt'],' sauvegarde_sortie_stat -ascii']) ;
A2 = A ;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
disp('calcul des incices au 1er ordre')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for blocage = 1:nbparam
    name=[] ; for i=1:N ; name=[name,'0'] ; end
    for nbtirage=1:nbtiragemax
        for i=1:nbparam
             x(nbp(i))=A2(nbtirage,nbp(i)) ; name(nbp(i))='2' ;
             % la variable qui ne change pas
             if i==blocage ; x(nbp(i))=A1(nbtirage,nbp(i)) ; name(nbp(i))='1' ; end
        end
        sortie = feval(fonction_propagation,x) ;
        if nbtirage==1
            sauvegarde_sortie=[x' sortie' ] ;
        else
            sauvegarde_sortie=[sauvegarde_sortie ; x' sortie' ] ;
        end
    end

    eval(['save ',['sauvegarde_sortie',name,'.txt'],' sauvegarde_sortie -ascii']) ;
    A = sauvegarde_sortie ;
    sauvegarde_sortie_stat = [ mean(A) ; std(A) ; min(A) ;  max(A)] ;
    eval(['save ',['sauvegarde_sortie_stat',name,'.txt'],' sauvegarde_sortie_stat -ascii']) ;
end

% calcul des indice au 1er ordre
% �chantillon  M1
name=[] ; for i=1:N ; name=[name,'0'] ; end ; for i=1:nbparam ; name(nbp(i))='1' ; end
eval(['load ','sauvegarde_sortie',name,'.txt']) ; 
M1=eval(['sauvegarde_sortie',name]) ;  M1=M1(:,nbparam+1:size(M1,2)) ;
% �chantillon  M2
%name=[] ; for i=1:N ; name=[name,'0'] ; end ; for i=1:nbparam ; name(nbp(i))='2' ; end
%eval(['load ','sauvegarde_sortie',name,'.txt']) ; 
%M2=eval(['sauvegarde_sortie',name]) ;  M2=M2(:,nbparam+1:size(M2,2)) ;

%Es=mean(M1.*M2) ;
Es=(mean(M1).^2) ;

S=zeros(N,N) ;
for blocage = 1:nbparam
    % r�cup�ration des r�sultats de l'�chantillon M2
    name=[] ; for i=1:N ; name=[name,'0'] ; end ; 
    for i=1:nbparam ; name(nbp(i))='2' ; end 
    name(nbp(blocage))='1' ; % la variable identique pour M1 et M2
    S(nbp(blocage),nbp(blocage))=1 ;
    eval(['load ','sauvegarde_sortie',name,'.txt']) ;
    M2=eval(['sauvegarde_sortie',name]) ;
    M2=M2(:,nbparam+1:size(M2,2)) ;
    SS(nbp(blocage),:) =  ( mean(M1.*M2) - Es)./var(M1) ;
   
   
end

indices_ordre1 = [S SS] 
eval(['save ',['indices_ordre1.txt'],' indices_ordre1 -ascii']) ;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
disp('calcul des indices totaux ')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for nblocage = 1:nbparam
    name = [] ; for i=1:N ; name = [name,'0'] ; end
    for nbtirage = 1:nbtiragemax
        for i=1:nbparam
             x(nbp(i))=A1(nbtirage,nbp(i)) ; name(nbp(i))='1' ;
             % la variable qui change
             if i==nblocage ; x(nbp(i))=A2(nbtirage,nbp(i)) ; name(nbp(i))='2' ; end
        end
        sortie = feval(fonction_propagation,x) ;
        if nbtirage==1
            sauvegarde_sortie=[x' sortie' ] ;
        else
            sauvegarde_sortie=[sauvegarde_sortie ; x' sortie' ] ;
        end
    end

    eval(['save ',['sauvegarde_sortie',name,'.txt'],' sauvegarde_sortie -ascii']) ;
    A = sauvegarde_sortie ;
    sauvegarde_sortie_stat = [ mean(A) ; std(A) ; min(A) ;  max(A)] ;
    eval(['save ',['sauvegarde_sortie_stat',name,'.txt'],' sauvegarde_sortie_stat -ascii']) ;
end

% calcul des indice totaux
% �chantillon M1
name=[] ; for i=1:N ; name=[name,'0'] ; end ; for i=1:nbparam ; name(nbp(i))='1' ; end
eval(['load ','sauvegarde_sortie',name,'.txt']) ; 
M1=eval(['sauvegarde_sortie',name]) ;  M1=M1(:,nbparam+1:size(M1,2)) ;
% �chantillon  M2
name=[] ; for i=1:N ; name=[name,'0'] ; end ; for i=1:nbparam ; name(nbp(i))='2' ; end
eval(['load ','sauvegarde_sortie',name,'.txt']) ; 
M2=eval(['sauvegarde_sortie',name]) ;  M2=M2(:,nbparam+1:size(M2,2)) ;

%Es=mean(M1.*M2) ;
Es=(mean(M1).^2) ;

S=zeros(N,N) ;
for nblocage = 1:nbparam
    % r�cup�ration des r�sultats de l'�chantillon M2
    name=[] ; for i=1:N ; name=[name,'0'] ; end ; for i=1:nbparam ; name(nbp(i))='1' ; end
    name(nbp(nblocage))='2' ; % la seule variable qui change entre M1 et M2
    S(nbp(nblocage),nbp(nblocage))=1 ;
    
    eval(['load ','sauvegarde_sortie',name,'.txt']) ;
    M2=eval(['sauvegarde_sortie',name]) ; M2=M2(:,nbparam+1:size(M2,2)) ;
    SS(nbp(nblocage),:) =  1 - ( mean(M1.*M2) - Es)./var(M1) ;
end

indices_ordreT = [S SS] 
eval(['save ',['indices_ordreT.txt'],' indices_ordreT -ascii']) ;
