function LateXModInit(Reponse,EIBB,EIBH,EIHB,EIHH,EFB,EFH)

NbParam = size(EFH,2);
ymean = mean(Reponse);
fichierLATEX = fopen('MdlMatInit.tex','w+');
fprintf(fichierLATEX,'\\begin{eqnarray}\n');
fprintf(fichierLATEX,'y &=& %7.3f \\nonumber\\\\ \n',ymean);
for i=1:1:NbParam
fprintf(fichierLATEX,'&+& \\begin{pmatrix}\n');
fprintf(fichierLATEX,'%7.4f & %7.4f\n',EFB(i),EFH(i));
fprintf(fichierLATEX,'\\end{pmatrix}\\left[%s\\right] \\nonumber\\\\ \n',char([64+i]));
end
min = 1;
max = 2*NbParam-1;
j=1;
k=2;
NbTotPI = NbParam*(NbParam-1)/2;
for i=1:1:NbTotPI
   fprintf(fichierLATEX,'&+& ^{T}\\left[ %c \\right]\n',char([64+j]));
   fprintf(fichierLATEX,'\\begin{pmatrix}\n');
   fprintf(fichierLATEX,'%7.4f & %7.4f\\\\ \n',EIBB(i),EIBH(i));
   fprintf(fichierLATEX,'%7.4f & %7.4f\n',EIHB(i),EIHH(i));
   if(i==NbTotPI)
   fprintf(fichierLATEX,'\\end{pmatrix}\\left[%c \\right]\n',...
           char([64+k]));
   else
   fprintf(fichierLATEX,'\\end{pmatrix}\\left[%c \\right]\\nonumber\\\\ \n',...
           char([64+k]));    
   end
       if((i<=max)&&(k<NbParam))
          k=k+1;
       else
          j=j+1;
          k=j+1;
          max = max+NbParam-j;           
       end      
end

fprintf(fichierLATEX,'\\end{eqnarray}\n');
fclose(fichierLATEX);