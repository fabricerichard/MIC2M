function [EIFBB EIFBH EIFHB EIFHH] = EFactor(TExp,NbParam,Reponse,EFB,EFH)

ILBB = 1;
ILBH = 1;
ILHB = 1;
ILHH = 1;



for i=1:1:NbParam
    NBB = 1; 
    NBH = 1; 
    NHB = 1; 
    NHH = 1;
    for j=(i+1):1:NbParam
      for k=1:1:size(TExp,1)
         if((TExp(k,i)==-1)&&(TExp(k,j)==-1))
             EIBB(ILBB,NBB) = Reponse(k);
             NBB = NBB+1;
             if(NBB>2^(NbParam-2))
                 NBB = 1;
             end
         end
         if((TExp(k,i)==-1)&&(TExp(k,j)==1))
             EIBH(ILBH,NBH) = Reponse(k);
             NBH = NBH+1;
             if(NBH>2^(NbParam-2))
                 NBH = 1;
             end
         end
         if((TExp(k,i)==1)&&(TExp(k,j)==-1))
             EIHB(ILHB,NHB) = Reponse(k);
             NHB = NHB+1;
             if(NHB>2^(NbParam-2))
                 NHB = 1;
             end
         end
         if((TExp(k,i)==1)&&(TExp(k,j)==1))
             EIHH(ILHH,NHH) = Reponse(k);
             NHH = NHH+1;
             if(NHH>2^(NbParam-2))
                 NHH = 1;
             end
         end  
      end
      ILBB = ILBB+1;
      ILBH = ILBH+1;
      ILHB = ILHB+1;
      ILHH = ILHH+1;  
   end
end

min = 1;
max = NbParam-1;
j=1;
k=2;
for i=1:1:size(EIHH,1)
    
   EIFBB(i) = mean(EIBB(i,:))-mean(Reponse)-EFB(j)-EFB(k);
   EIFBH(i) = mean(EIBH(i,:))-mean(Reponse)-EFB(j)-EFH(k);
   EIFHB(i) = mean(EIHB(i,:))-mean(Reponse)-EFH(j)-EFB(k);
   EIFHH(i) = mean(EIHH(i,:))-mean(Reponse)-EFH(j)-EFH(k);
   
   if((i<=max)&&(k<NbParam))
       k=k+1;
   else
      j=j+1;
      k=j+1;
      max= max+NbParam-j;
      
   end
end

