function CreerLatex(NbParam,Name,BVal,Reponse,EIBB,EIBH,EIHB,EIHH,EFB,EFH,...
                    Variance,Ftest,Ftheo,ddls,FSnedTest)

CreatePDF = 'oui';
                
%[NbParam Name BVal] = LireDataFile(DataFile);
                
LateXTabParam(Name,BVal);

LateXModInit(Reponse,EIBB,EIBH,EIHB,EIHH,EFB,EFH);

LateXANOVA(Variance,Ftest,Ftheo,ddls,FSnedTest,NbParam);

LateXModFinal(Reponse,EIBB,EIBH,EIHB,EIHH,EFB,EFH,FSnedTest);
% 
% Dep = ['! move ','*.tex ','./Publi/'];
% eval(Dep);
% Dep = ['! move ','*.eps ','./Publi/'];
% eval(Dep);
% 
% 
% if(CreatePDF == 'oui')
% cd('./Publi/');
% 
% LateXCom = '! G:\Applications-FEMTO-ST\miktex\miktex\bin\latex.exe DOE.tex';
% 
% for i=1:2
%    eval(LateXCom);
% end
% 
% DVIPS = '! G:\Applications-FEMTO-ST\miktex\miktex\bin\dvips.exe -P pdf  DOE.dvi'
% 
% eval(DVIPS);
% 
% PS2PDF = ['! "C:\Program Files\gs\gs8.61\bin\gswin32c.exe"',...
%           ' -sPAPERSIZE=a4 -dSAFER -dBATCH -dNOPAUSE ',...
%           '-sDEVICE=pdfwrite -sOutputFile=DOE.pdf -c save pop -f DOE.ps'];
% 
% eval(PS2PDF);
% 
% PDF = '! "C:\Program Files\Adobe\Reader 8.0\Reader\AcroRd32.exe" DOE.pdf';
% 
% eval(PDF);
% 
% cd('..');
% 
% end