function [Indice ParetoName IndiceFinal] = Pareto(EIBB,EIBH,EIHB,EIHH,EFB,EFH)

ParetoTemp = [EFB EIBB];

NbParam = size(EFB,2);

NbInterNiv2 = NbParam*(NbParam-1)/2;

NbTotPI = size(ParetoTemp,2);

Iter = 1;

for i=1:1:NbParam
if ((Iter <= NbParam)&&(Iter == 1 ))
    NomParetoTmp = strvcat(char([64+i]));
    Iter = Iter+1;
else if ((Iter <= NbParam)&&(Iter ~= 1 ))
    NomParetoTmp = strvcat(NomParetoTmp,char([64+i]));
    Iter = Iter+1;
    end
end
end


min = 1;
max = NbParam-1;
j=1;
k=2;
for i=1:1:(NbTotPI-NbParam)
   NameTmp = [char([64+j]),char([64+k])];
   NomParetoTmp = strvcat(NomParetoTmp,NameTmp);
       if((i<=max)&&(k<NbParam))
          k=k+1;
       else
          j=j+1;
          k=j+1;
          max = max+NbParam-j;           
       end   
end

for i=1:1:size(ParetoTemp,2)
 ParetoTemp(i) = abs(ParetoTemp(i));
end
    
[ParetoMat Indice] = sort(ParetoTemp,'descend');

for i=1:1:size(ParetoMat,2)
    if(i==1)
    ParetoName(i) = {NomParetoTmp(Indice(i),:)};
    else
    ParetoName(i) = {NomParetoTmp(Indice(i),:)};   
    end
end

ParetoCrit = 0.8;
TolCrit = 0.05;

ParCritMin = ParetoCrit-TolCrit;
ParCritMax = ParetoCrit+TolCrit;
Crit = 0.;
PareBlc = 1;
i=1;
TotalPareto = sum(ParetoMat);
for i=1:1:size(ParetoMat,2)
    Crit = Crit+ParetoMat(i)/TotalPareto;
    if((Crit>=ParCritMin)&&(Crit<=ParCritMax))     
        IndiceFinal = i;
        break; 
    end 
    if(Crit>ParCritMax)
       IndiceFinal = i;
       break;
    end
end

TextTitre = [num2str(Crit*100,'%2.2f'),'% des effets proviennent de ',...
        num2str(IndiceFinal/size(ParetoMat,2)*100,'%2.2f'),'% des facteurs'];

hPareto = figure('name','Diagramme de Pareto',...
                     'NumberTitle','off');
axes('Parent',hPareto,'YTick',zeros(1,0),'YGrid','on','YDir','reverse',...
    'XGrid','on');

hold on;
title(TextTitre,'Fontsize',12);
xlabel('Effet');
ylabel('Facteur');
bar(ParetoMat,'Horizontal','on');
x = get(gca,'XLim');
for i=1:1:size(ParetoName,2)
   text(ParetoMat(i),i,ParetoName(i)); 
end
y = [IndiceFinal+0.5 IndiceFinal+0.5];
plot(x,y,'--r');
hold on;
saveas(hPareto,'Pareto.eps','psc2');


