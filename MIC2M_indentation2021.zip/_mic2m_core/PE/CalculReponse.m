%function Reponse = CalculReponse(TExp,NbParam,BVal)
function Reponse = CalculReponse(fonction_PE,V,TExp)


NbEssais = length(TExp) ;

for i=1:NbEssais
     % ici il faut calculer v en fonction de V et Texp
    %v=[i i i i i]; % provisoirement
    %j=1
    for j=1:size(V,1)
        a=V(j,2); 
        b=V(j,3); 

        v(j)=(a+b)/2+TExp(i,j)*(b-a)/2 ;
    end
    g=feval(fonction_PE,v,i);
    Reponse(i,1)=g;
end

Reponse=Reponse';

%Reponse = [2218 2174 2198 2203 2169 2104 2169 2119];