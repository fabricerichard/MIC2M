function [Variance Ftest Ftheo ddls FSnedTest] = ANOVA(Reponse,...
                                              EIBB,EIBH,EIHB,EIHH,EFB,EFH)
NbParam = size(EFB,2) ;
NbNiveau = 2;
NbExp = size(Reponse,2) ;
ymean = mean(Reponse);


% Calcul de la somme des ecarts des facteurs (SCEF)
% Calcul de la variance des facteurs (VF(i)=SCEF(i)/ddl_i)
% ddl_i=NbNiveau_i-1
for i=1:1:NbParam    
    SCEF(i)=(NbExp)*EFH(i)^2;
    ddlF(i) = NbNiveau-1;
    VF(i) = SCEF(i)/ddlF(i);
end

for i=1:1:size(EIBB,2)
   SCEI(i) =  NbExp*EIHH(i)^2;
   ddlI(i) = (NbNiveau-1)*(NbNiveau-1);
   VI(i) = SCEI(i)/ddlI(i);
end

ST = 0.;
AST = 0.;
ddlT = NbExp-1 ;
for i=1:1:NbExp
    ST = ST+(Reponse(i)-ymean)^2;
end

AST = AST-NbExp*ymean^2;
SR = ST-sum(SCEF)-sum(SCEI);
ddlR = ddlT-(sum(ddlF)+sum(ddlI)) ;

VR = SR/ddlR ;

for i=1:1:NbParam
FtestF(i)=VF(i)/VR;
end

for i=1:1:size(EIBB,2)
FtestI(i)=VI(i)/VR;    
end

Variance = [VI VF VR];
Ftest = [FtestF FtestI];
ddl = [ddlF ddlI];

for i=1:1:size(ddl,2)
   Ftheo(i) = Snedecor95(ddl(i),ddlR); 
end

CalculTest = Ftest-Ftheo;

for i=1:1:size(CalculTest,2)
   if(CalculTest(i)>=0)
    if(i == 1)
     FSnedTest = strvcat('oui');
    else
     FSnedTest = strvcat(FSnedTest,'oui');   
    end
   else
    if(i == 1)
     FSnedTest = strvcat('non');
    else
     FSnedTest = strvcat(FSnedTest,'non');   
    end
   end    
end

ddls = [ddl ddlR] ;




