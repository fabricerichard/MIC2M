function [EIBBOpt,EIBHOpt,EIHBOpt,EIHHOpt,...
       EFBOpt,EFHOpt] = SimpModele(EIBB,EIBH,EIHB,EIHH,EFB,EFH,FSnedTest)
   
for i=1:1:size(EFH,2)
   if(FSnedTest(i,:) == 'oui')
      EFBOpt(i) = EFB(i);
      EFHOpt(i) = EFH(i);
   else
      EFBOpt(i) = 0.;
      EFHOpt(i) = 0.; 
   end  
end

for i=1:1:size(EIBB,2)
   if(FSnedTest(i+size(EFH,2),:) == 'oui')
      EIBBOpt(i) = EIBB(i); 
      EIBHOpt(i) = EIBH(i);
      EIHBOpt(i) = EIHB(i);
      EIHHOpt(i) = EIHH(i);
   else
      EIBBOpt(i) = 0.; 
      EIBHOpt(i) = 0.;
      EIHBOpt(i) = 0.;
      EIHHOpt(i) = 0.; 
   end
end