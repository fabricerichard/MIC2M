function Trial = GeneTableExp(NbParam,NbEssais)

for j=1:1:NbParam
   Iter = NbEssais/2^(j);
   p = 1;
   niv = 1;
   for k=1:1:NbEssais
      Trial(k,j) = niv;
      p=p+1;
      if(p>Iter)
         if(niv == 1)
             niv = -1;
         else 
             niv = 1;
         end
          p = 1;
      end
       
   end
end