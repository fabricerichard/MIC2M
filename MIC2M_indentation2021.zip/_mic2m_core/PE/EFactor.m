function [EFB EFH] = EFactor(TExp,NbParam,Reponse)


for i=1:1:NbParam
    ItB = 1;
    ItH = 1;
    for j=1:1:size(TExp,1)
       if(TExp(j,i)==-1) 
        MatEFB(i,ItB) = Reponse(j);
        ItB = ItB+1;
       end
       if(TExp(j,i)==1)
        MatEFH(i,ItH) = Reponse(j);
        ItH = ItH+1;
       end
    end    
end

for i=1:1:NbParam
   EFB(i) = mean(MatEFB(i,:))-mean(Reponse);
   EFH(i) = mean(MatEFH(i,:))-mean(Reponse);
end

