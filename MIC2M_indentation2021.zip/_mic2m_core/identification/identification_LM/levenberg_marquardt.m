function [cout,para,coutit,parait]=LS(fonction,V,enregistrement)

ARRET=1e-3 ; % ( � diminuer pour un crit�re d'arret + s�v�re : 1e-4 par exemple )

enregistrement=1;

N=size(V,1);
j=0;
for i=1:N
   if abs(V(i,3)-V(i,2))>0
      j=j+1;
      nbp(j)=i ;
   end
end
nbp 

nbparam=length(nbp);
P0=V(nbp(:),1);
V(nbp(:),:) ;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%								%
%			Identification		%
%								%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

P=P0 ;
DP=P ;

landa=0.001
alpha=10;
%dopage=1e-4;
[cout]=feval(fonction,V) ; neval=1 ;
load dopage.txt ;
S=0.5*(cout'*cout) ;
historique_cout=[S];
historique_para=[V(:,1)']; 

coutit=[neval S landa] ; 
parait=[neval V(:,1)'] ;
JR=10 ; JRit=[neval JR] ;
JB=20 ; JBit=[neval JB] ;
Itest=10 ; Itestit=[neval Itest] ;

if enregistrement==1 
   eval(['save  historique_cout_LM.txt historique_cout -ascii']) ;
   eval(['save  historique_para_LM.txt historique_para -ascii']) ;
   eval(['save  coutit_LM.txt coutit -ascii']) ;
   eval(['save  parait_LM.txt parait -ascii']) ;
   eval(['save  JRit_LM.txt JRit -ascii']) ;
   eval(['save  JBit_LM.txt JBit -ascii']) ;
   eval(['save  Itestit_LM.txt Itestit -ascii']) ; 
end

boucle=0;
NORMP  = norm(P)  ; if NORMP  == 0 ; NORMP  = 1e-12 ; end
NORMDP = norm(DP) ; if NORMDP == 0 ; NORMDP = 1e-12 ; end
S0=S;
S=S0-0.01*S0; 
%S=0 ;

while  ((NORMDP/NORMP>ARRET) | (abs(S-S0)/S0>ARRET)) & landa<1000

	if nbparam>1
        c=[0];
      	for i=1:nbparam
           	if V(nbp(i),2)~=0 & V(nbp(i),3)~=0
                if abs((P(i)-V(nbp(i),2))/V(nbp(i),2))<dopage & (P(i)-V(nbp(i),2))~=0; 
                        V(nbp(i),1)=V(nbp(i),2) ; V(nbp(i),3)=V(nbp(i),2) ;
                end
                if abs((P(i)-V(nbp(i),3))/V(nbp(i),3))<dopage & (P(i)-V(nbp(i),3))~=0
                        V(nbp(i),1)=V(nbp(i),3) ; V(nbp(i),2)=V(nbp(i),3) 
                end
                if abs((P(i)-V(nbp(i),2))/V(nbp(i),2))>=dopage & abs((P(i)-V(nbp(i),3))/V(nbp(i),3))>=dopage
                        V(nbp(i),1)=P(i) ;  c=[c,i] ;
                end
            end
        end

        c=c(2:length(c)) ;
        N=size(V,1);
        j=0; 
        clear nbp

     	for i=1:N
  	 		if abs(V(i,3)-V(i,2))>0
                j=j+1 ; nbp(j)=i ;
            end
        end
        
      	if j==0
        	disp('toutes les bornes atteintes') ; 
        	[cout]=feval(fonction,V) ; neval=neval+1 ;
        	S=0.5*(cout'*cout) ;
     		historique_cout=[historique_cout;S]; 
        	historique_para=[historique_para;V(:,1)']; 
        	cout=S ;
        	para=V(:,1)  ;
        	coutit(boucle+1,:)=[neval S landa];
   		    parait(boucle+1,:)=[neval V(:,1)'];
            
     		if enregistrement==1       
    			eval(['save  historique_cout_LM.txt historique_cout -ascii']) ;
                eval(['save  historique_para_LM.txt historique_para -ascii']) ;
                eval(['save  parait_LM.txt parait -ascii']) ;
      		    eval(['save  coutit_LM.txt coutit -ascii']) ;
                eval(['save  JRit_LM.txt JRit -ascii']) ;
                eval(['save  JBit_LM.txt JBit -ascii']) ;
                eval(['save  Itestit_LM.txt Itestit -ascii']) ;
      		    eval(['save  meilleur_LM.txt V -ascii']) ;
            end
        	return
        end
        nbparam=length(nbp) ;
        P=V(nbp(:),1);
   end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
       
   boucle=boucle+1 ;
   if boucle>1 ; landa=landa/alpha ; end
   cout0=cout ;
   S0=S ;
   P0=P ;
   
   % gradient
   clear J ; 
   for i=1:nbparam
      P=P0 ;
      P(i)=P0(i)*(1+dopage) ;
      if P(i)==0 ; P(i)=dopage ; end
      V(nbp(:),1)=P ;
      [cout]=feval(fonction,V) ; neval=neval+1 ;
      S=0.5*(cout'*cout) ;
      historique_cout=[historique_cout;S]; 
      historique_para=[historique_para;V(:,1)']; 
      if enregistrement==1       
         eval(['save  historique_cout_LM.txt historique_cout -ascii']) ;
         eval(['save  historique_para_LM.txt historique_para -ascii']) ;
      end
      J(:,i)=(cout-cout0)/(P(i)-P0(i));
      
      load scm.txt ; load sce.txt ;
      Jtest = (cout.*sce)/(P(i)-P0(i))*P0(i)./(scm)  ;
         
   end
      
   hessientest= Jtest'*Jtest ; 
   
   hessian=J'*J ;
   gra=J'*cout0 ;
   A=hessian ; b=-gra;
   save J_LM.txt J -ascii
   save P_LM.txt P -ascii
   
   %activer la pause pour le calcul des incertitudes
   %pause
   
   %	calcul d'un incr�ment de param�tres possible		%
   testrup=1 ; borne=0 ; 
   while (S>=S0 | testrup==1 | borne==1) & landa<1000
   %landa
      testrup=0 ;
      P=P0 ;
      borne=0;     
      
      clear Ab bb DP P
      for i=1:nbparam
         for j=1:nbparam
            Ab(i,j)=A(i,j)/(A(i,i)*A(j,j))^0.5 ;
         end
         bb(i,1)=b(i,1)/(A(i,i))^0.5 ;
      end
      save Ab.txt Ab -ascii
      Ab;
      e=eig(Ab); 
%      etest=eig(hessientest) ; Itest=log10(real(max(etest)/min(etest))) ; 
%      JR=real(max(e)/min(e));
%      JR=log10(JR);
%      JB=(1/min(e))^0.5;
      DPb=inv(Ab+landa*eye(nbparam))*bb ;
      
      for i=1:nbparam ; DP(i,1)=DPb(i,1)/(A(i,i))^0.5 ; end
      for l=1:nbparam ; P(l)=P0(l)+DP(l) ; end
     
      
      
      %	v�rification de la qualit� de la solution		%
      for l=1:nbparam
         if P(l)>V(nbp(l),3)*(1+0*dopage) | P(l)<V(nbp(l),2)*(1-0*dopage) ; borne =1 ; end	
      end

		if borne==0
        	V(nbp(:),1)=P(:);
         if enregistrement==1
            P_LM=V(:,1);
            eval(['save  P_LM.txt P_LM -ascii']) ;
         end
         [cout,testrup]=feval(fonction,V) ; neval=neval+1 ;
         S=0.5*(cout'*cout) ;
         if testrup==0
         	historique_cout=[historique_cout;S]; 
         	historique_para=[historique_para;V(:,1)']; 
         	if enregistrement==1 
           	 	eval(['save  historique_cout_LM.txt historique_cout -ascii']) ;
            	eval(['save  historique_para_LM.txt historique_para -ascii']) ;
         	end
         end
      end
    	if borne==1 | (testrup==1 & borne==0) | S>=S0 ; landa=landa*alpha ; end
        %if borne==1 | (testrup==1 & borne==0) | abs(S-S0)/S0>ARRET ; landa=landa*alpha ; end

        
   end
   
   for l=1:nbparam ; V(nbp(l),1)=P(l) ; end
   
   
	 if borne==0 & testrup==0 & S<=S0  
	 coutit(boucle+1,:)=[neval S landa];
   parait(boucle+1,:)=[neval V(:,1)'];
   JRit(boucle+1,:)=[neval JR];
   JBit(boucle+1,:)=[neval JB];
   Itestit(boucle+1,:)=[neval Itest];
   end
	 
	 
   if enregistrement==1 
      eval(['save  parait_LM.txt parait -ascii']) ;
      eval(['save  coutit_LM.txt coutit -ascii']) ;
      eval(['save  JRit_LM.txt JRit -ascii']) ;
      eval(['save  JBit_LM.txt JBit -ascii']) ;
      eval(['save  Itestit_LM.txt Itestit -ascii']) ;     
			eval(['save  meilleur_LM.txt V -ascii']) ;
   end

 
   NORMP = norm(P) ; 
   NORMDP = norm(DP) ;

NORMDP/NORMP;
abs(S-S0)/S0;


end

[cout ligne]=min(coutit(:,2)) ; para=parait(ligne,2:N+1)  ;


cout=real(cout) ;
para=real(para);
para = para' ; eval(['save  meilleur_LM.txt para -ascii']) ; para = para' ; 

coutit=real(coutit);
parait=real(parait);
JRit=real(JRit);


