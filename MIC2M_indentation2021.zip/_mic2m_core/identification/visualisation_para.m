clear all
load parait_LM.txt

nbiteration=size(parait_LM,1)

[s,ident,essais,model] = textread(['liste_experiences.txt'],'%s %s %s %s') ;
for i=2:length(s) 
    if strcmp( ident(i),'%')==0
        nom_du_modele=char(model(i)) ;
       end
end
% lecture parametre
fich_parametre = [char(nom_du_modele),'_parametres'] ;
[nom_para,para_nom,a,b,loi,CV] = textread([fich_parametre,'.txt'],'%s %f %f %f %f %f') ;
V=[para_nom,a,b,loi,CV] ;


N=size(V,1);
j=0;
for i=1:N
   if abs(V(i,3)-V(i,2))>0
      j=j+1;
      nbp(j)=i ;
   end
end
nbp 
nbparam=length(nbp);

P0=V(nbp(:),1);
Psol=V(nbp(:),4) ; %%% solution !!!

Pit=parait_LM(:,nbp(:)+1);
Pit=Pit';
ncalc=parait_LM(:,1);
nP=size(P0,1);

for i=1:nP
    %normPit(i,:)=Pit(i,:)./P(i);
    normPit(i,:)=Pit(i,:)./Psol(i); %%%%%% solution !!!
end
normPit
for i=1:nP
     plot(normPit(i,:));
    hold on
end


