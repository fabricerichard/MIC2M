function [bestindiv,besterreur]=identification_fabrice(ferreur,V)
% fonction identification de parametres
% ferreur : nom de la fonction erreur entre le modele et l'experience

% ATTENTION : cette fonction utilise les operateurs genetiques :
% reproduction, croisement, mutation

% V(:,2) et V(:,3) : bornes sur les parametres
% nindividu : nombre d'individus
% probmut : probabilite de mutation
% probcrois : probabilite de croisement
% ngeneration : nombre de generation maxi
% Fabrice RICHARD (1998)


% utilisation d'une population de d�part
generation0=0 ;

N=size(V,1);
j=0;
for i=1:N
    if abs(V(i,3)-V(i,2))>0
        j=j+1;
        nP(j)=i;
    end
end
nP
nbp=length(nP);
Xmin=V(nP(:),2)';
Xmax=V(nP(:),3)';


nindividu=nbp*10 ; % nombre d'individus (10*nP)
probmut=1/nindividu ; % probabilite de mutation (0.1 par defaut)
probcrois=0.8 ; % probabilite de croisement (0.8 par defaut)
ngeneration=20;  % nombre de generation


for w=1:1
nomw= int2str(w) ;

X=zeros(nindividu,nbp) ;

% initialisation des fichiers resultats
meilleur_parametre_genetique(1,:)=zeros(1,nbp+1) ;
meilleur_erreur_genetique(1,:)=zeros(1,2) ;
eval(['save ',['meilleur_parametre_genetique',nomw,'.txt'],' meilleur_parametre_genetique -ascii -double -tabs']) ;
eval(['save ',['meilleur_erreur_genetique',nomw,'.txt'],' meilleur_erreur_genetique -ascii -double -tabs']) ;


%%%%%%%%%%%%%%
% resolution %
%%%%%%%%%%%%%%

generation=0 ; 

while generation<=ngeneration

   err=zeros(nindividu,1);  f=zeros(nindividu,1);
   
   if generation>0 | generation0==0
      for individu=1:nindividu
         if generation==0
            for j=1:nbp
               XXX = rand(1) ;
               X(individu,j)=Xmin(j) + XXX*( Xmax(j)-Xmin(j) ) ;
            end
            % sauvegarde de l'individu en cours
            sauveP=X(individu,:);
            eval(['save ','parametre_genetique.txt',' sauveP -ascii -double -tabs']) ;
         end
         for j=1:nbp
             V(nP(j),1)=X(individu,j);
         end
         
         % l'erreur
         err(individu,1)=feval(ferreur,V);
         
         % l'historique
         feval('historique',individu,generation,X(individu,:),err(individu,1),nomw) ;
      end
   end
 
   if generation==0 & generation0==1
       %utilisation d'une generation0
      nff='parametre_generation0' ;
      eval(['load ',nff,'.txt']) ; parametre_generation0=eval(nff) ;
      nff='erreur_generation0' ;
      eval(['load ',nff,'.txt']) ; erreur_generation0=eval(nff) ;
      nind=size(parametre_generation0,1);
      
      if nind<nindividu ; disp('generation0 insuffisante') ; pause ; end
      
      eval(['save ',['historique_parametre_','genetique.txt'],' parametre_generation0 -ascii -double -tabs']) ;
      eval(['save ',['historique_erreur_','genetique.txt'],' erreur_generation0 -ascii -double -tabs']) ;

      err=erreur_generation0(nind-nindividu+1:nind,:) 
      X=parametre_generation0(nind-nindividu+1:nind,:)
   end
      
   % meilleur individu
   [minerr ligne]=min(err(:,1)) ;
   
   if generation==0
      besterreur=minerr ; bestindiv=X(ligne,:) ;
   else
      if minerr<besterreur besterreur=minerr ; bestindiv=X(ligne,:) ; end
   end
      
   fprintf(1,'Generation: %d,  Best: %f\n',generation,besterreur);
   meilleur_parametre_genetique(generation+1,:)=[generation bestindiv] ;
   meilleur_erreur_genetique(generation+1,:)=[generation besterreur] ;
   eval(['save ',['meilleur_parametre_genetique',nomw,'.txt'],' meilleur_parametre_genetique -ascii -double -tabs']) ;
   eval(['save ',['meilleur_erreur_genetique',nomw,'.txt'],' meilleur_erreur_genetique -ascii -double -tabs']) ;


   %for n=1:nP
   %      fprintf(1,'best(%d) = %f\n',n,bestindiv(1,n));
   %end
 
   % operateurs genetiques
   f=1./err ;
   
   X=feval('reproduction',X,f);
   X=feval('croisement',X,probcrois);
   X=feval('mutation',X,Xmin,Xmax,probmut); 
   generation=generation+1 ;

end

end


