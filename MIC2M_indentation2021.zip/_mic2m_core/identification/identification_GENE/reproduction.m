function [nouveaux_gen,selectionne] = reproduction(vieux_gen,adaptation)
% operateur genetique de reproduction
% les individus sont reproduits proportionnellement a leur adaptation
% Fabrice RICHARD (1998)


nindividu=size(vieux_gen,1);
ngene=size(vieux_gen,2);

norm_adapt = adaptation/sum(adaptation);
selectionne = rand(size(adaptation));
sum_adapt = 0;

for i=1:nindividu
   sum_adapt = sum_adapt + norm_adapt(i);
   index = find(selectionne<sum_adapt);
   selectionne(index) = i*ones(size(index));
end

nouveaux_gen = vieux_gen(selectionne,:);
