function [nouveaux_gen,mute] = mutation(vieux_gen,Xmin,Xmax,Pm)
% operateur genetique de mutation
% Pm: probabilite de mutation
% Fabrice RICHARD (1998)

nindividu=size(vieux_gen,1) ;
ngene=size(vieux_gen,2) ;
nouveaux_gen = vieux_gen;

for i=1:nindividu
   for j=1:ngene
      if rand(1)<Pm
         nouveaux_gen(i,j) = Xmin(j) + rand(1)*( Xmax(j)-Xmin(j) ) ;
      end
   end
end
