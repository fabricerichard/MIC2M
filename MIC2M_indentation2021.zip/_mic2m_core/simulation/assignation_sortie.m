function assignation_sortie(nom_var,sortie)


for i=1:size(nom_var,1) ; 
   nom=char(nom_var(i)) ; assignin('base',nom,sortie(:,i)) ;
end
