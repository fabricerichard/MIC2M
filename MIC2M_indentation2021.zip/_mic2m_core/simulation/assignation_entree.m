function assignation_entree(temps,nom_entree,entree)

for i=1:length(nom_entree) ; 
   nom=[char(nom_entree(i)) '_exp'] ;
   assignin('base',nom,entree(:,i)) ;
end
assignin('base','temps_exp',temps(:,1)) ;
