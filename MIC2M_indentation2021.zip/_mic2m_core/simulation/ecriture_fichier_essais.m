function []=ecriture_fichier_essais()

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all

fich_essai = 'test_PP_traction01' ;

com=['3',' ','asservi',' ','observe'];B=[cellstr(com)] ;
com=['temps',' ','sigz',' ','epsz'] ; B=[B;cellstr(com)] ;
com=['0',' ','0',' ','0'];B=[B;cellstr(com)] ;

%v0      = 30 ;   % valeur max du premier pic
v0      = 5 ;   % valeur max du premier pic

var_dot   = .1 ;  % vitesse de charge

%ncycles = 5 ;   % nb de cycles
%vmin =[0 0 0 ] ;
%vmax =[0 v0 0] ;
vmin =[0 0 0 0 0 0 0] ;
vmax =[0 v0 10 15 25 40 0] ;
%vmin =[0 0  0   0   0  0  0 ] ;
%vmax =[0 v0 60 90 150 230  0 ] ;
dv=vmax-vmin ;
 
%inc=[v0 50 100 200 100] ;        % increment de la valeur max /cycle
ncycles = length(vmax)-1 % nb de cycles

periode = v0/var_dot 
k =0;
temps =0;
var =0;
%vmax =v0;
maintien = 0 ;

for nb=2:ncycles
    %if n>1 
        %vmax  =  inc(n) ;% end ;
      vmax(nb)
    for i=1:2
        for m=1:50    
            if i==1
                k=k+1  ;  
                var = var + var_dot*(vmax(nb)-vmin(nb-1))/var_dot/50 ; V(k)=var ;   
                temps = temps + (vmax(nb)-vmin(nb-1))/var_dot/50 ; t(k)=temps ;
                com=[num2str(temps),' ',num2str(var),' ','0'] ; B=[B;cellstr(com)] ;
                if maintien~=0 & m==50 ; 
                    for n=1:50 ; 
                        k=k+1 ; V(k)=var ; temps = temps + maintien/50 ; t(k)=temps  ;
                        com=[num2str(temps),' ',num2str(var),' ','0'] ; B=[B;cellstr(com)] ;
                    end
                end
            else
                k=k+1 ;
                temps = temps + (vmax(nb)-vmin(nb))/var_dot/50 ; t(k)=temps ;
                var = var - var_dot*(vmax(nb)-vmin(nb))/var_dot/50 ; V(k)=var ;
                com=[num2str(temps),' ',num2str(var),' ','0'] ; B=[B;cellstr(com)] ;
            end
        end
    end
end

plot([0,t],[0,V],'ro')

fid = fopen([fich_essai,'.txt'],'w');
for i=1:size(B,1)   ;  fprintf(fid,'%s\n',char(B(i))) ; end
fclose('all');

[temps,nom_entree,type_entree,entree]=lecture_fichier_essais(fich_essai);
hold on
plot(temps,entree(:,1),'+g');

