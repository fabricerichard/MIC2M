function assignation_var(nom_var,var)
% assigne a la chaine de caracteres nom_para(i) la valeur valeur_para(i)
% dans la fonction appelante

for i=1:size(nom_var,1) ; 
   nom=char(nom_var(i)) ; assignin('caller',nom,var(i)) ;
end
