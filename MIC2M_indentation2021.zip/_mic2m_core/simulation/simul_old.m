function [temps,sortie,test_rupture,aux]=simul(fich_essai,mode)

%mode='i'
load k_iteration.txt
disp('sauvegarde k_iteration desactive') ; k_iteration = 0 ;

%k_it = 0 ; save k_criblage.txt k_criblage -ascii ; % initialisation du compteur
%k_identification = 0 ; save k_identification.txt k_identification -ascii ; % initialisation du compteur

nom_du_modele = textread(['nom_du_modele','.txt'],'%s') ;
nom_modele = [char(nom_du_modele),'_dot'] ;
fich_parametre = [char(nom_du_modele),'_parametres'] ;
fich_variable =  [char(nom_du_modele),'_variables'] ;

% lecture parametre
[nom_para,para_nom,a,b,loi,para_opt] = textread([fich_parametre,'.txt'],'%s %f %f %f %f %s') ;
load parametres.txt;
para_nom= parametres;

% lecture du fichier variables
[num_var,nom_var,var_0,graph] = textread([fich_variable,'.txt'],'%f %s %f %s') ;


% lecture du fichier essai
%fid = fopen('nom_experience.txt','w');
%for i=1:size(char(fich_essai),2)   ;  fprintf(fid,'%s',char(fich_essai(i))) ; end
%fclose('all');
[temps,nom_entree,type_entree,entree]=lecture_fichier_essais(fich_essai) ;

%temps=temps/10;
assignation_entree(temps,nom_entree,entree) 
save entree.txt entree -ascii

nligne=length(temps);

type_var = type_variable(nom_var,type_entree,nom_entree) ;
% type_var
% var_0
% type_entree
% nom_entree
% entree


for i=1:size(nom_var,1) ; 
   nom=[char(nom_var(i))] ;
   if strcmp(type_var(i),'asservi')==1

       for j=1:size(type_entree,2)
            if strcmp(nom_entree(j),nom)==1 
                var_0(i)=entree(1,j) ;
            end
       end
   end
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[nom_var,type_var];
[nom_entree;type_entree];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

disp(' ')
disp(['nom du fichier essai : ',fich_essai])

fprintf('variables asservies : ') ; 
for i=1:length(type_var) ; if strcmp(type_var(i),'asservi')==1 ; fprintf('%s  ',char(nom_var(i))) ; end ; end
disp(' ')
fprintf('variables observees : ') 
for i=1:length(type_var) ; if strcmp(type_var(i),'observe')==1 ; fprintf('%s  ',char(nom_var(i))) ; end ; end
disp(' ')
fprintf('variables autres : ') 
for i=1:length(type_var) ; 
    if strcmp(type_var(i),'asservi')==0 & strcmp(type_var(i),'observe')==0 ; fprintf('%s  ',char(nom_var(i))) ;  end 
end
disp(' ')
disp(['nombre d''increments de calcul : ',num2str(nligne)])
 

ndm=char(nom_du_modele) ;
if strcmp(ndm(1:3),'EF_')==1
    dopage=5e-3
    save dopage.txt dopage -ascii ;
    [temps,sortie,test_rupture,aux]=feval( ['calcul_',ndm],nom_modele,nom_para,para_nom,type_var,num_var,nom_var,var_0,type_entree,nom_entree,entree,temps,nligne,mode) ; 
else
    if strcmp(ndm(1:6),'AUTRE_')
    dopage=1e-3
    save dopage.txt dopage -ascii ;
    [temps,sortie,test_rupture,aux]=feval( ['calcul_',ndm],nom_modele,nom_para,para_nom,type_var,num_var,nom_var,var_0,type_entree,nom_entree,entree,temps,nligne,mode) ;    
    else
    dopage=1e-4
    save dopage.txt dopage -ascii ;
    [temps,sortie,test_rupture,aux]=calcul(nom_modele,nom_para,para_nom,type_var,num_var,nom_var,var_0,type_entree,nom_entree,entree,temps,nligne,mode) ;
    end
end
disp(' ')

%sortie
assignation_sortie(nom_var,sortie) ;


if k_iteration>0
    eval(['save ',['parametres_iteration',num2str(k_iteration),'.txt'],' parametres -ascii']) ;   
    eval(['save ',['temps_iteration',num2str(k_iteration),'.txt'],' temps -ascii']) ;
    eval(['save ',['sortie_iteration',num2str(k_iteration),'.txt'],' sortie -ascii']) ;
end

k_iteration = k_iteration+1 ;  save k_iteration.txt k_iteration -ascii ; 

