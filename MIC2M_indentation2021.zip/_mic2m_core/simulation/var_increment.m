function [Dvar_asservi,Dtemps]=var_increment(type_var,nom_var,var,type_entree,nom_entree,entree,temps,t)
%

nentree=length(nom_entree) ;
nvar=length(nom_var) ;

for i=1:nvar ; 
   Dvar_asservi(i,1)=0 ;
end

ligne=find( temps(:,1)== t ) ;

for i=1:nvar
   for j=1:nentree
      if strcmp(nom_var(i),nom_entree(j))==1
      	if strcmp(type_var(i,1),'asservi')==1
                  Dvar_asservi(i,1)=entree(ligne+1,j)-entree(ligne,j)  ;
         end
      end
   end
end

Dtemps = temps(ligne+1,1)-temps(ligne,1)  ;
