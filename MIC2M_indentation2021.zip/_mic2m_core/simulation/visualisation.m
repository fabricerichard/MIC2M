

nom_du_modele = textread(['nom_du_modele','.txt'],'%s') ;
fich_variable =  [char(nom_du_modele),'_variables'] ;
[num_var,nom_var,var_0,graph] = textread([fich_variable,'.txt'],'%f %s %f %s') ;


mode='0' ; 

x='temps' ;
y='temps' ;
couleur_sim='r' ;  marque_sim='-' ; couleur_exp='b' ;  marque_exp='o' ; mode='s+e' ;    

for i=1:length(graph)
    
    j=char(graph(i)) ;
    
    if j(1)== 'y' ; 
        y=char(nom_var(i)) ;
        if length(j)>1
            if j(3:5)=='exp'
                %disp('affichage exp�rience')
                %couleur_exp=j(7) ;  marque_exp=j(8) ; 
                mode='exp' ; 
            end
            if j(3:5)=='sim'
                %disp('affichage simulation')
                %couleur_sim=j(7) ;  marque_sim=j(8) ; 
                mode='sim' ; 
            end
            if j(3:5)=='s+e'
                %disp('affichage simulation + exp�rience')
                if length(j)==10 ; couleur_sim=j(7) ;  marque_sim=j(8) ; couleur_exp=j(9) ;  marque_exp=j(10) ; mode='s+e' ; end
            end 
        end
    end 
    if j(1)== 'x' ; 
        x=char(nom_var(i)) ;
        if length(j)>1
            if j(3:5)=='exp'
                %disp('affichage exp�rience')
                %couleur_exp=j(7) ;  marque_exp=j(8) ; 
                mode='exp' ; 
            end
            if j(3:5)=='sim'
                %disp('affichage simulation')
                %couleur_sim=j(7) ;  marque_sim=j(8) ; 
                mode='sim' ; 
            end
            if j(3:5)=='s+e'
                %disp('affichage simulation + exp�rience')
                if length(j)==10 ; couleur_sim=j(7) ;  marque_sim=j(8) ; couleur_exp=j(9) ;  marque_exp=j(10) ; 
                mode='s+e' ; end
            end 
        end
    end  
    
end
disp('') 
if mode=='0'   ; disp('erreur dans la programmation  de l''affichage') ; end
if mode=='sim' ; disp('affichage simulation') ; end
if mode=='exp' ; disp('affichage experience') ; end
if mode=='s+e' ; disp('affichage simulation + experience') ; end


% y     yellow        .     point              -     solid
% m     magenta       o     circle             :     dotted
% c     cyan          x     x-mark             -.    dashdot 
% r     red           +     plus               --    dashed   
% g     green         *     star
% b     blue          s     square
% w     white         d     diamond
% k     black         v     triangle (down)
%                     ^     triangle (up)
%                     <     triangle (left)
%                     >     triangle (right)
%                     p     pentagram
%                     h     hexagram


% AFFICHAGE

if mode=='exp' | mode=='s+e'; exp=[marque_exp,couleur_exp] ; x_exp=eval([x,'_exp']) ; y_exp=eval([y,'_exp']) ; end
if mode=='sim' | mode=='s+e'; sim=[marque_sim,couleur_sim] ; x_sim=eval([x]) ; y_sim=eval([y]) ; end

xx=x ; yy=y ;

if strncmpi(x,'eps',3)==1
   if mode=='exp' | mode=='s+e' ; x_exp=x_exp*100 ; end
   if mode=='sim' | mode=='s+e' ; x_sim=x_sim*100 ; end
end
if strncmpi(y,'eps',3)==1 
   if mode=='exp' | mode=='s+e' ; y_exp=y_exp*100 ; end
   if mode=='sim' | mode=='s+e' ; y_sim=y_sim*100 ; end
end

if strncmpi(x,'tem',3)==1
   if mode=='exp' | mode=='s+e' ; x_exp=x_exp/1 ; end
   if mode=='sim' | mode=='s+e' ; x_sim=x_sim/1 ; end
end
if strncmpi(y,'tem',3)==1 
   if mode=='exp' | mode=='s+e' ; y_exp=y_exp/1 ; end
   if mode=='sim' | mode=='s+e' ; y_sim=y_sim/1 ; end
   end

if strcmp(y,'temps')==1 ;  yy='\it{t} \rm(s)' ; end
if strcmp(y,'sigr')==1 ;   yy='\it{\sigma_r} \rm(MPa)' ; end
if strcmp(y,'sigt')==1 ;   yy='\it{\sigma_\theta} \rm(MPa)' ; end
if strcmp(y,'sigz')==1 ;   yy='\it{\sigma_z} \rm(MPa)' ; end
if strcmp(y,'epsz')==1 ;   yy='\it{\epsilon_z} \rm(%)' ; end
if strcmp(y,'epst')==1 ;   yy='\it{\epsilon_\theta} \rm(%)' ; end
if strcmp(y,'epsr')==1 ;   yy='\it{\epsilon_r} \rm(%)' ; end
if strcmp(y,'epsvpr')==1 ; yy='\it{\epsilon^{vp}_r} \rm(%)' ; end
if strcmp(y,'epsvpt')==1 ; yy='\it{\epsilon^{vp}_\theta} \rm(%)' ; end
if strcmp(y,'epsvpz')==1 ; yy='\it{\epsilon^{vp}_z} \rm(%)' ; end
if strcmp(y,'epsinr')==1 ; yy='\it{\epsilon^{in}_r} \rm(%)' ; end
if strcmp(y,'epsint')==1 ; yy='\it{\epsilon^{in}_\theta} \rm(%)' ; end
if strcmp(y,'epsinz')==1 ; yy='\it{\epsilon^{in}_z} \rm(%)' ; end
if strcmp(y,'sig1')==1 ;   yy='\it{\sigma_1} \rm(MPa)' ; end
if strcmp(y,'sig2')==1 ;   yy='\it{\sigma_2} \rm(MPa)' ; end
if strcmp(y,'sig3')==1 ;   yy='\it{\sigma_3} \rm(MPa)' ; end

if strcmp(y,'sig6')==1 ;   yy='\it{\tau} \rm(MPa)' ; end
if strcmp(y,'eps6')==1 ;   yy='\it{\gamma} \rm(%)' ; end

if strcmp(y,'eps1')==1 ;   yy='\it{\epsilon_1} \rm(%)' ; end
if strcmp(y,'eps2')==1 ;   yy='\it{\epsilon_2} \rm(%)' ; end
if strcmp(y,'eps3')==1 ;   yy='\it{\epsilon_3} \rm(%)' ; end


if strcmp(y,'epsvp1')==1 ; yy='\it{\epsilon^{vp}_1} \rm(%)' ; end
if strcmp(y,'epsvp2')==1 ; yy='\it{\epsilon^{vp}_2} \rm(%)' ; end
if strcmp(y,'epsvp3')==1 ; yy='\it{\epsilon^{vp}_3} \rm(%)' ; end
if strcmp(y,'epsin1')==1 ; yy='\it{\epsilon^{in}_1} \rm(%)' ; end
if strcmp(y,'epsin2')==1 ; yy='\it{\epsilon^{in}_2} \rm(%)' ; end
if strcmp(y,'epsin3')==1 ; yy='\it{\epsilon^{in}_3} \rm(%)' ; end

if strcmp(y,'FY')==1 ; yy='\it{P }\rm(mN)' ; end
if strcmp(y,'P')==1 ; yy='\it{P }\rm(mN)' ; end

if strcmp(x,'temps')==1 ;  xx='\it{t} \rm(s)' ; end
if strcmp(x,'sigr')==1 ;   xx='\it{\sigma_r} \rm(MPa)' ; end
if strcmp(x,'sigt')==1 ;   xx='\it{\sigma_\theta} \rm(MPa)' ; end
if strcmp(x,'sigz')==1 ;   xx='\it{\sigma_z} \rm(MPa)' ; end
if strcmp(x,'epsz')==1 ;   xx='\it{\epsilon_z} \rm(%)' ; end
if strcmp(x,'epst')==1 ;   xx='\it{\epsilon_\theta} \rm(%)' ; end
if strcmp(x,'epsr')==1 ;   xx='\it{\epsilon_r} \rm(%)' ; end
if strcmp(x,'epsvpr')==1 ; xx='\it{\epsilon^{vp}_r} \rm(%)' ; end
if strcmp(x,'epsvpt')==1 ; xx='\it{\epsilon^{vp}_\theta} \rm(%)' ; end
if strcmp(x,'epsvpz')==1 ; xx='\it{\epsilon^{vp}_z} \rm(%)' ; end
if strcmp(x,'epsinr')==1 ; xx='\it{\epsilon^{in}_r} \rm(%)' ; end
if strcmp(x,'epsint')==1 ; xx='\it{\epsilon^{in}_\theta} \rm(%)' ; end
if strcmp(x,'epsinz')==1 ; xx='\it{\epsilon^{in}_z} \rm(%)' ; end
if strcmp(x,'sig1')==1 ;   xx='\it{\sigma_1} \rm(MPa)' ; end
if strcmp(x,'sig2')==1 ;   xx='\it{\sigma_2} \rm(MPa)' ; end
if strcmp(x,'sig3')==1 ;   xx='\it{\sigma_3} \rm(MPa)' ; end
if strcmp(x,'eps1')==1 ;   xx='\it{\epsilon_1} \rm(%)' ; end
if strcmp(x,'eps2')==1 ;   xx='\it{\epsilon_2} \rm(%)' ; end
if strcmp(x,'eps3')==1 ;   xx='\it{\epsilon_3} \rm(%)' ; end

if strcmp(x,'sig6')==1 ;   xx='\it{\tau} \rm(MPa)' ; end
if strcmp(x,'eps6')==1 ;   xx='\it{\gamma} \rm(%)' ; end

if strcmp(x,'epsvp1')==1 ; xx='\it{\epsilon^{vp}_1} \rm(%)' ; end
if strcmp(x,'epsvp2')==1 ; xx='\it{\epsilon^{vp}_2} \rm(%)' ; end
if strcmp(x,'epsvp3')==1 ; xx='\it{\epsilon^{vp}_3} \rm(%)' ; end
if strcmp(x,'epsin1')==1 ; xx='\it{\epsilon^{in}_1} \rm(%)' ; end
if strcmp(x,'epsin2')==1 ; xx='\it{\epsilon^{in}_2} \rm(%)' ; end
if strcmp(x,'epsin3')==1 ; xx='\it{\epsilon^{in}_3} \rm(%)' ; end

if strcmp(x,'UY')==1 ; xx='\it{h }\rm(\mum)' ; end
if strcmp(x,'h')==1 ; xx='\it{h }\rm(\mum)' ; end

hold on


if mode=='exp' | mode=='s+e' ; plot(x_exp,y_exp,exp,'LineWidth',1) ; end
if mode=='sim' | mode=='s+e' ; plot(x_sim,y_sim,sim,'LineWidth',1.5) ; end


%set(gca,'FontName','Times New Roman','fontsize',35)
set(gca,'FontName','Cambria','fontsize',35)

%a=xlabel(xx) ; set(a,'fontsize',35,'FontName','Times New Roman')
%b=ylabel(yy) ; set(b,'fontsize',35,'Rotation',0,'FontName','Times New Roman')
a=xlabel(xx) ; set(a,'fontsize',35,'FontName','Cambria')
b=ylabel(yy) ; set(b,'fontsize',35,'Rotation',90,'FontName','Cambria')

axis square
grid
box on


%set(1,'Position',[232 139 755 539])

% flux
% \it{\Phi}\rm = 2 10^{14} n/cm^2/s
% 
% 
% \it{\Phi}\rm = 2 10^{14} n/cm^2/s
% 
% 
% legend(a,'\it{\Phi}\rm = 0  , 140 MPa, Isabelle', ...
%   '\it{\Phi}\rm = 0','\it{\Phi}\rm = 1.2 10^{14} n/cm^2/s','\it{\Phi}\rm = 1.7 10^{14} n/cm^2/s','\it{\Phi}\rm = 0, 100 MPa, Isabelle')
% 

