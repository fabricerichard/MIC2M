function [var_dot] = v_ec_cine_nl_iso_3D_dot(t,var,flag,nom_para,para,type_var,num_var,nom_var,var_asservi_dot)
%function [var_dot,test_rupture,aux]=v_ec_cine_nl_iso_3D_dot(nom_para,para,type_var,num_var,nom_var,var,var_asservi_dot,pas_temps)

test_rupture=0;
aux=0;
% parametres
assignation_para(nom_para,para)

% variables
assignation_var(nom_var,var) 
assignation_var_asservi_dot(nom_var,var_asservi_dot) 

sig   = [ sigr   ; sigt   ; sigz   ; sigtz   ;  sigrz  ; sigrt   ] ;
eps   = [ epsr   ; epst   ; epsz   ; epstz   ; epsrz   ; epsrt   ] ; 
epse  = [ epser  ; epset  ; epsez  ; epsetz  ; epserz  ; epsert  ] ; 
epsin = [ epsinr ; epsint ; epsinz ; epsintz ; epsinrz ; epsinrt ] ;
X     = [ Xr     ; Xt     ; Xz     ; Xtz     ; Xrz     ; Xrt     ] ;

G = E/ (2*(1+Nu)) ;

Sij = [	1/E,-Nu/E,-Nu/E,0,0,0 ;...
 	-Nu/E,1/E,-Nu/E,0,0,0 ;...
 	-Nu/E,-Nu/E,1/E,0,0,0 ;...
	0,0,0,1/G,0,0         ;...
	0,0,0,0,1/G,0         ;...
	0,0,0,0,0,1/G ]  ;
Cij = inv(Sij) ;

Di = [ 1;1;1;0;0;0 ] ;
sigp = sig - 1/3*Di'*sig*Di ;
%Xp   = X - 1/3*Di'*X*Di ;

Mij = [	 2/3,-1/3,-1/3,0,0,0 ;...
	-1/3,2/3,-1/3,0,0,0  ;...
	-1/3,-1/3,2/3,0,0,0  ;...
	0,0,0,2,0,0          ;...
	0,0,0,0,2,0          ;...
	0,0,0,0,0,2 ]  ;
	   
sigeq    = ( 3/2 * (sigp-X)' * Mij * (sigp-X) )^0.5  ;
Xeq      = ( 3/2 * X' * Mij * X )^0.5  ;
F        = ( 3/2 * (sigp-X)' * Mij * (sigp-X) )^0.5 - sigy - R ;

if F<=0  F = 1e-12 ; end
if sigeq <= 0  sigeq = 1e-12 ; end
if Xeq==0 ; Xeq=1e-12 ; end

% loi
epsineq_dot = (F/K)^n ;

% normalite
epsin_dot   = 3/2 * epsineq_dot * Mij * ( sigp-X ) /sigeq ;

% ecrouissage
Y0=C/g ; p=g ;
Yet=Y0 + Yiso;
X_dot = p  * ( 2/3*Yet*epsin_dot - X *epsineq_dot ) - rm*(Xeq/X0)^m0 *(X/Xeq) ;
R_dot = b*(Q-R)*epsineq_dot ;
Yiso_dot    = bY*(Yisosat-Yiso)*epsineq_dot ;

A = [ 	zeros(6,24) ; ...
	-eye(6,6) , zeros(6,6) , Cij        , zeros(6,6) ; ...
	zeros(6,6), -eye(6,6)  , eye(6,6)   , eye(6,6)   ; ...
	zeros(6,6), zeros(6,6) , zeros(6,6) , eye(6,6) ] ;

% asservissement
impose = [ zeros(6,1) ; zeros(6,1) ; zeros(6,1) ; epsin_dot ] ;

j=0 ;
for i=1:length(type_var)
    if strcmp(type_var(i),'asservi')==1
        j=j+1 ;
        A(j,i)  = 1 ;
        impose(j)=var_asservi_dot(i) ; 
    end
end   

var_dot = A \ impose ;  

var_dot = [ var_dot ; epsineq_dot ; X_dot ; R_dot ; Yiso_dot] ;


