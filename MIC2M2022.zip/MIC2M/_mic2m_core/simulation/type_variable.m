function type_var=type_variable(nom_var,type_entree,nom_entree)
%

nentree=length(nom_entree) ;
nvar=length(nom_var) ;

for i=1:nvar ; 
   type_var{i,1}='?' ;
end

for i=1:nvar
   for j=1:nentree
      %if j<=nvar
        if strcmp(nom_var(i),nom_entree(j))==1
            type_var{i,1}=type_entree{j} ;
        end 
      %end
  end
end

