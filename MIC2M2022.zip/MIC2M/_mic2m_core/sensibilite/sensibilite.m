clear all

% CHOIX DU MODELE 
%liste_modele = textread(['liste_modele','.txt'],'%s') ;
%disp(' ')
%for i=1:size(liste_modele,1) ; disp(['(',num2str(i),')','  ',char(liste_modele(i))]) ; end  
%disp(' ') ; 
%choix = input('CHOIX : ') ; nom_du_modele = char(liste_modele(choix)) 


[s,ident,essais,model] = textread(['liste_experiences.txt'],'%s %s %s %s') ;
    for i=2:length(s) 
        if strcmp( ident(i),'%')==0 
            nom_du_modele=char(model(i)) ;
        end
    end
    
fid = fopen('nom_du_modele.txt','w');
for i=1:size(char(nom_du_modele),2)   ;  fprintf(fid,'%s',char(nom_du_modele(i))) ; end
fclose('all');
% lecture parametre
%fich_parametre = [char(nom_du_modele),'_parametres'] ;
%[nom_para,para_nom,a,b,loi,CV] = textread([fich_parametre,'.txt'],'%s %f %f %f %f %f') ;
%V=[para_nom,a,b,loi,CV] ;


% lecture parametre
nom_fich = [char(nom_du_modele),'_parametres'] 
%[nom_para,para_nom,a,b,loi,CV] = textread([fich_parametre,'.txt'],'%s %f %f %f %f %f') ; ancien code matlab
%T = textread([fich_parametre,'.txt'],'%s','delimiter','\n');nombre_de_lignes = size(T,1) ;
fid = fopen([nom_fich,'.txt'],'r') ; X = fread(fid) ; fclose(fid) ; nombre_de_lignes = sum(X==10) ;
fid = fopen([nom_fich,'.txt']) ; C = textscan(fid, '%s %f %f %f %f %f', nombre_de_lignes) ; fclose(fid) ;
[nom_para,para_nom,a,b,loi,CV] = C{:} ;
V=[para_nom,a,b,loi,CV] ;



% CHOIX DU MODELE DE RESOLUTION

[sensi]=derive1('fsensi',V,1) ;
%plot(Sit(:,1),Sit(:,2))
eval(['save  sensi.txt sensi -ascii']) ;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all

clear all
load sensi.txt

N=size(sensi,1) ;
np=size(sensi,2) ;
%sensi=sensiH;
%sensi=sensiBR;
% E, pr, Sigy, Hardi, Beta, Epsd, S, T
etude = 1:np
%etude=[1  2 3 4 5 6 7 8 9 10 11  ];
% 
% load J_LM.txt
% load P_LM.txt
% et_essai=1e-4
% inv(J_LM(:,etude)'*J_LM(:,etude))
% c_v1=2*diag(inv(J_LM(:,etude)'*J_LM(:,etude))).^.5./P_LM*et_essai
% %bar(c_v1)
% 
% 
% load J.txt
% load P.txt
% et_essai=1e-4
% inv(J(:,etude)'*J(:,etude))
% c_v2=2*diag(inv(J(:,etude)'*J(:,etude))).^.5./P*et_essai
% c_v2=(2*diag(inv(J(:,etude)'*J(:,etude))).*et_essai).^.5
% 
% bar(c_v2)



%sensi=(sensi(2:N,:));
%N=N-1;

%fisher=sensi'*sensi;
%real(max(eig(fisher)))/min(eig(fisher))

for i = 1:np
    deltam_sqr(i)  = 1 * norm((sensi(:,i)),2) ;
    deltam_abs(i)  = 1/N^.5  * norm((sensi(:,i)),1) ; %N^.5 deja dans sensi
    deltam_mean(i) = 1/N^.5    * mean(sensi(:,i)) ;
    deltam_max(i)  =N^.5* max (sensi(:,i)) ;
    deltam_min(i)  =N^.5* min (sensi(:,i)) ;    
end

%delta = [deltam_sqr ; deltam_abs ;  ; deltam_mean ; deltam_max ; deltam_min]
delta = deltam_abs
delta = deltam_abs

%deltam_min]
%fisher=sensi(:,[1,2,3,4])'*sensi(:,[1,2,3,4]);e=eig(fisher);Je=max(e)/min(e)
figure(1) ; %hold on
bar(delta(etude))


% E, pr, Sigy, Hardi, Beta, Epsd, S, T
%plot(sensi)
save delta.txt delta -ascii


Je(1)=1e10 ;
for i=2:N
    fisher=sensi(1:i,etude)'*sensi(1:i,etude);e=eig(fisher);
    Je(i)=real(max(e)/min(e)) ; detJe(i)=real(det(fisher)^(1/length(etude))) ;
    if Je(i)<1e-3 ;  Je(i)=1e10  ; end
end
save fisher.txt fisher -ascii

real(max(e)/min(e))
load P.txt
%erreur=1e-2
%c_v=(diag(inv(fisher(:,etude)'*fisher(:,etude)))).^.5./P
%c_v=(diag(inv(fisher'*fisher))).^.5


figure(2) ; hold on
plot(log10(Je))
axis([0 length(Je) 0 6])
xlabel('temps de cycle') ; ylabel('log10(Je)') ; title('Gujarati')
grid


% BRUN
%load sensi.txt
%N=size(sensi,1) ;
%np=size(sensi,2) ;
%sensi=(sensi(2:N,:));
%N=N-1;

Jb(1)=1000 ; 
for i=2:N
    for u=1:np
        if norm(sensi(1:i,u))>1e-12
            sensit(1:i,u) = sensi(1:i,u)/norm(sensi(1:i,u)) ;
        else
            sensit(1:i,u) = 1e-12*sensi(1:i,u) ;
        end
    end    
  
    fishert=sensit(1:i,etude)'*sensit(1:i,etude);e=eig(fishert);
    Jb(i)=real(1/(min(e))^.5) ; detJb(i)=det(fishert)^(1/length(etude)) ;
    if Jb(i)<1e-3 ; Jb(i)=1000 ;end ;
    if Jb(i)>1000 ; Jb(i)=1000  ;end
   
end

%diag(inv(fisher(:,etude)'*fisher(:,etude))).^.5
figure(3)
plot(Jb); hold on
title('critere BRUN')
axis([0 length(Jb) 0 50])
xlabel('temps de cycle') ; ylabel('Jb)') ; title('Brun')
grid

Jb(length(Jb))
Je(length(Je))

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
% CV=pinv(fisher) 
% diag(CV).^0.5
% 
% for i=1:size(sensi,2)
%     for j=1:size(sensi,2)
%         CR(i,j)= CV(i,j)/(CV(i,i)*CV(j,j))^.5 ;
%         CR=abs(CR);
%     end    
% end

for i=1:size(sensi,2)
    for j=1:size(sensi,2)
        MACMat(i,j)=abs(sensi(:,i)'*sensi(:,j))^2/( norm(sensi(:,i))^2*norm(sensi(:,j))^2 );
        if norm(sensi(:,i))<1e-6 | norm(sensi(:,j))<1e-6 
            MACMat(i,j)=1 ; disp('attention faible norme'); 
        end 
    end
end


for i=1:size(sensi,2)
    for j=1:size(sensi,2)
        MACMatBRUN=[sensit(:,i) sensit(:,j)]'*[sensit(:,i) sensit(:,j)] ;
        e=eig(MACMatBRUN) ;
        MACJb(i,j)=(1/(min(e))^.5) ; 
        %if MACJb(i,j)>20 ; MACJb(i,j)=20 ; end
    end
end

for i=1:size(sensi,2)
    for j=1:size(sensi,2)
        MACMatJe=[sensi(:,i) sensi(:,j)]'*[sensi(:,i) sensi(:,j)] ;
        e=eig(MACMatJe) ;
        MACJe(i,j)=max(eig(MACMatJe))/min(eig(MACMatJe));
        %if MACJe(i,j)>1000 ; MACJe(i,j)=1000 ; end
    end  
end

% for i=1:size(sensi,2)
%     for j=1:size(sensi,2)
%         MACH(i,j)= abs(fisher(i,j)/(fisher(i,i)*fisher(j,j))^.5) ;
%     end    
% end
%MACMat
%CR
MACJb
MACJe=log10(MACJe)
%MACH   

% 
% figure(4)
% [l c] = size(MACMat) ;
% MACMat = [MACMat zeros(l,1)] ;
% MACMat = [MACMat ; zeros(1,c+1)] ;
% [l c] = size(MACMat) ;
% colormap(cool) ;
% colormap(gray(4))
% pcolor(MACMat) ;
% colorbar ;
% title('MACMat matrix') ;
% xlabel('parameter 2') ;
% ylabel('parameter 1') ;
% axis square    
% 
% figure(5)
% [l c] = size(CR) ;
% CR = [CR zeros(l,1)] ;
% CR = [CR ; zeros(1,c+1)] ;
% [l c] = size(CR) ;
% colormap(cool) ;
% colormap(gray(10))
% pcolor(CR) ;
% colorbar ;
% xlabel('\it{\theta_i}','FontSize',30,'FontName','Times New Roman');
% ylabel('\it{\theta_j}','FontSize',30,'FontName','Times New Roman');
% title('Correlation Matrix (CR)','FontSize',20,'FontName','Times New Roman');
% axis square    
   

figure(6)
[l c] = size(MACJb) ;
MACJb = [MACJb zeros(l,1)] ;
MACJb = [MACJb ; zeros(1,c+1)] ;
[l c] = size(MACJb) ;
colormap(cool) ;
colormap(gray(4))
pcolor(MACJb) ;
colorbar ;
xlabel('\it{\theta_i}','FontSize',30,'FontName','Times New Roman');
ylabel('\it{\theta_j}','FontSize',30,'FontName','Times New Roman');
title('JB matrix (Brun criteria)','FontSize',20,'FontName','Times New Roman');
axis square    


figure(7)
[l c] = size(MACJe) ;
MACJe = [(MACJe) zeros(l,1)] ;
MACJe = [(MACJe) ; zeros(1,c+1)] ;
[l c] = size(Je) ;
colormap(cool) ;
colormap(gray(4))
pcolor(MACJe) ;
colorbar ;
title('Je matrix') ;
xlabel('parameter 2') ;
ylabel('parameter 1') ;
axis square    


% figure(8)
% [l c] = size(MACH) ;
% MACH = [MACH zeros(l,1)] ;
% MACH = [MACH ; zeros(1,c+1)] ;
% [l c] = size(MACH) ;
% colormap(cool) ;
% colormap(gray(4))
% pcolor(MACH) ;
% colorbar ;
% title('H matrix') ;
% xlabel('parameter 2') ;
% ylabel('parameter 1') ;
% 

Jb(length(Jb))
Je(length(Je))

