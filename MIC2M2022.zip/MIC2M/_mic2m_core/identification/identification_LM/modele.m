function [temps,sortie,test_rupture,aux]=modele(fich_essai) ;

[temps,sortie,test_rupture,aux] = simul(fich_essai,'i') ;
