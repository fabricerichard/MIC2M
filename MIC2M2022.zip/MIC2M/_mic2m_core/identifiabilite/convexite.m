%close all
clear all

% valeur des parametres identifies (nombre egale au nombre de colonnes du
% fichier sensi.txt
%P = [417.2 5.66 404.9]
%P = [5.66 404.9]
%P = [200000 1240 .3]

P = [1.63 1.05 0.13 18.56] ; % E c1 Nu Eta
P = [243 52.9 70.7] ; 
P = [3.47E-05 4.71E-06 4.85E-05 ] ;
P = [8.50E-06 3.43E-06 7.64E-05 ] ;
P = [3.44 6.33] 
%P = [14.1 34.7] 

% valeur la fonction objective obtenue
w=8.04e-3/2 ;
w=4.29e-3/2;
w=5.2e-4/2
%w=3.4e-4/2


% le set de parametres etudie
etude=[1 2 ]
%etude=[1 2 3]

% recuperation des sensibilites calculees a l'aide de <identifiabilite.m>
%load sensi.txt ; sensi=sensi;
load sensiTiAl_BerkoCC.txt ; sensi=sensiTiAl_BerkoCC;
%load sensiTiAlN_BerkoCC.txt ; sensi=sensiTiAlN_BerkoCC;



%sensi=sensi(1:51,:).*(size(sensi,1)/51)^.5
%sensi=sensi(1:21,:).*(size(sensi,1)/21)^.5*(82/20);
%npara=size(sensi,2);
%P=zeros(1,npara)
%P(etude(1))=para(1);
%P(etude(2))=para(2);

fisher=sensi(:,etude)'*sensi(:,etude);e=eig(fisher);
Hb=fisher;

log10(real(max(e)/min(e)))

nbpara=length(P);

for i =1:nbpara
for j =1:nbpara
H(i,j)=Hb(i,j)/P(i)/P(j);
end
end

% incertitude relative
Vb=inv(Hb)
for i =1:nbpara
    Dr(i)=(2*w*Vb(i,i))^0.5;
end
Dr
% incertitude absolue
V=inv(H)
for i =1:nbpara
    D(i)=(2*w*V(i,i))^0.5;
    %D(i)=(2*Vb(i,i)*w)^0.5*P(i);
end
D


%%%%%%%%%%%%%%%%%%%%%%%%%%
%%graphe si 2 param�tres
%%%%%%%%%%%%%%%%%%%%%%%%%%
pp1=1;
pp2=2;

P1=P(pp1);
P2=P(pp2);

%[x,y] = meshgrid(-5e-1:1e-3:5e-1);
[x,y] = meshgrid(-1:1e-3:1);

X=x ;
Y=y ;

X=x*P1+P1 ;
Y=y*P2+P2 ;

xx=x*P1 ;
yy=y*P2 ;

%Z= 0.5*((Hb(1,1)*x+Hb(1,2)*y).*x+(Hb(2,1)*x+Hb(2,2)*y).*y) ;
Z= 0.5*((H(pp1,pp1)*xx+H(pp1,pp2)*yy).*xx+(H(pp2,pp1)*xx+H(pp2,pp2)*yy).*yy) ;


figure(10)
hold on
[C,h] = contour(X,Y,Z,[1e-4 1e-5 1e-6],'r');
set(h,'ShowText','on','TextStep',get(h,'LevelStep')*2)
%colormap cool
%colormap gray
axis square

plot(P1,P2,'ob')

%(Vb(1,1)/Vb(2,2))^.5

VVb = inv([Hb(pp1,pp1) Hb(pp1,pp2) ; Hb(pp2,pp1) Hb(pp2,pp2)]) ;
Dx=(2*VVb(1,1)*w)^0.5*P1;
Dy=(2*VVb(2,2)*w)^0.5*P2;
%Dx=(2*VVb(pp1,pp1)*w)^0.5*P1;
%Dy=(2*VVb(pp2,pp2)*w)^0.5*P2;

%Dx_x=(2*Vb(1,1)*w)^0.5;
%Dy_y=(2*Vb(2,2)*w)^0.5;

%make some arbitrary rectangle (in this case, located at (0,0) with [width, height] of [10, 20])
rect_H = rectangle('Position', [P1-Dx, P2-Dy, 2*Dx, 2*Dy]); 
%sets the edge to be green
set(rect_H, 'EdgeColor', [0, 1, 0])
hold on




